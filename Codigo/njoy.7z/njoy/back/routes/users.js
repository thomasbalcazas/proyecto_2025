import express from 'express';
const router = express.Router();

// Datos de ejemplo (reemplázalo con una base de datos real)
let usuarios = [
    { nombre: "Juan", email: "juan@example.com", password: "123456" }
];

// Ruta POST /api/login
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    const usuario = usuarios.find(u => u.email === email && u.password === password);

    if (usuario) {
        res.json({ success: true, usuario });
    } else {
        res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
    }
});

// Ruta POST /api/registro
router.post('/registro', (req, res) => {
    const { nombre, email, password } = req.body;

    if (usuarios.some(u => u.email === email)) {
        return res.status(400).json({ success: false, message: 'Email ya registrado' });
    }

    usuarios.push({ nombre, email, password });
    res.json({ success: true, message: 'Registro exitoso' });
});

export default router;