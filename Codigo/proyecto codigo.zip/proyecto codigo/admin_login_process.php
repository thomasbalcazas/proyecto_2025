<?php
// admin_login_process.php

// Inicia la sesión en la primera línea.
session_start();

// --- Define aquí tus credenciales de administrador ---
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'Njoyadminadmin'); // ¡Cambia esta contraseña por una segura!

// Comprueba que los datos se enviaron por el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Verifica si las credenciales son correctas
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        
        // Credenciales correctas: crea la sesión y redirige al panel de admin
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin.php');
        exit;

    } else {
        // ---- ESTA ES LA PARTE CLAVE ----
        // Credenciales incorrectas: redirige de vuelta a login.php CON LA SEÑAL DE ERROR
        header('Location: login.php?error=1');
        exit;
    }

} else {
    // Si alguien intenta acceder a este archivo sin enviar el formulario, lo mandamos al login
    header('Location: login.php');
    exit;
}
?>