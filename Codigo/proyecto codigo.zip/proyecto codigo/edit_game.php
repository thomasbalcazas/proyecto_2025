<?php
// edit_game.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login_admin.php');
    exit;
}

require_once 'db.php';

// Validar ID del juego
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Error: Se requiere un ID de juego válido.");
}
$juego_id = (int)$_GET['id'];

// Obtener todos los datos del juego
$stmt = $conn->prepare("SELECT * FROM juegos WHERE id = ?");
$stmt->bind_param("i", $juego_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows !== 1) {
    die("Error: Juego con ID {$juego_id} no encontrado.");
}
$juego = $result->fetch_assoc();
$stmt->close();

// Obtener las secciones a las que pertenece el juego
$secciones_actuales = [];
$stmt_secciones = $conn->prepare("SELECT seccion_id FROM juego_secciones WHERE juego_id = ?");
$stmt_secciones->bind_param("i", $juego_id);
$stmt_secciones->execute();
$result_secciones = $stmt_secciones->get_result();
while ($row = $result_secciones->fetch_assoc()) {
    $secciones_actuales[] = $row['seccion_id'];
}
$stmt_secciones->close();

// Obtener todas las secciones disponibles para el formulario
$todas_las_secciones = [];
$sql_todas_secciones = "SELECT id, nombre_visible FROM secciones ORDER BY nombre_visible ASC";
$result_todas_secciones = $conn->query($sql_todas_secciones);
if ($result_todas_secciones) {
    while($seccion = $result_todas_secciones->fetch_assoc()) {
        $todas_las_secciones[] = $seccion;
    }
}

// Procesar galería de imágenes para mostrar
$galeria_actual = [];
if (!empty($juego['imagenes_galeria'])) {
    // Filtrar elementos vacíos que podrían resultar de un '||' al final o al principio
    $galeria_actual = array_filter(explode('|', $juego['imagenes_galeria']));
}

// Convertir características y requisitos de '|' a saltos de línea para el textarea
$caracteristicas_textarea = str_replace('|', "\n", $juego['caracteristicas'] ?? '');
$req_minimos_textarea = str_replace('|', "\n", $juego['req_minimos'] ?? '');
$req_recomendados_textarea = str_replace('|', "\n", $juego['req_recomendados'] ?? '');


// Variables para el estado de los checkboxes de precio
$is_upcoming = (bool)$juego['es_proximamente'];
$is_free = (!$is_upcoming && (float)$juego['precio_final'] == 0 && (int)$juego['descuento_porcentaje'] == 0);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Juego - NJOY</title>
    <style>
        /* CSS completo para consistencia visual con admin.php */
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #1A1A2E; color: #E0E7FF; line-height: 1.6; padding: 2rem; }
        .admin-container { max-width: 800px; margin: 0 auto; }
        h1, h2 { color: #FFFFFF; margin-bottom: 1.5rem; font-weight: 600; }
        h2 { padding-bottom: 0.5rem; border-bottom: 1px solid rgba(139, 92, 246, 0.3); font-weight: 500; margin-top: 2rem;}
        .form-container { background-color: #16213E; padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2); }
        .form-group { margin-bottom: 1.5rem; }
        .form-row { display: flex; gap: 1.5rem; }
        .form-row .form-group { flex: 1; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #A5B4FC; }
        .form-input, textarea.form-input { width: 100%; padding: 0.8rem 1rem; background-color: #1A1A2E; border: 2px solid #312E81; border-radius: 8px; color: #E0E7FF; font-size: 1rem; transition: all 0.3s ease; font-family: inherit; }
        textarea.form-input { resize: vertical; min-height: 120px; }
        .form-input:disabled { background-color: #2a2a4a; color: #888; cursor: not-allowed; }
        .form-input:focus:not(:disabled) { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.25); }
        .form-group-checkbox { display: flex; align-items: center; gap: 0.75rem; background-color: #1A1A2E; padding: 0.8rem 1rem; border-radius: 8px; margin-bottom: 1.5rem; cursor: pointer; border: 2px solid #312E81; }
        .form-group-checkbox input[type="checkbox"] { width: 1.2em; height: 1.2em; accent-color: #8B5CF6; }
        .form-help-text { display: block; margin-top: 0.5rem; font-size: 0.8rem; color: #9CA3AF; }
        .form-help-text code { background-color: #1A1A2E; padding: 2px 5px; border-radius: 4px; color: #E0E7FF; }
        .current-image { max-width: 150px; display: block; margin-bottom: 1rem; border-radius: 8px; border: 2px solid #312E81; }
        .back-link { display: inline-block; margin-bottom: 2rem; color: #A5B4FC; text-decoration: none; font-weight: 600; }
        .submit-btn { width: 100%; padding: 1rem; background: linear-gradient(90deg, #6366F1, #8B5CF6); color: #FFFFFF; border: none; border-radius: 8px; font-size: 1.1rem; font-weight: 700; cursor: pointer; transition: all 0.3s ease; text-transform: uppercase; }
        .submit-btn:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(139, 92, 246, 0.3); }
        .gallery-management { border: 2px solid #312E81; border-radius: 8px; padding: 1.5rem; background-color: #1A1A2E; }
        .current-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
        .gallery-item { position: relative; }
        .gallery-item img { width: 100%; height: auto; display: block; aspect-ratio: 16/9; object-fit: cover; border-radius: 4px; }
        .delete-label { position: absolute; top: 8px; right: 8px; background-color: rgba(0,0,0,0.6); padding: 4px; border-radius: 50%; display: flex; cursor: pointer; }
        .delete-label input { width: 18px; height: 18px; accent-color: #ec4899; cursor: pointer; }
        .file-upload-button { display: inline-block; width: 100%; padding: 0.8rem 1rem; background-color: #16213E; border: 2px solid #312E81; border-radius: 8px; color: #E0E7FF; cursor: pointer; text-align: center; }
        .gallery-preview { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 1rem; margin-top: 1.5rem; }
        .preview-item { display: flex; flex-direction: column; gap: 0.5rem; align-items: center; }
        .preview-image { width: 100%; height: auto; aspect-ratio: 16/9; object-fit: cover; border-radius: 4px; }
        .checkbox-group { border: 2px solid #312E81; border-radius: 8px; padding: 1rem; background-color: #1A1A2E; }
        .checkbox-item { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; }
        .checkbox-item:last-child { margin-bottom: 0; }
        .checkbox-item label { margin-bottom: 0; }
        @media (max-width: 600px) { .form-row { flex-direction: column; gap: 0; } }
    </style>
</head>
<body>
    <div class="admin-container">
        <a href="admin.php" class="back-link">← Volver al Panel</a>
        <h1>Modificar Juego</h1>
        
        <div class="form-container">
            <form action="update_game.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="juego_id" value="<?php echo $juego['id']; ?>">

                <h2>Datos Principales</h2>
                <div class="form-group"><label for="titulo">Título del Juego</label><input type="text" id="titulo" name="titulo" class="form-input" value="<?php echo htmlspecialchars($juego['titulo']); ?>" required></div>
                <div class="form-group"><label>Portada Actual</label><img src="<?php echo htmlspecialchars($juego['imagen_url']); ?>" alt="Imagen actual" class="current-image"></div>
                <div class="form-group"><label for="imagen">Cambiar Portada (Opcional)</label><input type="file" id="imagen" name="imagen" class="form-input"><input type="hidden" name="imagen_actual" value="<?php echo htmlspecialchars($juego['imagen_url']); ?>"></div>
                <div class="form-group-checkbox"><input type="checkbox" id="es_free" name="es_free" <?php if ($is_free) echo 'checked'; ?>><label for="es_free">Marcar si es Free to Play</label></div>
                <div class="form-group-checkbox"><input type="checkbox" id="es_proximamente" name="es_proximamente" value="1" <?php if ($is_upcoming) echo 'checked'; ?>><label for="es_proximamente">Marcar como "Próximamente"</label></div>
                <div class="form-row">
                    <div class="form-group"><label for="precio">Precio Final (USD)</label><input type="number" id="precio" name="precio" step="0.01" class="form-input" value="<?php echo htmlspecialchars($juego['precio_final']); ?>" required></div>
                    <div class="form-group"><label for="descuento">Descuento (%)</label><input type="number" id="descuento" name="descuento" class="form-input" value="<?php echo htmlspecialchars($juego['descuento_porcentaje']); ?>"></div>
                </div>
                <div class="form-group"><label for="tags">Tags (separados por coma)</label><input type="text" id="tags" name="tags" class="form-input" value="<?php echo htmlspecialchars($juego['tags'] ?? ''); ?>" placeholder="Ej: ROL, Aventura"></div>

                <h2>Detalles de la Página del Juego</h2>
                <div class="form-group"><label for="pagina_url">URL de la Página del Juego</label><input type="text" id="pagina_url" name="pagina_url" class="form-input" value="<?php echo htmlspecialchars($juego['pagina_url'] ?? ''); ?>" required></div>
                <div class="form-group"><label for="descripcion_larga">Descripción Larga</label><textarea id="descripcion_larga" name="descripcion_larga" class="form-input" rows="6"><?php echo htmlspecialchars($juego['descripcion_larga'] ?? ''); ?></textarea></div>
                <div class="form-group">
                    <label for="video_youtube_id">ID del Video de YouTube</label>
                    <input type="text" id="video_youtube_id" name="video_youtube_id" class="form-input" value="<?php echo htmlspecialchars($juego['video_youtube_id'] ?? ''); ?>" placeholder="Ej: QdBZY2fkU-0">
                    <small class="form-help-text">Copia solo el código de 11 caracteres de la URL. Ej: <code>youtube.com/watch?v=<strong>QdBZY2fkU-0</strong></code></small>
                </div>

                <div class="form-group">
                    <label>Gestión de Galería</label>
                    <div class="gallery-management">
                        <h3>Galería Actual</h3>
                        <?php if (!empty($galeria_actual)): ?>
                            <div class="current-gallery">
                                <?php foreach ($galeria_actual as $img_url): ?>
                                    <div class="gallery-item">
                                        <img src="<?php echo htmlspecialchars($img_url); ?>" alt="Imagen de galería">
                                        <label class="delete-label" title="Marcar para eliminar"><input type="checkbox" name="delete_gallery[]" value="<?php echo htmlspecialchars($img_url); ?>"></label>
                                        
                                        <!-- === CORRECCIÓN CLAVE: Enviar la lista de imágenes actuales para que no se borren === -->
                                        <input type="hidden" name="galeria_actual[]" value="<?php echo htmlspecialchars($img_url); ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <small class="form-help-text">Marque las imágenes que desea eliminar. Los cambios se aplicarán al guardar.</small>
                        <?php else: ?>
                            <p>Este juego no tiene imágenes en la galería.</p>
                        <?php endif; ?>

                        <h3 style="margin-top: 1.5rem; margin-bottom: 1rem;">Añadir Nuevas Imágenes</h3>
                        <button type="button" id="add_gallery_btn" class="file-upload-button">Seleccionar archivos para añadir...</button>
                        <input type="file" id="gallery_file_input" name="imagenes_galeria[]" multiple style="display: none;" accept="image/jpeg, image/png, image/webp, image/gif">
                        <div id="gallery_preview_container" class="gallery-preview"></div>
                    </div>
                </div>

                <div class="form-group"><label for="caracteristicas">Características Principales (una por línea)</label><textarea id="caracteristicas" name="caracteristicas" class="form-input" rows="5"><?php echo htmlspecialchars($caracteristicas_textarea); ?></textarea></div>
                <div class="form-row">
                    <div class="form-group"><label for="req_minimos">Requisitos Mínimos (una por línea)</label><textarea id="req_minimos" name="req_minimos" class="form-input" rows="6"><?php echo htmlspecialchars($req_minimos_textarea); ?></textarea></div>
                    <div class="form-group"><label for="req_recomendados">Requisitos Recomendados (una por línea)</label><textarea id="req_recomendados" name="req_recomendados" class="form-input" rows="6"><?php echo htmlspecialchars($req_recomendados_textarea); ?></textarea></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label for="desarrollador">Desarrollador</label><input type="text" id="desarrollador" name="desarrollador" class="form-input" value="<?php echo htmlspecialchars($juego['desarrollador'] ?? ''); ?>"></div>
                    <div class="form-group"><label for="editor">Editor</label><input type="text" id="editor" name="editor" class="form-input" value="<?php echo htmlspecialchars($juego['editor'] ?? ''); ?>"></div>
                </div>
                <div class="form-group"><label for="fecha_lanzamiento">Fecha de Lanzamiento</label><input type="text" id="fecha_lanzamiento" name="fecha_lanzamiento" class="form-input" value="<?php echo htmlspecialchars($juego['fecha_lanzamiento'] ?? ''); ?>" placeholder="Ej: 14 ABR 2015"></div>
                
                <div class="form-group">
                    <label>Asignar a Secciones</label>
                    <div class="checkbox-group">
                        <?php
                        if (!empty($todas_las_secciones)) {
                            foreach($todas_las_secciones as $seccion) {
                                $seccion_id = htmlspecialchars($seccion['id']);
                                $nombre_seccion = htmlspecialchars($seccion['nombre_visible']);
                                $is_checked = in_array($seccion['id'], $secciones_actuales) ? 'checked' : '';
                                echo "<div class='checkbox-item'><input type='checkbox' name='secciones[]' value='{$seccion_id}' id='seccion_{$seccion_id}' {$is_checked}><label for='seccion_{$seccion_id}'>{$nombre_seccion}</label></div>";
                            }
                        }
                        ?>
                    </div>
                </div>

                <button type="submit" class="submit-btn">Actualizar Juego</button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Lógica para checkboxes de precio
            const freeCheckbox = document.getElementById('es_free');
            const proximamenteCheckbox = document.getElementById('es_proximamente');
            const precioInput = document.getElementById('precio');
            const descuentoInput = document.getElementById('descuento');

            function handlePriceOptions() {
                const isFree = freeCheckbox.checked;
                const isUpcoming = proximamenteCheckbox.checked;

                precioInput.disabled = isFree || isUpcoming;
                descuentoInput.disabled = isFree || isUpcoming;
                
                if (isUpcoming) {
                    freeCheckbox.disabled = true;
                    if (freeCheckbox.checked) freeCheckbox.checked = false;
                } else if (isFree) {
                    proximamenteCheckbox.disabled = false;
                    precioInput.value = '0.00';
                    descuentoInput.value = '0';
                } else {
                    freeCheckbox.disabled = false;
                    proximamenteCheckbox.disabled = false;
                }
            }
            
            freeCheckbox.addEventListener('change', handlePriceOptions);
            proximamenteCheckbox.addEventListener('change', handlePriceOptions);
            handlePriceOptions(); // Ejecutar al cargar para establecer el estado inicial

            // Lógica para la galería acumulativa
            const addButton = document.getElementById('add_gallery_btn');
            const fileInput = document.getElementById('gallery_file_input');
            const previewContainer = document.getElementById('gallery_preview_container');
            let fileStore = new DataTransfer();

            if (addButton) {
                addButton.addEventListener('click', () => fileInput.click());
            }

            if (fileInput) {
                fileInput.addEventListener('change', (event) => {
                    // Añadir los nuevos archivos al DataTransfer
                    for (const file of event.target.files) {
                        fileStore.items.add(file);
                    }
                    // Asignar la colección actualizada de vuelta al input
                    fileInput.files = fileStore.files;
                    updatePreview();
                });
            }

            function updatePreview() {
                previewContainer.innerHTML = '';
                Array.from(fileStore.files).forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const previewItem = document.createElement('div');
                        previewItem.className = 'preview-item';

                        const img = document.createElement('img');
                        img.className = 'preview-image';
                        img.src = e.target.result;

                        const removeButton = document.createElement('button');
                        removeButton.type = 'button';
                        removeButton.textContent = 'Quitar';
                        removeButton.style.cssText = "font-size:0.7rem; padding:2px 5px; margin-top: 4px; background-color:#EF4444; color:white; border:none; border-radius:4px; cursor:pointer;";
                        
                        removeButton.onclick = function() {
                            const newFileStore = new DataTransfer();
                            const currentFiles = Array.from(fileStore.files);
                            // Volver a añadir todos los archivos excepto el que se quiere quitar
                            currentFiles.forEach((file, i) => {
                                if (index !== i) {
                                    newFileStore.items.add(file);
                                }
                            });
                            
                            fileStore = newFileStore; // Actualizar el almacén de archivos
                            fileInput.files = fileStore.files; // Sincronizar con el input
                            updatePreview(); // Volver a renderizar la vista previa
                        };

                        previewItem.appendChild(img);
                        previewItem.appendChild(removeButton);
                        previewContainer.appendChild(previewItem);
                    }
                    reader.readAsDataURL(file);
                });
            }
        });
    </script>
</body>
</html>