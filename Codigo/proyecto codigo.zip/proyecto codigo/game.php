<?php
// game.php
session_start();
if (!isset($_SESSION['usuario_id']) || empty($_SESSION['usuario_id'])) {
    $redirect_url = urlencode($_SERVER['REQUEST_URI']);
    header('Location: login.html?redirect=' . $redirect_url);
    exit();
}
require_once 'db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { die("Juego no encontrado."); }
$juego_id = (int)$_GET['id'];
$usuario_actual_id = (int)$_SESSION['usuario_id'];

// === INICIO DE LA AUTOMATIZACIÓN DE PRECIO ARS ===

/**
 * Obtiene la tasa de conversión actualizada de USD a ARS, usando un sistema de caché.
 * @return float La tasa de conversión.
 */
function get_ars_conversion_rate() {
    $apiKey = 'd6cd4770cf766bd3beb9cef2'; // Tu API Key
    $cacheFile = 'exchange_rate_cache.json';
    $cacheTime = 86400; // 24 horas en segundos
    $fallbackRate = 1400; // Valor de respaldo por si todo falla

    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTime) {
        $cache = json_decode(file_get_contents($cacheFile), true);
        if (isset($cache['rate']) && is_numeric($cache['rate'])) {
            return $cache['rate'];
        }
    }

    $apiUrl = "https://v6.exchangerate-api.com/v6/{$apiKey}/latest/USD";
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if ($data && $data['result'] === 'success' && isset($data['conversion_rates']['ARS'])) {
            $rate = $data['conversion_rates']['ARS'];
            file_put_contents($cacheFile, json_encode(['rate' => $rate, 'timestamp' => time()]));
            return $rate;
        }
    }

    if (file_exists($cacheFile)) {
        $cache = json_decode(file_get_contents($cacheFile), true);
        if (isset($cache['rate'])) {
            return $cache['rate'];
        }
    }
    
    return $fallbackRate;
}

$conversion_rate_ars = get_ars_conversion_rate();
// === FIN DE LA AUTOMATIZACIÓN ===


$stmt = $conn->prepare("SELECT * FROM juegos WHERE id = ?");
$stmt->bind_param("i", $juego_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows !== 1) { die("Juego no encontrado."); }
$juego = $result->fetch_assoc();
$stmt->close();

$amigos_recomiendan = [];
$stmt_amigos = $conn->prepare("
    SELECT u.id, u.nombre, u.foto
    FROM resenas r
    JOIN usuarios u ON r.usuario_id = u.id
    WHERE r.juego_id = ? AND r.recomendacion = 'recomienda' AND r.usuario_id IN (
        SELECT IF(usuario1_id = ?, usuario2_id, usuario1_id) FROM amigos 
        WHERE (usuario1_id = ? OR usuario2_id = ?) AND estado = 'aceptada'
    )
    LIMIT 5
");
$stmt_amigos->bind_param("iiii", $juego_id, $usuario_actual_id, $usuario_actual_id, $usuario_actual_id);
$stmt_amigos->execute();
$result_amigos = $stmt_amigos->get_result();
while ($row = $result_amigos->fetch_assoc()) {
    $amigos_recomiendan[] = $row;
}
$stmt_amigos->close();

$conn->close();

function getAbsolutePath($path) {
    $path = trim($path);
    if (!empty($path) && strpos($path, '/') !== 0 && strpos($path, 'http') !== 0) {
        return '/' . $path;
    }
    return $path;
}

$tags_array = !empty($juego['tags']) ? explode(',', $juego['tags']) : [];
$galeria_array = !empty($juego['imagenes_galeria']) ? explode('|', $juego['imagenes_galeria']) : [];
$caracteristicas_array = !empty($juego['caracteristicas']) ? explode('|', $juego['caracteristicas']) : [];
$req_min_array = !empty($juego['req_minimos']) ? explode('|', $juego['req_minimos']) : [];
$req_rec_array = !empty($juego['req_recomendados']) ? explode('|', $juego['req_recomendados']) : [];
$main_media_image = $galeria_array[0] ?? $juego['imagen_url'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Allerta+Stencil&display=swap" rel="stylesheet">
  <title>NJOY - <?php echo htmlspecialchars($juego['titulo']); ?></title>
  <link rel="icon" type="image/x-icon" href="/favicon.ico">
  
  <style>
    /* === PANTALLA DE CARGA (LOADER) === */
    #loader {
        position: fixed;
        inset: 0;
        z-index: 99999;
        background-color: #1E1B4B;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: opacity 0.5s ease-out, visibility 0s linear 0.5s;
        opacity: 1;
        visibility: visible;
    }
    #loader.hidden {
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }
    #loader img {
        width: 120px;
        height: auto;
        animation: pulse 1.5s ease-in-out infinite;
        filter: drop-shadow(0 0 15px rgba(139, 92, 246, 0.7));
    }
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.08); opacity: 0.8; }
        100% { transform: scale(1); opacity: 1; }
    }
  </style>

  <style>
    /* === BASE Y FONDO === */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { font-size: clamp(10.5px, 1.125vw, 12px); }
    body { 
      font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; 
      background-color: #1E1B4B;
      color: white; 
      min-height: 100vh; 
      position: relative;
      overflow-x: hidden;
      transition: color 0.5s ease; 
    }
    
    .page-background-container {
        position: fixed; top: 0; left: 0; width: 100%; height: 100vh;
        z-index: 0; pointer-events: none; overflow: hidden;
    }
    .background-gradient {
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #3B0764 25%, #1E1B4B 50%, #312E81 75%, #6366F1 100%);
        background-size: 400% 400%; animation: gradientShift 20s ease infinite;
    }
    @keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
    
    .floating-shapes { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 3; overflow: hidden; }
    .shape { position: absolute; background: rgba(139, 92, 246, 0.1); border-radius: 50%; animation: float 25s linear infinite; backdrop-filter: blur(1px); transition: transform 0.4s ease-out; }
    .shape:nth-child(1) { width: 100px; height: 100px; left: 10%; animation-duration: 30s; }
    .shape:nth-child(2) { width: 150px; height: 150px; left: 30%; animation-duration: 25s; }
    .shape:nth-child(3) { width: 80px; height: 80px; left: 60%; animation-duration: 35s; }
    .shape:nth-child(4) { width: 120px; height: 120px; left: 80%; animation-duration: 28s; }
    @keyframes float { 0% { transform: translateY(100vh) rotate(0deg); opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { transform: translateY(-200px) rotate(360deg); opacity: 0; } }

    .page-content {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        opacity: 0;
        transition: opacity 0.6s ease 0.2s;
        position: relative;
        z-index: 1;
    }
    .page-content.loaded {
        opacity: 1;
    }
    
    /* === HEADER Y NAV === */
    header, nav { 
      background: rgba(30, 30, 47, 0.85); 
      backdrop-filter: blur(15px); 
      position: fixed; 
      left: 0; 
      right: 0; 
      border-bottom: 2px solid rgba(139, 92, 246, 0.2); 
      z-index: 1001; 
      transition: all 0.3s ease; 
    }
    header { 
      padding: 12px 5%; display: flex; align-items: center; 
      justify-content: space-between; top: 0; height: 70px; 
      box-shadow: 0 5px 20px rgba(0,0,0,0.2); 
    }
    nav { 
      display: flex; align-items: center; justify-content: center; 
      gap: 35px; padding: 12px 5%; top: 70px; height: 50px; 
      z-index: 1000; 
    }
    .header-left { display: flex; align-items: center; gap: 70px; }
    .logo img { height: 38px; transition: transform 0.3s ease; filter: drop-shadow(0 4px 8px rgba(139, 92, 246, 0.4)); cursor: pointer; }
    .logo:hover img { transform: scale(1.05) rotate(5deg); }
    .header-right { display: flex; align-items: center; gap: 15px; justify-content: flex-end; flex-grow: 1; }
    nav a { 
      text-decoration: none; color: #E5E7EB; font-weight: 600; font-size: 0.95rem; 
      padding: 8px 5px; position: relative; transition: color 0.3s ease; 
    }
    nav a:hover { color: #FFFFFF; }
    nav a::after { 
      content: ''; position: absolute; width: 0%; height: 3px; border-radius: 2px; 
      background: linear-gradient(90deg, #8B5CF6, #6366F1); bottom: -5px; 
      left: 50%; transform: translateX(-50%); transition: width 0.4s cubic-bezier(0.25, 1, 0.5, 1); 
    }
    nav a:hover::after { width: 100%; }
    
    /* --- BARRA DE BÚSQUEDA --- */
    .search-container { position: relative; max-width: 500px; width: 100%; margin-right: 20px; }
    #searchInput { width: 100%; padding: 10px 15px 10px 40px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.3); background-color: rgba(0, 0, 0, 0.3); color: white; font-size: 0.9rem; transition: all 0.3s ease; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='rgba(255,255,255,0.5)' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: 15px center; }
    #searchInput:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); background-color: rgba(0, 0, 0, 0.5); }
    .search-results { display: none; position: absolute; top: 110%; left: 0; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(10px); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 10px; max-height: 400px; overflow-y: auto; z-index: 1000; }
    .search-category { padding: 8px 15px; font-size: 0.8rem; font-weight: bold; color: #a78bfa; text-transform: uppercase; border-bottom: 1px solid rgba(139, 92, 246, 0.2); }
    .search-item { display: flex; align-items: center; gap: 12px; padding: 10px 15px; text-decoration: none; color: #E5E7EB; transition: background-color 0.2s ease; }
    .search-item:hover { background-color: rgba(139, 92, 246, 0.15); }
    .search-item img { width: 64px; height: 36px; object-fit: cover; border-radius: 4px; }
    .search-item img.avatar { width: 36px; height: 36px; border-radius: 50%; }

    /* --- NOTIFICACIONES --- */
    #notificacionesBtn { position: relative; cursor: pointer; display: flex; align-items: center; }
    #notificacion-alerta { position: absolute; top: -2px; right: -4px; width: 10px; height: 10px; background-color: #ef4444; border-radius: 50%; border: 2px solid #1E1B4B; display: none; }
    #notificaciones-panel { display: none; position: absolute; top: 60px; right: 0; width: 340px; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; max-height: 400px; overflow-y: auto; animation: menuSlideDown 0.3s ease-out; }
    .notificacion-item { padding: 15px; display: flex; align-items: flex-start; gap: 12px; border-bottom: 1px solid rgba(139, 92, 246, 0.1); }
    .notificacion-item a { text-decoration: none; }
    .notificacion-item:last-child { border: none; }
    .notificacion-avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; }
    .notificacion-contenido { flex-grow: 1; }
    .notificacion-item p { font-size: 0.9rem; line-height: 1.4; color: #E5E7EB; margin: 0; }
    .notificacion-item p a { color: #c4b5fd; font-weight: bold; text-decoration: none; }
    .notificacion-item p a:hover { text-decoration: underline; }
    .notificacion-acciones { margin-top: 10px; display: flex; gap: 10px; }
    .notif-action-btn { font-size: 0.8rem; padding: 4px 10px; border-radius: 5px; border: none; cursor: pointer; font-weight: 600; color: white; transition: transform 0.1s ease; }
    .notif-action-btn:active { transform: scale(0.95); }
    .notif-action-btn.accept { background-color: #10B981; }
    .notif-action-btn.reject { background-color: #EF4444; }
    .notif-feedback { font-size: 0.9rem; color: #a78bfa; font-style: italic; }
    .notificacion-item.no-leida { background: rgba(139, 92, 246, 0.1); }
    #notificacion-icono-svg { width: 26px; height: 26px; stroke: #E5E7EB; transition: all 0.3s ease; }
    #notificacionesBtn:hover #notificacion-icono-svg { stroke: #FFFFFF; filter: drop-shadow(0 0 5px rgba(192, 132, 252, 0.7)); }

    .usuario { cursor: pointer; display: flex; align-items: center; gap: 10px; position: relative; z-index: 2; }
    .nombre-usuario { font-weight: 600; font-size: 0.95rem; transition: color 0.3s ease; }
    .usuario:hover .nombre-usuario { color: #e0e0e0; }
    .usuario img { width: 42px; height: 42px; border-radius: 50%; border: 2.5px solid rgba(139, 92, 246, 0.8); object-fit: cover; transition: all 0.3s ease; box-shadow: 0 0 15px rgba(139, 92, 246, 0.75); }
    .usuario:hover img { transform: scale(1.1); border-color: #8B5CF6; box-shadow: 0 0 25px rgba(139, 92, 246, 1); }
    .usuario-menu { display: none; position: absolute; top: 60px; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; overflow: hidden; min-width: 220px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; animation: menuSlideDown 0.3s ease-out; transition: background 0.5s ease; }
    @keyframes menuSlideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    .usuario-menu a { display: flex; align-items: center; gap: 12px; padding: 15px; text-decoration: none; color: white; font-weight: 500; font-size: 14px; transition: all 0.3s ease; }
    .usuario-menu a:hover { background: rgba(139, 92, 246, 0.2); }
    
    /* === LAYOUT PRINCIPAL Y ANIMACIONES DE ENTRADA === */
    main { 
        padding-top: 140px; 
        max-width: 1200px;
        width: 100%; 
        margin: 0 auto; 
        padding-left: 20px; 
        padding-right: 20px; 
        position: relative; 
        z-index: 2;
        flex-grow: 1;
    }
    [data-section] {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
    }
    [data-section].is-visible {
        opacity: 1;
        transform: translateY(0);
    }

    .breadcrumbs { margin-bottom: 20px; font-size: 0.9rem; color: #9ca3af; }
    .breadcrumbs a { color: #c4b5fd; text-decoration: none; transition: color 0.3s ease; }
    .hero-section { background: linear-gradient(135deg, #1e1b4b 0%, #3b0764 100%); border-radius: 8px; overflow: hidden; margin-bottom: 20px; position: relative; border: 1px solid rgba(139, 92, 246, 0.3); box-shadow: 0 10px 40px rgba(139, 92, 246, 0.2); }
    .hero-background { width: 100%; height: 400px; object-fit: cover; opacity: 0.3; }
    .hero-content { position: absolute; top: 0; left: 0; right: 0; bottom: 0; padding: 40px; display: flex; align-items: flex-end; background: linear-gradient(to bottom, transparent 0%, rgba(26, 11, 46, 0.9) 100%); }
    .hero-info h1 { font-size: clamp(2rem, 6vw, 3rem); font-weight: 300; margin-bottom: 10px; color: #fff; text-shadow: 0 0 20px rgba(139, 92, 246, 0.6); }
    .hero-tags { display: flex; gap: 8px; flex-wrap: wrap; }
    .hero-tags .tag { background: rgba(139, 92, 246, 0.3); padding: 6px 14px; border-radius: 5px; font-size: 12px; color: #e0d4ff; border: 1px solid rgba(139, 92, 246, 0.5); }

    /* === LAYOUT CON CSS GRID === */
    .game-content-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px; 
        gap: 0 40px;
        align-items: start;
    }
    .main-column {
        display: flex;
        flex-direction: column;
        gap: 20px;
        min-width: 0;
    }
    .sidebar-section {
        position: sticky;
        top: 140px;
        width: 320px; 
        display: flex; 
        flex-direction: column; 
        gap: 20px;
    }
    .media-section { min-width: 0; }

    .main-media { 
        background: #000; border-radius: 8px; overflow: hidden; position: relative; 
        border: 1px solid rgba(139, 92, 246, 0.3); box-shadow: 0 10px 40px rgba(139, 92, 246, 0.2); 
        aspect-ratio: 16 / 9;
        margin-bottom: 15px; 
        width: 100%;
    }
    .main-media img, .main-media iframe { 
        width: 100%; height: 100%; object-fit: cover; display: block; 
        border: none; position: absolute; top: 0; left: 0; 
    }
    .thumbnail-carousel { position: relative; padding: 0 40px; }
    .thumbnail-strip { 
        display: flex; gap: 10px; overflow-x: auto; scroll-behavior: smooth; 
        -ms-overflow-style: none; scrollbar-width: none; 
        padding-bottom: 5px;
    }
    .thumbnail-strip::-webkit-scrollbar { display: none; }
    .thumb { 
        flex-shrink: 0; 
        width: 120px;
        aspect-ratio: 16 / 9;
        border-radius: 4px; overflow: hidden; cursor: pointer; 
        border: 2px solid transparent; transition: all 0.3s ease; opacity: 0.6; 
        background: #000; position: relative; 
    }
    .thumb img { width: 100%; display: block; height: 100%; object-fit: cover; }
    .thumb:hover, .thumb.active { border-color: #8B5CF6; opacity: 1; }
    .thumb .play-icon { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 30px; height: 30px; background-color: rgba(0,0,0,0.6); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 14px; pointer-events: none; }
    .carousel-arrow { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(30, 30, 47, 0.8); border: 1px solid rgba(139, 92, 246, 0.3); color: white; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; z-index: 10; font-size: 20px; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; }
    .carousel-arrow:hover { background-color: #8B5CF6; }
    .carousel-arrow:active { transform: translateY(-50%) scale(0.9); }
    .carousel-arrow.prev { left: 0; }
    .carousel-arrow.next { right: 0; }
    .description-section, .requirements-section, .resenas-section { background: linear-gradient(135deg, rgba(30, 27, 75, 0.6) 0%, rgba(59, 7, 100, 0.4) 100%); padding: 30px; border-radius: 8px; border: 1px solid rgba(139, 92, 246, 0.2); box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3); }
    
    .requirements-section, .resenas-section {
        margin-top: 20px;
    }

    .description-section h2, .requirements-section h2, .resenas-section h2 { font-size: 1rem; text-transform: uppercase; color: #e0d4ff; margin-bottom: 20px; font-weight: 600; letter-spacing: 2px; border-bottom: 2px solid rgba(139, 92, 246, 0.4); padding-bottom: 10px; position: relative;}
    .description-section p { line-height: 1.8; margin-bottom: 15px; color: #d1d5db; }
    .features-list { list-style: none; padding: 0; }
    .features-list li { padding: 8px 0; padding-left: 25px; position: relative; color: #d1d5db; }
    .features-list li:before { content: "✓"; position: absolute; left: 0; color: #a78bfa; font-weight: bold; font-size: 18px; }
    .game-cover-box img { width: 100%; border-radius: 8px; box-shadow: 0 5px 30px rgba(139, 92, 246, 0.3); border: 1px solid rgba(139, 92, 246, 0.3); }
    .purchase-box { background: linear-gradient(135deg, rgba(30, 27, 75, 0.8) 0%, rgba(59, 7, 100, 0.6) 100%); padding: 20px; border-radius: 8px; border: 1px solid rgba(139, 92, 246, 0.4); box-shadow: 0 5px 25px rgba(139, 92, 246, 0.2); }
    .purchase-box h3 { font-size: 1.1rem; margin-bottom: 15px; color: #fff; font-weight: 500; }
    .price-section { background: rgba(0, 0, 0, 0.4); padding: 15px; border-radius: 5px; margin-bottom: 15px; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(139, 92, 246, 0.2); }
    .discount-badge { background: linear-gradient(135deg, #ec4899, #8B5CF6); color: #fff; padding: 8px 14px; font-size: 1.5rem; font-weight: 700; border-radius: 5px; box-shadow: 0 4px 15px rgba(236, 72, 153, 0.4); }
    .price-values { text-align: right; line-height: 1.3; }
    .original-price-ars { text-decoration: line-through; color: #9ca3af; font-size: 0.9rem; }
    .current-price-ars { font-size: 1.6rem; color: #e0d4ff; font-weight: 600; text-shadow: 0 0 10px rgba(139, 92, 246, 0.5); }
    .sub-price-usd { font-size: 0.8rem; color: #9ca3af; opacity: 0.7; }
    .purchase-button { background: linear-gradient(135deg, #8B5CF6, #6366F1); border: none; color: white; padding: 14px; width: 100%; border-radius: 5px; cursor: pointer; font-size: 1rem; font-weight: 600; transition: all 0.3s ease; text-decoration: none; display: block; text-align: center; box-shadow: 0 5px 20px rgba(139, 92, 246, 0.4); }
    .purchase-button:hover { background: linear-gradient(135deg, #a78bfa, #818cf8); transform: translateY(-3px); box-shadow: 0 8px 25px rgba(139, 92, 246, 0.6); }
    .purchase-button:active { transform: translateY(0) scale(0.98); }
    .game-info, .tags-section { background: rgba(30, 27, 75, 0.5); padding: 20px; border-radius: 8px; border: 1px solid rgba(139, 92, 246, 0.2); }
    .game-info { font-size: 0.9rem; }
    .info-row { display: flex; padding: 8px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.1); }
    .info-row:last-child { border-bottom: none; }
    .info-label { color: #a78bfa; flex: 0 0 120px; font-weight: 600; }
    .info-value, .info-value a { color: #d1d5db; text-decoration: none; transition: color 0.3s ease; }
    .info-value a:hover { color: #fff; }
    .tags-section h3 { font-size: 1rem; margin-bottom: 12px; color: #e0d4ff; font-weight: 500; }
    .tags-container { display: flex; flex-wrap: wrap; gap: 8px; }
    .tag-link { background: rgba(139, 92, 246, 0.2); padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; color: #c4b5fd; text-decoration: none; transition: all 0.3s ease; border: 1px solid rgba(139, 92, 246, 0.3); }
    .tag-link:hover { background: rgba(139, 92, 246, 0.4); color: #fff; border-color: #8B5CF6; transform: translateY(-2px); }
    .requirements-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
    .req-column h3 { font-size: 0.9rem; color: #c4b5fd; margin-bottom: 15px; font-weight: 600; }
    .req-column ul { list-style: none; padding: 0; }
    .req-column li { padding: 5px 0; font-size: 0.85rem; color: #d1d5db; }
    .req-column strong { color: #a78bfa; }
    
    /* === RESEÑAS Y SKELETON LOADER === */
    .resenas-section { min-height: 400px; }
    #form-resena { display: flex; flex-direction: column; gap: 15px; margin-bottom: 30px; padding-bottom: 30px; border-bottom: 1px solid rgba(139, 92, 246, 0.2); }
    .calificacion-input { display: flex; flex-direction: column; gap: 8px; }
    #lista-resenas { margin-top: 40px; }
    .rating-container { display: flex; align-items: center; gap: 15px; }
    .estrellas-rediseñadas { display: inline-flex; gap: 4px; font-size: 2.5rem; user-select: none; }
    .estrella-wrapper { position: relative; display: block; line-height: 1; }
    .estrella-wrapper .estrella-fondo, .estrella-wrapper .estrella-relleno { display: block; transition: color 0.2s ease; }
    .estrella-wrapper .estrella-fondo { color: #4a4a68; }
    .estrella-wrapper .estrella-relleno { position: absolute; top: 0; left: 0; color: #f8c325; overflow: hidden; width: 0; transition: width 0.1s ease; }
    .estrella-wrapper .interaccion-mitad { position: absolute; top: 0; left: 0; width: 50%; height: 100%; cursor: pointer; }
    .estrella-wrapper .interaccion-mitad.derecha { left: 50%; }
    #calificacion-numerica { font-size: 1.2rem; font-weight: 500; color: #c4b5fd; min-width: 50px; transition: color 0.2s ease; }
    #resena-texto { width: 100%; min-height: 100px; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(139, 92, 246, 0.4); border-radius: 5px; color: white; font-size: 1rem; resize: vertical; }
    #enviar-resena { align-self: flex-end; padding: 10px 25px; background: linear-gradient(135deg, #8B5CF6, #6366F1); border: none; color: white; border-radius: 5px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; }
    #enviar-resena:hover { background: linear-gradient(135deg, #a78bfa, #818cf8); transform: translateY(-2px); }
    #enviar-resena:active { transform: translateY(0) scale(0.98); }
    #enviar-resena:disabled { background: #555; cursor: not-allowed; }
    .resena-item { display: flex; gap: 15px; padding: 20px; position: relative; border-radius: 16px; transition: background 0.3s ease, border 0.3s ease; margin-bottom: 20px; animation: fadeIn 0.5s ease; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .resena-item:last-child { margin-bottom: 0; }
    .resena-item:not(.resena-premiada) { border-bottom: 1px solid rgba(139, 92, 246, 0.2); }
    .resena-item .avatar { text-decoration: none; }
    .resena-item .avatar img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
    .resena-contenido { flex: 1; }
    .resena-header { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
    .resena-header .nombre { text-decoration: none; font-weight: bold; color: #e0d4ff; transition: color 0.3s ease; }
    .resena-header .nombre:hover { color: #fff; }
    .estrellas-display { font-size: 1rem; color: #f8c325; }
    #lista-resenas:empty::after { content: 'Sé el primero en dejar una reseña para este juego.'; display: block; text-align: center; color: #9ca3af; padding: 20px 0; }
    .recomendacion-input { display: flex; flex-direction: column; gap: 8px; margin-bottom: 10px; }
    .recomendacion-botones { display: flex; gap: 15px; }
    .recomendacion-btn { flex: 1; padding: 12px; border-radius: 8px; border: 2px solid rgba(139, 92, 246, 0.3); background: rgba(139, 92, 246, 0.1); color: #e0d4ff; font-weight: 600; cursor: pointer; transition: all 0.2s ease-in-out; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .recomendacion-btn:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
    .recomienda-btn.selected { background: #10B981; border-color: #10B981; color: white; }
    .no-recomienda-btn.selected { background: #EF4444; border-color: #EF4444; color: white; }
    .resena-header .recomendacion-display { display: flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: bold; padding: 4px 8px; border-radius: 5px; }
    .recomendacion-display.recomienda { color: #A7F3D0; background: rgba(16, 185, 129, 0.2); }
    .recomendacion-display.no-recomienda { color: #FCA5A5; background: rgba(239, 68, 68, 0.2); }
    .resena-acciones { display: flex; align-items: center; gap: 20px; margin-top: 15px; opacity: 0.8; }
    .accion-btn { background: rgba(139, 92, 246, 0.15); border: 1px solid rgba(139, 92, 246, 0.3); color: #c4b5fd; padding: 5px 12px; border-radius: 20px; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 0.8rem; transition: all 0.3s ease; }
    .accion-btn:hover:not(:disabled) { background: rgba(139, 92, 246, 0.3); color: #fff; transform: translateY(-2px); }
    .accion-btn:active:not(:disabled) { transform: translateY(0) scale(0.95); }
    .accion-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .accion-btn .count { font-weight: bold; }
    .premiar-btn { background: rgba(253, 186, 116, 0.1); border-color: rgba(251, 146, 60, 0.4); color: #fcd34d; }
    .premiar-btn:hover:not(:disabled) { background: rgba(251, 146, 60, 0.3); color: #fff; }
    .accion-btn.accion-activa { background: #8B5CF6; color: #fff; border-color: #8B5CF6; }
    .premiar-btn.accion-activa { background: #f59e0b; border-color: #f59e0b; }
    .eliminar-resena-btn { position: absolute; top: 20px; right: 15px; background: none; border: none; color: #9ca3af; font-size: 1.5rem; cursor: pointer; transition: all 0.3s ease; padding: 5px; line-height: 1; z-index: 3; }
    .eliminar-resena-btn:hover { color: #ef4444; transform: scale(1.2) rotate(90deg); }
    @keyframes rayosGiratoriosFinal { from { transform: translate(-50%, -50%) rotate(0deg); } to { transform: translate(-50%, -50%) rotate(360deg); } }
    .resena-item.resena-premiada { background: linear-gradient(135deg, rgba(50, 40, 15, 0.7), rgba(30, 27, 75, 0.5)); border: 2px solid #FFD700; box-shadow: 0 0 20px rgba(255, 215, 0, 0.3), 0 0 40px rgba(255, 215, 0, 0.2) inset; overflow: hidden; }
    .resena-item.resena-premiada::before { content: ''; position: absolute; top: 50%; left: 50%; width: 200%; padding-bottom: 200%; transform: translate(-50%, -50%); z-index: 0; background-image: repeating-conic-gradient(from 12.5deg, rgba(255, 240, 200, 0.15) 0deg 1deg, transparent 1deg 25deg), repeating-conic-gradient(from 0deg, rgba(255, 215, 0, 0.2) 0deg 3deg, transparent 3deg 25deg); filter: blur(20px); animation: rayosGiratoriosFinal 35s linear infinite; }
    .resena-item.resena-premiada::after { content: 'RESEÑA DESTACADA 🌟'; position: absolute; top: 0; left: 0; background: #FFD700; color: #1E1B4B; padding: 4px 12px; font-size: 0.8rem; font-weight: bold; border-bottom-right-radius: 16px; z-index: 2; }
    .resena-item.resena-premiada > .avatar, .resena-item.resena-premiada > .resena-contenido { position: relative; z-index: 1; background-color: transparent; }
    
    .skeleton-review { display: flex; gap: 15px; padding: 20px; margin-bottom: 20px; }
    .skeleton { background-color: rgba(139, 92, 246, 0.1); background-image: linear-gradient(90deg, rgba(139, 92, 246, 0.1) 0px, rgba(139, 92, 246, 0.2) 80px, rgba(139, 92, 246, 0.1) 160px); background-size: 600px; animation: shimmer 1.8s infinite linear; }
    @keyframes shimmer { 0% { background-position: -300px 0; } 100% { background-position: 300px 0; } }
    .skeleton-avatar { width: 50px; height: 50px; border-radius: 50%; flex-shrink: 0; }
    .skeleton-line { height: 1em; border-radius: 4px; margin-bottom: 10px; }

    /* === FOOTER, MODALES & UTILIDADES === */
    footer { background: rgba(30, 30, 47, 0.9); backdrop-filter: blur(20px); padding: 40px 20px; text-align: center; color: #E5E7EB; font-size: 14px; border-top: 1px solid rgba(139, 92, 246, 0.2); position: relative; z-index: 2; margin-top: auto; transition: background 0.5s ease, color 0.5s ease; }
    .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(10px); justify-content: center; align-items: center; z-index: 2000; }
    .modal-content { background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); padding: 28px; border-radius: 18px; max-width: 420px; width: 90%; color: white; text-align: center; position: relative; border: 1px solid rgba(139, 92, 246, 0.3); animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
    @keyframes modalSlideIn { from { transform: translateY(-50px) scale(0.9); opacity: 0; } to { transform: translateY(0) scale(1); opacity: 1; } }
    .modal-content h2 { margin-bottom: 18px; font-size: 1.4rem; }
    .modal-content label { display: block; margin: 13px 0 7px; text-align: left; font-weight: 500; font-size: 0.9rem; }
    .modal-content input, .modal-content textarea, .modal-content select { width: 100%; padding: 11px; border: 1px solid rgba(139, 92, 246, 0.3); background: rgba(255, 255, 255, 0.1); border-radius: 9px; margin-bottom: 13px; color: white; transition: all 0.3s ease; font-family: inherit; }
    .modal-content input:focus, .modal-content textarea:focus, .modal-content select:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
    .modal-content button { padding: 11px 22px; border: none; border-radius: 8px; cursor: pointer; margin: 9px 4px; font-weight: 600; font-size: 0.9rem; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);}
    .modal-content button:active { transform: scale(0.95); }
    .modal-button-secondary { background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); }
    .modal-button-secondary:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
    .cerrar { position: absolute; top: 13px; right: 18px; font-size: 22px; cursor: pointer; color: #9CA3AF; transition: all 0.3s ease;}
    .cerrar:hover { color: #fff; }
    .foto-perfil-config-container { display: flex; align-items: center; gap: 13px; margin-bottom: 13px; }
    #configFotoPreview { width: 65px; height: 65px; border-radius: 50%; border: 4px solid rgba(139, 92, 246, 0.5); object-fit: cover; }
    .boton-subir-foto { background: rgba(255, 255, 255, 0.1); padding: 9px 13px; border-radius: 7px; border: 1px solid rgba(139, 92, 246, 0.3); cursor: pointer; transition: all 0.3s ease; font-weight: 500; font-size: 0.85rem; }
    .boton-subir-foto:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }

    /* === THEME SWITCH === */
    .theme-switch-wrapper { display: flex; align-items: center; gap: 13px; margin-top: 13px; margin-bottom: 20px; }
    .theme-switch { position: relative; display: inline-block; width: 55px; height: 30px; }
    .theme-switch input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 30px; }
    .slider:before { position: absolute; content: ""; height: 23px; width: 23px; left: 4px; bottom: 3.5px; background-color: white; transition: .4s; border-radius: 50%; }
    input:checked + .slider { background-color: #8B5CF6; }
    input:focus + .slider { box-shadow: 0 0 1px #8B5CF6; }
    input:checked + .slider:before { transform: translateX(24px); }

    /* === MODO CLARO === */
    body.light-mode { color: #111827; }
    body.light-mode .background-gradient { background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 25%, #f5f3ff 50%, #c4b5fd 75%, #a5b4fc 100%); }
    body.light-mode header, body.light-mode nav { background: rgba(255, 255, 255, 0.85); border-bottom-color: rgba(0, 0, 0, 0.1); }
    body.light-mode nav a, body.light-mode .nombre-usuario { color: #374151; }
    body.light-mode nav a:hover { color: #111827; }
    body.light-mode .breadcrumbs { color: #6b7280; }
    body.light-mode .breadcrumbs a { color: #6d28d9; }
    body.light-mode .usuario-menu { background: rgba(255, 255, 255, 0.95); border-color: rgba(0, 0, 0, 0.1); }
    body.light-mode .usuario-menu a { color: #1f2937; }
    body.light-mode .usuario-menu a:hover { background: rgba(139, 92, 246, 0.1); }
    body.light-mode .hero-section, body.light-mode .description-section, body.light-mode .purchase-box, 
    body.light-mode .game-info, body.light-mode .tags-section, body.light-mode .requirements-section,
    body.light-mode .resenas-section { 
        background: rgba(255, 255, 255, 0.8); border-color: rgba(0,0,0,0.1); box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    body.light-mode .hero-info h1 { color: #111827; text-shadow: 0 2px 10px rgba(109, 40, 217, 0.3); }
    body.light-mode .hero-tags .tag { background: rgba(139, 92, 246, 0.1); color: #6d28d9; border-color: rgba(139, 92, 246, 0.3); }
    body.light-mode .description-section h2, body.light-mode .requirements-section h2, body.light-mode .resenas-section h2 { color: #4c1d95; border-bottom-color: rgba(139, 92, 246, 0.3); }
    body.light-mode .description-section p, body.light-mode .features-list li, body.light-mode .info-value, 
    body.light-mode .req-column li, body.light-mode .resena-item p { color: #374151; }
    body.light-mode .info-label, body.light-mode .req-column strong, body.light-mode .features-list li:before { color: #6d28d9; }
    body.light-mode .purchase-box h3, body.light-mode .req-column h3, body.light-mode .tags-section h3, body.light-mode .resena-header .nombre { color: #111827; }
    body.light-mode .price-section { background: #f3f4f6; border-color: #e5e7eb; }
    body.light-mode .current-price-ars { color: #6d28d9; text-shadow: none; }
    body.light-mode .tag-link { background: rgba(139, 92, 246, 0.1); color: #6d28d9; border-color: rgba(139, 92, 246, 0.3); }
    body.light-mode .tag-link:hover { background: rgba(139, 92, 246, 0.2); color: #5b21b6; }
    body.light-mode #resena-texto { background: #f3f4f6; color: #111827; border-color: #d1d5db;}
    body.light-mode footer { background: rgba(255, 255, 255, 0.9); color: #4b5563; border-top-color: rgba(0, 0, 0, 0.1); }
    body.light-mode .modal-content { background: rgba(255, 255, 255, 0.98); color: #111827; border-color: rgba(0, 0, 0, 0.1); }
    body.light-mode .modal-content h2 { color: #1f2937; }
    body.light-mode .modal-content input, body.light-mode .modal-content select { background: #f3f4f6; border-color: #d1d5db; color: #111827; }
    body.light-mode .modal-content input:focus, body.light-mode .modal-content select:focus { border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
    body.light-mode .cerrar { color: #6b7280; }
    body.light-mode .cerrar:hover { color: #111827; }
    body.light-mode .boton-subir-foto { background: #f3f4f6; border-color: #d1d5db; }
    body.light-mode .carousel-arrow { background: rgba(255, 255, 255, 0.8); border-color: #d1d5db; color: #111827; }
    body.light-mode .estrella-wrapper .estrella-fondo { color: #e5e7eb; }
    body.light-mode .recomendacion-btn { background: #f3f4f6; color: #4b5563; border-color: #d1d5db; }
    body.light-mode .recomendacion-btn:hover { background: #e5e7eb; }
    body.light-mode .recomienda-btn.selected, body.light-mode .no-recomienda-btn.selected { color: white; }
    body.light-mode .recomendacion-display.recomienda { background: #d1fae5; color: #065f46; }
    body.light-mode .recomendacion-display.no-recomienda { background: #fee2e2; color: #991b1b; }
    body.light-mode .resena-item:not(.resena-premiada) { border-color: #e5e7eb; }
    body.light-mode .resena-header .nombre { color: #111827; }
    body.light-mode .accion-btn { background: rgba(139, 92, 246, 0.1); color: #6d28d9; border-color: rgba(139, 92, 246, 0.3); }
    body.light-mode .accion-btn:hover:not(:disabled) { background: rgba(139, 92, 246, 0.2); }
    body.light-mode .accion-btn.accion-activa { background: #7c3aed; color: white; border-color: #7c3aed; }
    body.light-mode .premiar-btn.accion-activa { background: #d97706; color: white; border-color: #d97706; }
    body.light-mode .resena-item.resena-premiada { background: linear-gradient(135deg, #fffbeb, #f3f4f6); border-color: #f59e0b; }
    body.light-mode .resena-item.resena-premiada::after { background: #f59e0b; color: #111827; }
    body.light-mode .eliminar-resena-btn { color: #9ca3af; }
    body.light-mode .eliminar-resena-btn:hover { color: #dc2626; }
    body.light-mode #notificacion-icono-svg { stroke: #4b5563; }
    body.light-mode #notificacionesBtn:hover #notificacion-icono-svg { stroke: #111827; filter: none; }
    body.light-mode #notificaciones-panel { background: rgba(255,255,255,0.98); border-color: #e5e7eb; }
    body.light-mode .notificacion-item { border-color: #e5e7eb; }
    
    /* === RESPONSIVE === */
    @media (max-width: 992px) { 
        .carousel-arrow { display: none; } 
        .thumbnail-carousel { padding: 0; }
        nav { 
            justify-content: flex-start; 
            overflow-x: auto; 
            -webkit-overflow-scrolling: touch; 
            padding-left: 15px;
            padding-right: 15px;
        }
        nav a {
            flex-shrink: 0;
            white-space: nowrap;
        }
        .header-left { gap: 20px; } 
        .search-container { margin-right: 0; max-width: 250px; }
        #searchInput { padding-left: 15px; background-position: 5px center; }
    }

    @media (max-width: 820px) {
        main {
            padding-top: 130px; 
            padding-left: 15px;
            padding-right: 15px;
        }
        .hero-section {
            padding: 20px; 
            height: auto; 
        }
        .hero-background {
            height: 200px; 
        }
        .hero-content {
            padding: 20px;
        }
        .hero-info h1 {
            font-size: clamp(1.8rem, 8vw, 2.5rem); 
        }

        .game-content-grid {
            grid-template-columns: 1fr; 
            gap: 30px 0;
        }
        .sidebar-section {
            position: static; 
            width: 100%;
            order: -1; 
        }
        .requirements-grid { 
            grid-template-columns: 1fr; 
            gap: 20px;
        }
        .main-media {
            margin-bottom: 10px;
        }
        .thumbnail-carousel {
            padding: 0;
        }
        .thumb {
            width: 100px;
        }
        .description-section, .requirements-section, .resenas-section {
            padding: 20px;
        }
        .game-info .info-row {
            flex-direction: column;
            align-items: flex-start;
            padding: 10px 0;
        }
        .game-info .info-label {
            margin-bottom: 5px;
            flex: none;
        }
    }
    
    @media (max-width: 576px) {
        header { padding: 10px 15px; height: 60px; }
        .header-left { gap: 10px; }
        .logo img { height: 32px; }
        nav { top: 60px; height: 45px; padding: 10px 10px; gap: 25px; }
        main { padding-top: 115px; padding-left: 10px; padding-right: 10px; }

        .search-container { display: none; }
        .header-right { gap: 10px; }
        .usuario img { width: 38px; height: 38px; }
        .nombre-usuario { display: none; }
        #notificacion-icono-svg { width: 22px; height: 22px; }

        .hero-info h1 { font-size: clamp(1.5rem, 9vw, 2rem); }
        .hero-content { padding: 15px; }

        .purchase-box { padding: 15px; }
        .discount-badge { font-size: 1.2rem; padding: 6px 10px; }
        .current-price-ars { font-size: 1.4rem; }
        .purchase-button { padding: 12px; font-size: 0.95rem; }

        .resena-item { flex-direction: column; align-items: flex-start; gap: 10px; padding: 15px; }
        .resena-item .avatar img { width: 40px; height: 40px; }
        .resena-header { flex-direction: column; align-items: flex-start; gap: 5px; margin-bottom: 5px; }
        .resena-acciones { flex-wrap: wrap; gap: 10px; margin-top: 10px; }
        .accion-btn { font-size: 0.75rem; padding: 4px 10px; }
        .eliminar-resena-btn { top: 10px; right: 10px; font-size: 1.2rem; }
    }

    @media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; } }
  </style>
</head>
<body style="background-color: #1E1B4B;">
    <?php include 'loader.php'; ?>

    <div class="page-content">
        <div class="page-background-container">
            <div class="background-gradient"></div>
            <div class="floating-shapes">
                <div class="shape"></div><div class="shape"></div><div class="shape"></div><div class="shape"></div>
            </div>
        </div>
        
        <header>
          <div class="header-left">
              <div class="logo"><a href="index.php"><img src="NJOYSINFONDO.jpeg" alt="njoy" id="logoImg" /></a></div>
          </div>
          <div class="header-right">
                <div id="notificacionesBtn">
                    <svg id="notificacion-icono-svg" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
                    </svg>
                    <span id="notificacion-alerta"></span>
                    <div id="notificaciones-panel"></div>
                </div>
                <div class="usuario" id="usuarioBtn">
                    <img src="" alt="Perfil" id="foto">
                    <span id="nombreUsuario" class="nombre-usuario"></span>
                    <div class="usuario-menu" id="usuarioMenu">
                        <a href="perfil.php">👤 Mi Perfil</a>
                        <a href="#configuracion">⚙️ Configuración</a>
                        <a href="#logout">🚪 Cerrar sesión</a>
                    </div>
                </div>
          </div>
        </header>
        
        <nav>
            <a href="index.php#recomendados-para-ti">Recomendados</a>
            <a href="index.php#ofertas">Ofertas</a>
            <a href="index.php#populares">Populares</a>
            <a href="index.php#free-to-play">Gratis</a>
            <a href="index.php#novedades">Novedades</a>
        </nav>
        
        <main>
            <div data-section>
                <div class="breadcrumbs">
                    <a href="index.php">Inicio</a> › 
                    <span><?php echo htmlspecialchars($juego['titulo']); ?></span>
                </div>

                <div class="hero-section">
                    <img class="hero-background" src="<?php echo htmlspecialchars(getAbsolutePath($main_media_image)); ?>" alt="Hero">
                    <div class="hero-content">
                        <div class="hero-info">
                            <h1><?php echo htmlspecialchars($juego['titulo']); ?></h1>
                            <div class="hero-tags">
                                <?php foreach (array_slice($tags_array, 0, 3) as $tag): if(!empty(trim($tag))): ?>
                                    <span class="tag"><?php echo htmlspecialchars(trim($tag)); ?></span>
                                <?php endif; endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="game-content-grid" data-section>
                
                <div class="main-column">
                    <div class="media-section">
                        <div class="main-media" id="main-media-player">
                            <?php if (!empty($juego['video_youtube_id'])): ?>
                                <iframe src="https://www.youtube.com/embed/<?php echo htmlspecialchars($juego['video_youtube_id']); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <?php else: ?>
                                <img src="<?php echo htmlspecialchars(getAbsolutePath($main_media_image)); ?>" alt="Gameplay">
                            <?php endif; ?>
                        </div>
                        <div class="thumbnail-carousel">
                            <button class="carousel-arrow prev" id="thumb-prev">‹</button>
                            <div class="thumbnail-strip" id="thumbnail-strip">
                                <?php if (!empty($juego['video_youtube_id'])): ?>
                                <div class="thumb active" data-type="video" data-id="<?php echo htmlspecialchars($juego['video_youtube_id']); ?>">
                                    <img src="https://img.youtube.com/vi/<?php echo htmlspecialchars($juego['video_youtube_id']); ?>/0.jpg" alt="Video Thumbnail">
                                    <div class="play-icon">▶</div>
                                </div>
                                <?php endif; ?>
                                <?php foreach ($galeria_array as $index => $img_path): if(!empty(trim($img_path))): ?>
                                <div class="thumb <?php if(empty($juego['video_youtube_id']) && $index == 0) echo 'active'; ?>" data-type="image" data-src="<?php echo htmlspecialchars(getAbsolutePath(trim($img_path))); ?>">
                                    <img src="<?php echo htmlspecialchars(getAbsolutePath(trim($img_path))); ?>" alt="thumbnail">
                                </div>
                                <?php endif; endforeach; ?>
                            </div>
                            <button class="carousel-arrow next" id="thumb-next">›</button>
                        </div>
                    </div>

                    <div class="description-section">
                        <h2>Acerca de este juego</h2>
                        <p><?php echo nl2br(htmlspecialchars($juego['descripcion_larga'])); ?></p>
                        
                        <?php if(!empty(trim($juego['caracteristicas']))): ?>
                        <h2 style="margin-top: 30px;">Características principales</h2>
                        <ul class="features-list">
                            <?php foreach ($caracteristicas_array as $caracteristica): if(!empty(trim($caracteristica))): ?>
                                <li><?php echo htmlspecialchars(trim($caracteristica)); ?></li>
                            <?php endif; endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="sidebar-column">
                    <div class="sidebar-section">
                        <div class="game-cover-box">
                            <img src="<?php echo htmlspecialchars(getAbsolutePath($juego['imagen_url'])); ?>" alt="Carátula de <?php echo htmlspecialchars($juego['titulo']); ?>">
                        </div>
                        <div class="purchase-box">
                          <h3>Comprar <?php echo htmlspecialchars($juego['titulo']); ?></h3>
                          <div class="price-section">
                            <?php
                            $precio_usd = (float)$juego['precio_final'];
                            $descuento = (int)$juego['descuento_porcentaje'];
                            $precio_ars = $precio_usd * $conversion_rate_ars;

                            if ($descuento > 0) {
                                $precio_final_ars = $precio_ars * (1 - ($descuento / 100));
                                $precio_final_usd = $precio_usd * (1 - ($descuento / 100));
                                echo '<div class="discount-badge">-' . $descuento . '%</div>';
                                echo '<div class="price-values">';
                                echo '  <div class="original-price-ars">$ ' . number_format($precio_ars, 0, ',', '.') . '</div>';
                                echo '  <div class="current-price-ars">$ ' . number_format($precio_final_ars, 0, ',', '.') . ' ARS</div>';
                                echo '  <div class="sub-price-usd">$' . number_format($precio_final_usd, 2) . ' USD</div>';
                                echo '</div>';
                            } elseif ($precio_usd == 0) {
                                echo '<div class="current-price-ars" style="text-align:center; width:100%;">Free to Play</div>';
                            } else {
                                echo '<div class="price-values" style="width: 100%;">';
                                echo '  <div class="current-price-ars">$ ' . number_format($precio_ars, 0, ',', '.') . ' ARS</div>';
                                echo '  <div class="sub-price-usd">$' . number_format($precio_usd, 2) . ' USD</div>';
                                echo '</div>';
                            }
                            ?>
                          </div>
                          <?php if($precio_usd > 0): ?>
                            <button class="purchase-button">Añadir al carrito</button>
                          <?php else: ?>
                            <button class="purchase-button" style="background: linear-gradient(135deg, #10B981, #059669);">Jugar Gratis</button>
                          <?php endif; ?>
                        </div>

                        <?php if (!empty($amigos_recomiendan)): ?>
                        <div class="game-info">
                            <h3 style="font-size: 1rem; margin-bottom: 12px; color: #e0d4ff; font-weight: 500; border-bottom: 1px solid rgba(139, 92, 246, 0.1); padding-bottom: 8px;">Amigos que recomiendan</h3>
                            <div style="display: flex; flex-direction: column; gap: 10px;">
                                <?php foreach($amigos_recomiendan as $amigo): ?>
                                <a href="perfil.php?id=<?php echo $amigo['id']; ?>" style="display: flex; align-items: center; gap: 10px; text-decoration: none;">
                                    <img src="<?php echo htmlspecialchars(getAbsolutePath($amigo['foto'])); ?>" style="width: 40px; height: 40px; border-radius: 50%;">
                                    <span style="color: #d1d5db; font-weight: 600;"><?php echo htmlspecialchars($amigo['nombre']); ?></span>
                                </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="game-info">
                          <div class="info-row"><div class="info-label">Desarrollador:</div><div class="info-value"><a href="#"><?php echo htmlspecialchars($juego['desarrollador']); ?></a></div></div>
                          <div class="info-row"><div class="info-label">Editor:</div><div class="info-value"><a href="#"><?php echo htmlspecialchars($juego['editor']); ?></a></div></div>
                          <div class="info-row"><div class="info-label">Lanzamiento:</div><div class="info-value"><?php echo htmlspecialchars($juego['fecha_lanzamiento']); ?></div></div>
                        </div>
                        <?php if(!empty($tags_array[0])): ?>
                        <div class="tags-section">
                          <h3>Etiquetas populares:</h3>
                          <div class="tags-container">
                            <?php foreach ($tags_array as $tag): if(!empty(trim($tag))): ?>
                            <a href="#" class="tag-link"><?php echo htmlspecialchars(trim($tag)); ?></a>
                            <?php endif; endforeach; ?>
                          </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(!empty(trim($juego['req_minimos']))): ?>
            <div class="requirements-section" data-section>
              <h2>Requisitos del sistema</h2>
              <div class="requirements-grid">
                <div class="req-column">
                  <h3>MÍNIMO:</h3>
                  <ul>
                    <?php foreach ($req_min_array as $req): if(!empty(trim($req))): ?>
                        <li><?php echo htmlspecialchars(trim($req)); ?></li>
                    <?php endif; endforeach; ?>
                  </ul>
                </div>
                <?php if(!empty(trim($juego['req_recomendados']))): ?>
                <div class="req-column">
                  <h3>RECOMENDADO:</h3>
                  <ul>
                    <?php foreach ($req_rec_array as $req): if(!empty(trim($req))): ?>
                        <li><?php echo htmlspecialchars(trim($req)); ?></li>
                    <?php endif; endforeach; ?>
                  </ul>
                </div>
                <?php endif; ?>
              </div>
            </div>
            <?php endif; ?>

            <div class="resenas-section" data-section>
                <h2>Reseñas de Usuarios</h2>
                <form id="form-resena">
                    <div class="calificacion-input">
                        <label>Tu calificación:</label>
                        <div class="rating-container">
                            <div id="estrellas-input" data-calificacion="0"></div>
                            <span id="calificacion-numerica">(0.0)</span>
                        </div>
                    </div>
                     <div class="recomendacion-input">
                        <label>¿Recomiendas este juego?</label>
                        <div class="recomendacion-botones">
                            <button type="button" class="recomendacion-btn recomienda-btn" data-value="recomienda">👍 Recomendar</button>
                            <button type="button" class="recomendacion-btn no-recomienda-btn" data-value="no_recomienda">👎 No recomendar</button>
                        </div>
                    </div>
                    <textarea id="resena-texto" placeholder="Escribe tu reseña aquí..."></textarea>
                    <button type="submit" id="enviar-resena">Enviar Reseña</button>
                </form>
                <div id="lista-resenas"></div>
            </div>

        </main>
        
        <footer>
            <p>© 2025 NJOY - Tu tienda de videojuegos. Todos los derechos reservados.</p>
        </footer>

    </div> <!-- Cierre de .page-content -->

    <!-- MODALES COMPLETOS Y ACTUALIZADOS -->
    <div class="modal" id="modalLogout">
        <div class="modal-content">
          <span class="cerrar" data-close="modalLogout">&times;</span>
          <h2>🚪 Cerrar sesión</h2>
          <p>¿Estás seguro de que deseas cerrar sesión?</p>
          <button id="confirmarLogout" style="background: #ef4444;">Sí, cerrar sesión</button>
          <button id="cancelarLogout" class="modal-button-secondary">Cancelar</button>
        </div>
    </div>

    <div class="modal" id="modalConfig">
        <div class="modal-content">
          <span class="cerrar" data-close="modalConfig">&times;</span>
          <h2>⚙️ Configuración</h2>
          
          <label>Modo de visualización:</label>
          <div class="theme-switch-wrapper">
            <label class="theme-switch" for="theme-toggle"><input type="checkbox" id="theme-toggle" /><span class="slider"></span></label>
            <span id="theme-label-text">Modo Oscuro</span>
          </div>
          
          <button id="guardarConfig" style="background: #8B5CF6; width: 100%;">Guardar cambios</button>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // ===================================================================
    // INICIO DE ANIMACIONES Y EFECTOS
    // ===================================================================
    const sections = document.querySelectorAll('[data-section]');
    const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
    const sectionObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                entry.target.style.transitionDelay = `${index * 150}ms`;
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    sections.forEach(section => sectionObserver.observe(section));
    
    // ===================================================================
    // FIN DE ANIMACIONES Y EFECTOS
    // ===================================================================

    let currentUserData = { nombre: '', foto: '' };
    const fotoPerfil = document.getElementById("foto");
    const nombreUsuarioSpan = document.getElementById("nombreUsuario");
    const usuarioBtn = document.getElementById("usuarioBtn");
    const usuarioMenu = document.getElementById("usuarioMenu");
    const juegoId = <?php echo $juego_id; ?>;

    function getAbsolutePath(path) {
        if (path && !path.startsWith('/') && !path.startsWith('http')) { return '/' + path; }
        return path;
    }

    if (usuarioBtn) {
        usuarioBtn.addEventListener("click", (e) => { e.stopPropagation(); usuarioMenu.style.display = usuarioMenu.style.display === "block" ? "none" : "block"; });
    }
    document.addEventListener("click", (e) => {
        const target = e.target;
        if (usuarioMenu && usuarioMenu.style.display === "block" && !usuarioMenu.contains(target) && !usuarioBtn.contains(target)) {
            usuarioMenu.style.display = "none";
        }
    });

    fetch(`obtener_datos_usuario.php?v=${new Date().getTime()}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === "ok") {
                currentUserData = data;
                const fotoUrl = getAbsolutePath(data.foto) + "?t=" + new Date().getTime();
                fotoPerfil.src = fotoUrl;
                nombreUsuarioSpan.textContent = data.nombre;
            }
        });
        
    const modalConfig = document.getElementById('modalConfig');
    const modalLogout = document.getElementById('modalLogout');
    document.querySelectorAll(".usuario-menu a").forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();
            const href = link.getAttribute("href");
            if (href === "#configuracion") {
                modalConfig.style.display = 'flex';
            } else if (href === "#logout") {
                modalLogout.style.display = 'flex';
            } else {
                window.location.href = href;
            }
            usuarioMenu.style.display = 'none';
        });
    });

    document.querySelectorAll(".cerrar, [data-close], #cancelarLogout").forEach(el => {
        el.addEventListener("click", () => el.closest('.modal').style.display = "none");
    });
    document.querySelectorAll(".modal").forEach(modal => {
        modal.addEventListener("click", e => { if (e.target === modal) modal.style.display = "none"; });
    });
    document.getElementById("confirmarLogout").addEventListener("click", () => {
        fetch('logout.php', { method: 'POST' }).finally(() => window.location.replace('index.php'));
    });

    document.getElementById('guardarConfig').addEventListener('click', () => {
        modalConfig.style.display = 'none';
    });

    const themeToggle = document.getElementById('theme-toggle');
    const logoImg = document.getElementById('logoImg');
    if(themeToggle) {
        const themeLabel = document.getElementById('theme-label-text');
        function setTheme(theme) {
          document.body.classList.toggle('light-mode', theme === 'light');
          themeToggle.checked = (theme === 'light');
          if (themeLabel) themeLabel.textContent = (theme === 'light') ? 'Modo Claro' : 'Modo Oscuro';
          if(logoImg) logoImg.src = (theme === 'light') ? 'NJOY_LOGO_CLARO.jpeg' : 'NJOYSINFONDO.jpeg';
        }
        themeToggle.addEventListener('change', () => {
          const newTheme = themeToggle.checked ? 'light' : 'dark';
          localStorage.setItem('theme', newTheme);
          setTheme(newTheme);
        });
        const savedTheme = localStorage.getItem('theme') || 'dark';
        setTheme(savedTheme);
    }

    const notificacionesBtn = document.getElementById('notificacionesBtn');
    const notificacionesPanel = document.getElementById('notificaciones-panel');
    const notificacionAlerta = document.getElementById('notificacion-alerta');
    
    function checkUnreadNotifications() {
        fetch('/api.php?action=get_notifications')
            .then(res => res.json())
            .then(data => {
                if(data.status === 'ok' && data.unread_count > 0) {
                    notificacionAlerta.style.display = 'block';
                } else {
                    notificacionAlerta.style.display = 'none';
                }
            });
    }

    function cargarNotificaciones() {
        if(!notificacionesPanel) return;

        fetch('/api.php?action=get_notifications')
            .then(res => res.json())
            .then(data => {
                if (data.status === 'ok') {
                    notificacionesPanel.innerHTML = '';
                    if (data.notificaciones.length > 0) {
                         data.notificaciones.forEach(notif => {
                            const profileLink = `perfil.php?id=${notif.usuario_origen_id}`;
                            const userLink = `<a href="${profileLink}"><b>${notif.origen_nombre}</b></a>`;
                            let texto = '';
                            let acciones = '';
                            switch(notif.tipo_notificacion) {
                                case 'SOLICITUD_AMISTAD':
                                    texto = `${userLink} quiere ser tu amigo.`;
                                    acciones = `<div class="notificacion-acciones">
                                        <button class="notif-action-btn accept" data-action="aceptar" data-solicitante-id="${notif.usuario_origen_id}">Aceptar</button>
                                        <button class="notif-action-btn reject" data-action="rechazar" data-solicitante-id="${notif.usuario_origen_id}">Rechazar</button>
                                    </div>`;
                                    break;
                                case 'SOLICITUD_ACEPTADA':
                                    texto = `Ahora eres amigo de ${userLink}.`;
                                    break;
                                case 'AMISTAD_CONFIRMADA':
                                    texto = `Has aceptado la solicitud de amistad de ${userLink}.`;
                                    break;
                                case 'AMISTAD_RECHAZADA':
                                    texto = `Has rechazado la solicitud de amistad de ${userLink}.`;
                                    break;
                                default:
                                    texto = `${userLink} ha interactuado contigo.`;
                            }
                            const notifHtml = `
                            <div class="notificacion-item ${notif.leido == 0 ? 'no-leida' : ''}" data-notif-id="${notif.id}">
                                <a href="${profileLink}"><img src="${notif.origen_foto}" alt="Avatar" class="notificacion-avatar"></a>
                                <div class="notificacion-contenido">
                                    <p>${texto}</p>
                                    ${acciones}
                                </div>
                            </div>`;
                            notificacionesPanel.innerHTML += notifHtml;
                        });
                    } else {
                        notificacionesPanel.innerHTML = '<p style="padding: 15px; text-align:center;">No tienes notificaciones.</p>';
                    }
                }
            });
    }

    if(notificacionesBtn) {
        notificacionesBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isVisible = notificacionesPanel.style.display === 'block';
            notificacionesPanel.style.display = isVisible ? 'none' : 'block';
            if (!isVisible) {
                cargarNotificaciones();
                setTimeout(() => {
                    fetch('/api.php?action=mark_notifications_read', { method: 'POST' })
                        .then(res => res.json())
                        .then(data => {
                            if(data.status === 'ok' && data.affected_rows > 0) {
                                notificacionAlerta.style.display = 'none';
                                notificacionesPanel.querySelectorAll('.no-leida').forEach(item => item.classList.remove('no-leida'));
                            }
                        });
                }, 2500);
            }
        });
    }

    if(notificacionesPanel) {
        notificacionesPanel.addEventListener('click', e => {
            e.stopPropagation();
            const target = e.target;
            if(target.classList.contains('notif-action-btn')) {
                const accion = target.dataset.action;
                const solicitanteId = target.dataset.solicitanteId;
                const notifItemContent = target.closest('.notificacion-contenido');

                const formData = new FormData();
                formData.append('solicitante_id', solicitanteId);
                formData.append('accion', accion);

                fetch('gestionar_solicitud.php', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'ok') {
                            cargarNotificaciones();
                        } else {
                            notifItemContent.innerHTML = `<p class="notif-feedback" style="color: #fca5a5;">${data.msg || 'Error al procesar.'}</p>`;
                        }
                    });
            }
        });
        document.addEventListener('click', (e) => {
            if (notificacionesPanel.style.display === 'block' && !notificacionesBtn.contains(e.target)) {
                notificacionesPanel.style.display = 'none';
            }
        });
    }
    
    checkUnreadNotifications();
    
    const mainMediaContainer = document.getElementById('main-media-player');
    const thumbs = document.querySelectorAll('.thumb');
    
    if (mainMediaContainer && thumbs.length > 0) {
        thumbs.forEach(thumb => {
            thumb.addEventListener('click', () => {
                thumbs.forEach(t => t.classList.remove('active'));
                thumb.classList.add('active');
                const type = thumb.dataset.type;
                if (type === 'video') {
                    mainMediaContainer.innerHTML = `<iframe src="https://www.youtube.com/embed/${thumb.dataset.id}?autoplay=1&rel=0" allowfullscreen></iframe>`;
                } else if (type === 'image') {
                    mainMediaContainer.innerHTML = `<img src="${thumb.dataset.src}" alt="Gameplay Screenshot">`;
                }
            });
        });
    }

    const thumbStrip = document.getElementById('thumbnail-strip');
    const prevBtn = document.getElementById('thumb-prev');
    const nextBtn = document.getElementById('thumb-next');
    if (thumbStrip) {
        const scrollAmount = thumbStrip.clientWidth * 0.8;
        prevBtn.addEventListener('click', () => thumbStrip.scrollBy({ left: -scrollAmount, behavior: 'smooth' }));
        nextBtn.addEventListener('click', () => thumbStrip.scrollBy({ left: scrollAmount, behavior: 'smooth' }));
    }

    const formResena = document.getElementById('form-resena');
    const estrellasContainer = document.getElementById('estrellas-input');
    const calificacionNumericaSpan = document.getElementById('calificacion-numerica');
    const resenaTexto = document.getElementById('resena-texto');
    const listaResenas = document.getElementById('lista-resenas');

    const actualizarEstrellas = (valor) => {
        if (!estrellasContainer) return;
        const wrappers = estrellasContainer.querySelectorAll('.estrella-wrapper');
        wrappers.forEach((wrapper, index) => {
            const estrellaValor = index + 1;
            const relleno = wrapper.querySelector('.estrella-relleno');
            if (valor >= estrellaValor) relleno.style.width = '100%';
            else if (valor > index && valor < estrellaValor) relleno.style.width = '50%';
            else relleno.style.width = '0%';
        });
        if (calificacionNumericaSpan) calificacionNumericaSpan.textContent = `(${valor.toFixed(1)})`;
    };

    if (estrellasContainer) {
        estrellasContainer.className = 'estrellas-rediseñadas';
        for (let i = 1; i <= 5; i++) {
            const wrapper = document.createElement('div');
            wrapper.className = 'estrella-wrapper';
            wrapper.innerHTML = `
                <span class="estrella-fondo">★</span>
                <span class="estrella-relleno">★</span>
                <div class="interaccion-mitad izquierda" data-value="${i - 0.5}"></div>
                <div class="interaccion-mitad derecha" data-value="${i}"></div>`;
            estrellasContainer.appendChild(wrapper);
        }
        estrellasContainer.addEventListener('mouseover', e => { if (e.target.classList.contains('interaccion-mitad')) actualizarEstrellas(parseFloat(e.target.dataset.value)); });
        estrellasContainer.addEventListener('mouseleave', () => actualizarEstrellas(parseFloat(estrellasContainer.dataset.calificacion) || 0));
        estrellasContainer.addEventListener('click', e => {
            if (e.target.classList.contains('interaccion-mitad')) {
                const val = parseFloat(e.target.dataset.value);
                estrellasContainer.dataset.calificacion = val;
                actualizarEstrellas(val);
            }
        });
        actualizarEstrellas(parseFloat(estrellasContainer.dataset.calificacion) || 0);
    }

    if (formResena) {
        const recomendacionContainer = formResena.querySelector('.recomendacion-botones');
        if (recomendacionContainer) {
            recomendacionContainer.addEventListener('click', e => {
                const button = e.target.closest('.recomendacion-btn');
                if (!button) return;
                const value = button.dataset.value;
                formResena.dataset.recomendacion = value;
                recomendacionContainer.querySelectorAll('.recomendacion-btn').forEach(btn => btn.classList.remove('selected'));
                button.classList.add('selected');
            });
        }

        formResena.addEventListener('submit', e => {
            e.preventDefault();
            const submitBtn = document.getElementById('enviar-resena');
            const calificacion = parseFloat(estrellasContainer.dataset.calificacion) || 0;
            const comentario = resenaTexto.value.trim();
            const recomendacion = formResena.dataset.recomendacion;

            if (calificacion === 0) { alert('Por favor, selecciona una calificación.'); return; }
            if (!recomendacion) { alert('Por favor, indica si recomiendas o no el juego.'); return; }

            submitBtn.disabled = true;
            submitBtn.textContent = 'Enviando...';

            const formData = new FormData();
            formData.append('juego_id', juegoId);
            formData.append('calificacion', calificacion);
            formData.append('comentario', comentario);
            formData.append('recomendacion', recomendacion);

            fetch('guardar_resena.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'ok') {
                        resenaTexto.value = '';
                        estrellasContainer.dataset.calificacion = 0;
                        actualizarEstrellas(0);
                        delete formResena.dataset.recomendacion;
                        if(recomendacionContainer) {
                            recomendacionContainer.querySelectorAll('.recomendacion-btn').forEach(btn => btn.classList.remove('selected'));
                        }
                        cargarResenas();
                    } else { alert(data.msg); }
                }).catch(error => console.error('FALLO CRÍTICO al guardar la reseña:', error))
                .finally(() => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Enviar Reseña';
                });
        });
    }

    function generarEstrellasHTML(calificacion) {
        let html = '';
        for (let i = 1; i <= 5; i++) {
            if (calificacion >= i) html += '★';
            else if (calificacion >= i - 0.5) html += '½';
            else html += '☆';
        }
        return `<div class="estrellas-display">${html}</div>`;
    }

    function renderReviewSkeleton() {
        let skeletonHTML = '';
        for (let i = 0; i < 2; i++) {
            skeletonHTML += `
            <div class="skeleton-review">
                <div class="skeleton skeleton-avatar"></div>
                <div style="flex-grow: 1;">
                    <div class="skeleton skeleton-line" style="width: 30%; margin-bottom: 15px;"></div>
                    <div class="skeleton skeleton-line"></div>
                    <div class="skeleton skeleton-line" style="width: 85%;"></div>
                </div>
            </div>`;
        }
        if(listaResenas) listaResenas.innerHTML = skeletonHTML;
    }

    function cargarResenas() {
        if (!listaResenas) return;
        renderReviewSkeleton();

        fetch(`obtener_resenas.php?juego_id=${juegoId}&v=${new Date().getTime()}`)
            .then(response => response.json())
            .then(data => {
                const usuarioActualId = data.usuario_actual_id;
                listaResenas.innerHTML = '';
                if (data.lista && data.lista.length > 0) {
                    data.lista.forEach((r, index) => {
                        const esMiResena = (usuarioActualId !== 0 && parseInt(usuarioActualId) === parseInt(r.usuario_id));
                        const esPremiada = (index === 0 && r.premios > 0);
                        const clasePremiada = esPremiada ? 'resena-premiada' : '';
                        const likeActivo = r.usuario_dio_like > 0 ? 'accion-activa' : '';
                        const dislikeActivo = r.usuario_dio_dislike > 0 ? 'accion-activa' : '';
                        const premioActivo = r.usuario_dio_premio > 0 ? 'accion-activa' : '';
                        const deshabilitadoPremio = esMiResena ? 'disabled' : '';

                        let recomendacionHtml = '';
                        if (r.recomendacion === 'recomienda') {
                            recomendacionHtml = `<span class="recomendacion-display recomienda">👍 Recomienda este juego</span>`;
                        } else if (r.recomendacion === 'no_recomienda') {
                            recomendacionHtml = `<span class="recomendacion-display no-recomienda">👎 No recomienda este juego</span>`;
                        }
                        
                        listaResenas.innerHTML += `
                            <div class="resena-item ${clasePremiada}" data-resena-id="${r.id}">
                                ${esMiResena ? `<button class="eliminar-resena-btn" data-resena-id="${r.id}" title="Eliminar mi reseña">&times;</button>` : ''}
                                <a href="perfil.php?id=${r.usuario_id}" class="avatar"><img src="${getAbsolutePath(r.foto) + "?t=" + new Date().getTime()}" alt="${r.nombre}"></a>
                                <div class="resena-contenido">
                                    <div class="resena-header">
                                        <a href="perfil.php?id=${r.usuario_id}" class="nombre">${r.nombre}</a>
                                        ${generarEstrellasHTML(parseFloat(r.calificacion))}
                                        ${recomendacionHtml}
                                    </div>
                                    <p>${r.comentario ? r.comentario.replace(/\n/g, '<br>') : '<em>No hay comentario.</em>'}</p>
                                    <div class="resena-acciones">
                                        <button class="accion-btn like-btn ${likeActivo}" data-action="like">👍 <span class="count likes-count">${r.likes}</span></button>
                                        <button class="accion-btn dislike-btn ${dislikeActivo}" data-action="dislike">👎 <span class="count dislikes-count">${r.dislikes}</span></button>
                                        <button class="accion-btn premiar-btn ${premioActivo}" data-action="premio" ${deshabilitadoPremio}>🏆 Premiar <span class="count premios-count">${r.premios}</span></button>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                }
            }).catch(error => console.error('Fallo al cargar reseñas:', error));
    }

    if (listaResenas) {
        listaResenas.addEventListener('click', function(e) {
            const accionBtn = e.target.closest('.accion-btn');
            if (accionBtn && !accionBtn.disabled) {
                const resenaItem = accionBtn.closest('.resena-item');
                const resenaId = resenaItem.dataset.resena-id;
                const action = accionBtn.dataset.action;
                const formData = new FormData();
                formData.append('resena_id', resenaId);
                formData.append('action', action);

                fetch('interactuar_resena.php', { method: 'POST', body: formData })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'ok') {
                            resenaItem.querySelector('.likes-count').textContent = data.newCounts.likes;
                            resenaItem.querySelector('.dislikes-count').textContent = data.newCounts.dislikes;
                            resenaItem.querySelector('.premios-count').textContent = data.newCounts.premios;

                            const interactions = data.userInteractions;
                            resenaItem.querySelector('.like-btn').classList.toggle('accion-activa', interactions.like);
                            resenaItem.querySelector('.dislike-btn').classList.toggle('accion-activa', interactions.dislike);
                            resenaItem.querySelector('.premiar-btn').classList.toggle('accion-activa', interactions.premio);

                            let maxPremios = -1;
                            let newTopReviewElement = null;
                            const allReviews = listaResenas.querySelectorAll('.resena-item');

                            allReviews.forEach(review => {
                                const currentPremios = parseInt(review.querySelector('.premios-count').textContent, 10);
                                if (currentPremios >= maxPremios) {
                                    maxPremios = currentPremios;
                                    newTopReviewElement = review;
                                }
                            });
                            
                            allReviews.forEach(review => {
                                review.classList.remove('resena-premiada');
                            });
                            
                            if (newTopReviewElement && maxPremios > 0) {
                                newTopReviewElement.classList.add('resena-premiada');
                                if (listaResenas.firstChild !== newTopReviewElement) {
                                    listaResenas.prepend(newTopReviewElement);
                                }
                            }
                            
                        } else { 
                            alert(data.msg); 
                        }
                    })
                    .catch(error => console.error('Error en la interacción:', error));
            }

            const eliminarBtn = e.target.closest('.eliminar-resena-btn');
            if (eliminarBtn) {
                const resenaId = eliminarBtn.dataset.resena-id;
                if (confirm('¿Estás seguro de que quieres eliminar tu reseña? Esta acción no se puede deshacer.')) {
                    const formData = new FormData();
                    formData.append('resena_id', resenaId);
                    
                    fetch('eliminar_resena.php', { method: 'POST', body: formData })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'ok') {
                                cargarResenas();
                            } else { alert('Error: ' + data.msg); }
                        })
                        .catch(error => console.error('Error al eliminar la reseña:', error));
                }
            }
        });
    }

    cargarResenas();
});

// --- CORRECCIÓN FINAL DEL LOADER ---
window.addEventListener('load', function() {
    const loader = document.getElementById('loader');
    const pageContent = document.querySelector('.page-content');
    
    if (loader) { 
        loader.classList.add('hidden'); 
    }
    if (pageContent) {
        pageContent.classList.add('loaded');
    }
});
</script>

</body>
</html>