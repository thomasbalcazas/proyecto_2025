<?php
// Usar las clases de PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar el autoloader de Composer
require 'vendor/autoload.php';

// Establecer la cabecera de respuesta como JSON
header('Content-Type: application/json');

// Función para enviar respuestas JSON y terminar el script
function json_response($success, $message) {
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

// --- CONFIGURACIÓN ---
// Base de datos (reemplaza con tus datos de Hostinger)
$db_host = '127.0.0.1:3306';
$db_user = 'u651705570_njoy';
$db_pass = 'Njoy2025';
$db_name = 'u651705570_njoy';

// Configuración de correo (obtenla de tu cuenta de correo en Hostinger)
$smtp_host = 'smtp.hostinger.com';
$smtp_user = 'ticketsupport@njoy3077.shop'; // El correo que creaste en Hostinger
$smtp_pass = 'Github.com24092006*';
$smtp_port = 465; // Usualmente 465 para SSL o 587 para TLS

// --- LÓGICA DEL SCRIPT ---

// 1. Leer el JSON enviado desde el JavaScript
$json_data = file_get_contents('php://input');
$data = json_decode($json_data);

// Validar que se recibió el email
if (!$data || !isset($data->email)) {
    json_response(false, '❌ No se proporcionó un correo electrónico.');
}

// 2. Limpiar y validar el correo electrónico
$email = filter_var(trim($data->email), FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(false, '❌ El formato del correo electrónico no es válido.');
}

// 3. Conectar a la base de datos
$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_error) {
    // No mostrar el error real en producción por seguridad
    json_response(false, '❌ Error de conexión con el servidor.');
}

// 4. Verificar si el correo existe en la base de datos (usando sentencias preparadas)
$stmt = $mysqli->prepare("SELECT id FROM usuarios WHERE correo_electronico = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// IMPORTANTE: Por seguridad, siempre enviaremos un mensaje de éxito,
// exista o no el correo, para evitar que alguien pueda adivinar qué correos están registrados.
if ($result->num_rows > 0) {
    // 5. El usuario existe, generar un token seguro
    $token = bin2hex(random_bytes(32)); // Token de 64 caracteres
    $expiracion = date('Y-m-d H:i:s', time() + 3600); // Token válido por 1 hora

    // 6. Almacenar el token y la fecha de expiración en la base de datos
    $update_stmt = $mysqli->prepare("UPDATE usuarios SET token = ?, token_expiracion = ? WHERE correo_electronico = ?");
    $update_stmt->bind_param("sss", $token, $expiracion, $email);
    
    if ($update_stmt->execute()) {
        // 7. Enviar el correo electrónico con PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Configuración del servidor SMTP
            $mail->isSMTP();
            $mail->Host       = smtp.hostinger.com;
            $mail->SMTPAuth   = true;
            $mail->Username   = ticketsupport@njoy3077.shop;
            $mail->Password   = Github.com24092006*;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = $465;

            // Remitente y destinatario
            $mail->setFrom($smtp_user, 'Soporte NJOY'); // Puedes cambiar 'Soporte NJOY'
            $mail->addAddress($email);

            // Contenido del correo
            $mail->isHTML(true);
            $mail->Subject = 'Restablecimiento de tu contraseña en NJOY';
            $enlace_recuperacion = "https://tudominio.com/restablecer_contrasena.php?token=" . $token;
            $mail->Body    = "Hola,<br><br>Has solicitado restablecer tu contraseña. Haz clic en el siguiente enlace para continuar:<br><br>"
                           . "<a href='{$enlace_recuperacion}'>Restablecer mi contraseña</a><br><br>"
                           . "Si no solicitaste esto, puedes ignorar este correo de forma segura.<br><br>"
                           . "Saludos,<br>El equipo de NJOY";
            $mail->AltBody = "Hola, has solicitado restablecer tu contraseña. Copia y pega el siguiente enlace en tu navegador: {$enlace_recuperacion}";

            $mail->send();
            
        } catch (Exception $e) {
            // No se pudo enviar el correo, pero no informamos al usuario para mantener la seguridad
            // Opcional: Registrar el error en un archivo de log del servidor
            // error_log("PHPMailer Error: " . $mail->ErrorInfo);
        }
    }
}

// 8. Cerrar conexiones
$stmt->close();
$mysqli->close();

// 9. Enviar respuesta de éxito genérica
json_response(true, '✅ Si existe una cuenta con ese correo, hemos enviado las instrucciones para restablecer la contraseña.');

?>