<?php
// api.php
header('Content-Type: application/json');
session_start();
require_once 'db.php';
require_once 'social_system.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'No autenticado']);
    exit();
}

$usuario_actual_id = (int)$_SESSION['usuario_id'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_feed':
        $stmt_amigos = $conn->prepare("SELECT IF(usuario1_id = ?, usuario2_id, usuario1_id) AS amigo_id FROM amigos WHERE (usuario1_id = ? OR usuario2_id = ?) AND estado = 'aceptada'");
        $stmt_amigos->bind_param("iii", $usuario_actual_id, $usuario_actual_id, $usuario_actual_id);
        $stmt_amigos->execute();
        $result_amigos = $stmt_amigos->get_result();
        $amigos_ids = [$usuario_actual_id]; // Incluir la propia actividad
        while ($row = $result_amigos->fetch_assoc()) {
            $amigos_ids[] = $row['amigo_id'];
        }
        $stmt_amigos->close();

        $feed_items = [];
        if (!empty($amigos_ids)) {
            $amigos_ids_str = implode(',', array_map('intval', $amigos_ids));
            $sql_feed = "SELECT a.*, u.nombre, u.foto FROM actividad a JOIN usuarios u ON a.usuario_id = u.id WHERE a.usuario_id IN ($amigos_ids_str) ORDER BY a.timestamp DESC LIMIT 30";
            $feed_items_result = $conn->query($sql_feed);
            if($feed_items_result) {
                $feed_items = $feed_items_result->fetch_all(MYSQLI_ASSOC);
            }
            
            // Enriquecer los datos con información contextual
            foreach($feed_items as &$item) {
                $ref_id = (int) $item['referencia_id'];
                if (!$ref_id) continue; // Si no hay ID de referencia, saltar

                if ($item['tipo_actividad'] === 'NUEVA_RESENA' || $item['tipo_actividad'] === 'ELIMINO_RESENA') {
                    $stmt_juego = $conn->prepare("SELECT titulo, pagina_url FROM juegos WHERE id = ?");
                    $stmt_juego->bind_param("i", $ref_id);
                    $stmt_juego->execute();
                    $item['juego'] = $stmt_juego->get_result()->fetch_assoc();
                    $stmt_juego->close();
                }
                
                if ($item['tipo_actividad'] === 'NUEVO_AMIGO') {
                    $stmt_amigo = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
                    $stmt_amigo->bind_param("i", $ref_id);
                    $stmt_amigo->execute();
                    $item['amigo'] = $stmt_amigo->get_result()->fetch_assoc();
                    $stmt_amigo->close();
                }

                // --- INICIO DE LA ACTUALIZACIÓN ---
                // Si la actividad es un comentario en un perfil, obtener el nombre del dueño del perfil.
                if ($item['tipo_actividad'] === 'NUEVO_COMENTARIO_PERFIL') {
                    $stmt_perfil = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
                    $stmt_perfil->bind_param("i", $ref_id);
                    $stmt_perfil->execute();
                    $item['perfil_comentado'] = $stmt_perfil->get_result()->fetch_assoc();
                    $stmt_perfil->close();
                }
                // --- FIN DE LA ACTUALIZACIÓN ---
            }
        }
        echo json_encode(['status' => 'ok', 'feed' => $feed_items]);
        break;

    case 'get_notifications':
        $sql = "SELECT n.*, u.nombre AS origen_nombre, u.foto AS origen_foto FROM notificaciones n JOIN usuarios u ON n.usuario_origen_id = u.id WHERE n.usuario_destino_id = ? ORDER BY n.timestamp DESC LIMIT 50";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $usuario_actual_id);
        $stmt->execute();
        $notificaciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // --- MEJORA DE SEGURIDAD ---
        $stmt_unread = $conn->prepare("SELECT COUNT(id) as total FROM notificaciones WHERE usuario_destino_id = ? AND leido = 0");
        $stmt_unread->bind_param("i", $usuario_actual_id);
        $stmt_unread->execute();
        $unread_count_res = $stmt_unread->get_result()->fetch_assoc();
        $stmt_unread->close();
        
        echo json_encode(['status' => 'ok', 'notificaciones' => $notificaciones, 'unread_count' => (int)$unread_count_res['total']]);
        break;

    case 'mark_notifications_read':
        $stmt = $conn->prepare("UPDATE notificaciones SET leido = 1 WHERE usuario_destino_id = ? AND leido = 0");
        $stmt->bind_param("i", $usuario_actual_id);
        $stmt->execute();
        echo json_encode(['status' => 'ok', 'affected_rows' => $stmt->affected_rows]);
        break;
}
$conn->close();
?>