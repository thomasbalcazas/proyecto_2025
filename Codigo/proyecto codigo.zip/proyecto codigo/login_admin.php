<?php
session_start();
// Si el admin ya ha iniciado sesión, que lo mande directo al panel
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login de Administrador</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #1A1A2E; color: #E0E7FF; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-container { background-color: #16213E; padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3); width: 100%; max-width: 400px; }
        h1 { text-align: center; color: #FFFFFF; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #A5B4FC; }
        .form-input { width: 100%; padding: 0.8rem 1rem; background-color: #1A1A2E; border: 2px solid #312E81; border-radius: 8px; color: #E0E7FF; font-size: 1rem; transition: all 0.3s ease; }
        .form-input:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.25); }
        .submit-btn { width: 100%; padding: 1rem; background: linear-gradient(90deg, #8B5CF6, #6366F1); color: #FFFFFF; border: none; border-radius: 8px; font-size: 1.1rem; font-weight: 700; cursor: pointer; transition: all 0.3s ease; }
        .submit-btn:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(139, 92, 246, 0.3); }
        /* ---- ESTE ES EL ESTILO PARA EL MENSAJE DE ERROR ---- */
        .error-message { color: #EF4444; background-color: rgba(239, 68, 68, 0.1); border: 1px solid #EF4444; padding: 0.8rem; border-radius: 8px; text-align: center; margin-bottom: 1.5rem; }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Acceso al Panel</h1>
        
        <?php
        // ---- ESTE CÓDIGO PHP MUESTRA EL MENSAJE DE ERROR ----
        // Comprueba si en la URL existe la señal "error"
        if (isset($_GET['error'])) {
            echo '<div class="error-message">Usuario o contraseña incorrectos.</div>';
        }
        ?>

        <form action="admin_login_process.php" method="post">
            <div class="form-group">
                <label for="username">Usuario</label>
                <input type="text" id="username" name="username" class="form-input" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" class="form-input" required>
            </div>
            <button type="submit" class="submit-btn">Entrar</button>
        </form>
    </div>
</body>
</html>