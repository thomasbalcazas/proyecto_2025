<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

// 1. Comprobar si hay una sesión activa y guardar el estado en una variable
$usuario_logueado = isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
$nombre_usuario = ''; // Inicializar la variable de nombre

require_once 'db.php';

// Si el usuario está logueado, obtener su nombre para mostrarlo en el header
if ($usuario_logueado) {
    $stmt = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['usuario_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $nombre_usuario = $row['nombre'];
    }
    $stmt->close();
}

// 3. Prevenir caché del navegador
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// === INICIO DE LA AUTOMATIZACIÓN DE PRECIO ARS ===

/**
 * Obtiene la tasa de conversión actualizada de USD a ARS, usando un sistema de caché.
 * @return float La tasa de conversión.
 */
function get_ars_conversion_rate() {
    $apiKey = 'd6cd4770cf766bd3beb9cef2'; // <-- ¡IMPORTANTE! Pega la clave que obtuviste.
    $cacheFile = 'exchange_rate_cache.json';
    $cacheTime = 86400; // Tiempo en segundos para mantener el caché (24 horas)
    $fallbackRate = 1400; // Un valor de respaldo por si la API falla.

    // 1. Comprobar si el archivo de caché existe y es reciente
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTime) {
        $cache = json_decode(file_get_contents($cacheFile), true);
        if (isset($cache['rate'])) {
            return $cache['rate'];
        }
    }

    // 2. Si el caché no es válido, llamar a la API
    $apiUrl = "https://v6.exchangerate-api.com/v6/{$apiKey}/latest/USD";
    
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if ($data && $data['result'] === 'success' && isset($data['conversion_rates']['ARS'])) {
            $rate = $data['conversion_rates']['ARS'];
            
            // 3. Guardar el nuevo valor y la fecha en el archivo de caché
            $newCache = ['rate' => $rate, 'timestamp' => time()];
            file_put_contents($cacheFile, json_encode($newCache));
            
            return $rate;
        }
    }

    // 4. Si la API falla, intentar usar un caché antiguo si existe
    if (file_exists($cacheFile)) {
        $cache = json_decode(file_get_contents($cacheFile), true);
        if (isset($cache['rate'])) {
            return $cache['rate']; // Devolver el valor antiguo
        }
    }

    // 5. Como último recurso, devolver el valor de respaldo
    return $fallbackRate;
}

// Obtenemos la tasa de conversión una sola vez por carga de página.
$conversion_rate_ars = get_ars_conversion_rate();

// === FIN DE LA AUTOMATIZACIÓN ===


/**
 * Función que genera el bloque HTML para una tarjeta de juego en carrusel.
 * @param array $juego Un array asociativo con los datos del juego desde la BD.
 */
function generarJuegoHTML($juego) {
    global $conversion_rate_ars; // Hacemos accesible la variable de conversión

    $id = htmlspecialchars($juego['id']);
    $titulo = htmlspecialchars($juego['titulo']);
    $imagen_url = htmlspecialchars($juego['imagen_url']);
    $pagina_url = !empty($juego['pagina_url']) ? htmlspecialchars($juego['pagina_url']) : '#';
    $precio_original_usd = (float)$juego['precio_final'];
    $descuento = (int)$juego['descuento_porcentaje'];
    $es_proximamente = (bool)($juego['es_proximamente'] ?? false);

    $precio_original_ars = $precio_original_usd * $conversion_rate_ars;

    $html_precio = '';
    if ($es_proximamente) {
        $html_precio = '<p class="precio proximamente-label">Próximamente</p>';
    } else if ($precio_original_usd == 0 && $descuento == 0) {
        $html_precio = '<p class="precio">Free to Play</p>';
    } else if ($descuento > 0) {
        $precio_final_calculado_ars = $precio_original_ars * (1 - ($descuento / 100));
        $precio_final_calculado_usd = $precio_original_usd * (1 - ($descuento / 100));
        
        $html_precio =
            '<span class="descuento">-' . $descuento . '%</span>' .
            '<div class="precio-bloque-descuento">' .
                '<span class="precio-original">$ ' . number_format($precio_original_ars, 0, ',', '.') . '</span>' .
                '<p class="precio">$ ' . number_format($precio_final_calculado_ars, 0, ',', '.') . ' ARS</p>' .
                '<span class="precio-usd-final">$' . number_format($precio_final_calculado_usd, 2) . ' USD</span>' .
            '</div>';
    } else {
        $html_precio = 
            '<div class="precio-bloque">' .
                '<p class="precio">$ ' . number_format($precio_original_ars, 0, ',', '.') . ' ARS</p>' .
                '<span class="precio-usd">$' . number_format($precio_original_usd, 2) . ' USD</span>' .
            '</div>';
    }

    echo '
    <div class="juego" data-juego-id="' . $id . '">
      <a href="' . $pagina_url . '">
        <div class="juego-imagen-wrapper">
            <img src="' . $imagen_url . '" alt="' . $titulo . '">
            <div class="juego-brillo"></div>
        </div>
        <div class="info-content">
          <p class="titulo">' . $titulo . '</p>
        </div>
        <div class="precio-container">' . $html_precio . '</div>
      </a>
    </div>';
}

/**
 * Función que genera el bloque HTML para una fila de juego en la nueva sección de listas.
 * @param array $juego Un array asociativo con los datos del juego desde la BD.
 */
function generarJuegoFilaHTML($juego) {
    global $conversion_rate_ars; // Hacemos accesible la variable de conversión

    $id = htmlspecialchars($juego['id']);
    $titulo = htmlspecialchars($juego['titulo']);
    $imagen_url = htmlspecialchars($juego['imagen_url']);
    $pagina_url = !empty($juego['pagina_url']) ? htmlspecialchars($juego['pagina_url']) : '#';
    $precio_original_usd = (float)$juego['precio_final'];
    $descuento = (int)$juego['descuento_porcentaje'];
    $es_proximamente = (bool)($juego['es_proximamente'] ?? false);

    $precio_original_ars = $precio_original_usd * $conversion_rate_ars;

    $html_precio_fila = '';
    if ($es_proximamente) {
        $html_precio_fila = '<div class="precio-fila proximamente-label">Próximamente</div>';
    } else if ($precio_original_usd == 0 && $descuento == 0) {
        $html_precio_fila = '<div class="precio-fila free">Gratis</div>';
    } else if ($descuento > 0) {
        $precio_final_calculado_ars = $precio_original_ars * (1 - ($descuento / 100));
        $precio_final_calculado_usd = $precio_original_usd * (1 - ($descuento / 100));

        $html_precio_fila =
            '<div class="precio-fila con-descuento">' .
                '<span class="descuento-fila">-' . $descuento . '%</span>' .
                '<div class="precio-bloque-fila">' .
                    '<span class="precio-original-fila">$ ' . number_format($precio_original_ars, 0, ',', '.') . '</span>' .
                    '<span class="precio-final-fila">$ ' . number_format($precio_final_calculado_ars, 0, ',', '.') . '</span>' .
                    '<span class="precio-fila-usd">$' . number_format($precio_final_calculado_usd, 2) . ' USD</span>' .
                '</div>' .
            '</div>';
    } else {
        $html_precio_fila = 
            '<div class="precio-fila-dual">' .
                '<div class="precio-fila">$ ' . number_format($precio_original_ars, 0, ',', '.') . '</div>' .
                '<span class="precio-fila-usd">$' . number_format($precio_original_usd, 2) . ' USD</span>' .
            '</div>';
    }

    echo '
    <a href="' . $pagina_url . '" class="juego-fila" data-juego-id="' . $id . '">
        <img src="' . $imagen_url . '" alt="' . $titulo . '" class="juego-fila-img">
        <div class="juego-fila-info">
            <h3 class="juego-fila-titulo">' . $titulo . '</h3>
        </div>
        ' . $html_precio_fila . '
    </a>';
}


// --- CONSULTAS PARA CADA SECCIÓN ---
$sql_destacados_principal = "SELECT id, titulo, pagina_url, imagen_url, precio_final, imagenes_galeria, descuento_porcentaje, es_proximamente, tags FROM juegos WHERE es_proximamente = 0 ORDER BY RAND() LIMIT 5";
$result_destacados_principal = $conn->query($sql_destacados_principal);
$juegos_destacados_principal = [];
if ($result_destacados_principal && $result_destacados_principal->num_rows > 0) {
    $juegos_raw = $result_destacados_principal->fetch_all(MYSQLI_ASSOC);
    foreach ($juegos_raw as $juego) {
        $capturas_urls = [];
        if (!empty($juego['imagenes_galeria'])) {
            $capturas_urls = explode('|', $juego['imagenes_galeria']);
        }
        $juego['capturas'] = array_slice($capturas_urls, 0, 4);
        $juegos_destacados_principal[] = $juego;
    }
}

$categorias_para_mostrar = [];
$sql_top_tags = "
    SELECT tag, COUNT(*) as total_juegos
    FROM (
        SELECT
            TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(j.tags, ',', n.n), ',', -1)) AS tag
        FROM
            juegos AS j
        INNER JOIN (
            SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
        ) AS n
            ON n.n <= 1 + (LENGTH(j.tags) - LENGTH(REPLACE(j.tags, ',', '')))
        WHERE
            j.tags IS NOT NULL AND j.tags != ''
    ) AS tags_separados
    WHERE
        tag != ''
    GROUP BY
        tag
    ORDER BY
        total_juegos DESC
    LIMIT 20;
";
$result_top_tags = $conn->query($sql_top_tags);
$categorias_principales = [];
if ($result_top_tags && $result_top_tags->num_rows > 0) {
    while ($row = $result_top_tags->fetch_assoc()) {
        $categorias_principales[] = $row['tag'];
    }
}
shuffle($categorias_principales);
foreach ($categorias_principales as $categoria) {
    $stmt = $conn->prepare("SELECT imagen_url FROM juegos WHERE tags LIKE ? ORDER BY RAND() LIMIT 16");
    $searchTerm = "%" . $conn->real_escape_string($categoria) . "%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result_imagenes = $stmt->get_result();
    $imagenes = [];
    if ($result_imagenes->num_rows > 0) {
        while ($img_row = $result_imagenes->fetch_assoc()) {
            $imagenes[] = $img_row['imagen_url'];
        }
    }
    if (!empty($imagenes)) {
        $categorias_para_mostrar[] = [
            'nombre' => $categoria,
            'imagenes' => $imagenes
        ];
    }
    $stmt->close();
}

$sql_recomendados = "SELECT * FROM ( (SELECT * FROM juegos WHERE descuento_porcentaje >= 50 ORDER BY descuento_porcentaje DESC LIMIT 5) UNION (SELECT * FROM juegos WHERE click_count > 20 ORDER BY click_count DESC LIMIT 10) UNION (SELECT * FROM juegos ORDER BY id DESC LIMIT 10) ) AS T1 ORDER BY RAND() LIMIT 10;";
$result_recomendados = $conn->query($sql_recomendados);

$sql_novedades_carousel = "SELECT * FROM juegos ORDER BY id DESC LIMIT 16";
$result_novedades_carousel = $conn->query($sql_novedades_carousel);
$sql_novedades_lista = "SELECT * FROM juegos ORDER BY id DESC LIMIT 20";
$result_novedades_lista = $conn->query($sql_novedades_lista);

$sql_ofertas_carousel = "SELECT * FROM juegos WHERE descuento_porcentaje > 0 ORDER BY id DESC LIMIT 10";
$result_ofertas_carousel = $conn->query($sql_ofertas_carousel);
$sql_ofertas_lista = "SELECT * FROM juegos WHERE descuento_porcentaje > 0 ORDER BY id DESC LIMIT 20";
$result_ofertas_lista = $conn->query($sql_ofertas_lista);

$sql_proximamente_carousel = "SELECT * FROM juegos WHERE es_proximamente = 1 ORDER BY id DESC LIMIT 10";
$result_proximamente_carousel = $conn->query($sql_proximamente_carousel);
$sql_proximamente_lista = "SELECT * FROM juegos WHERE es_proximamente = 1 ORDER BY id DESC LIMIT 20";
$result_proximamente_lista = $conn->query($sql_proximamente_lista);

$sql_gratuitos_populares = "SELECT * FROM juegos WHERE precio_final = 0 AND descuento_porcentaje = 0 AND es_proximamente = 0 AND click_count > 0 ORDER BY click_count DESC LIMIT 20";
$result_gratuitos_populares = $conn->query($sql_gratuitos_populares);

$sql_populares = "SELECT * FROM juegos WHERE click_count > 0 ORDER BY click_count DESC LIMIT 10";
$result_populares = $conn->query($sql_populares);
$sql_f2p = "SELECT * FROM juegos WHERE precio_final = 0 AND descuento_porcentaje = 0 AND es_proximamente = 0 ORDER BY id DESC LIMIT 10";
$result_f2p = $conn->query($sql_f2p);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Allerta+Stencil&display=swap" rel="stylesheet">
  <title>NJOY - Tu tienda de videojuegos</title>
  <link rel="icon" type="image/x-icon" href="/NJOYSINFONDO.ico">

  <style>
    /* === PANTALLA DE CARGA (LOADER) === */
    #loader {
        position: fixed;
        inset: 0;
        z-index: 99999;
        background-color: #1E1B4B;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: opacity 0.5s ease-out, visibility 0s linear 0.5s;
        opacity: 1;
        visibility: visible;
    }
    #loader.hidden {
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }
    #loader img {
        width: 120px;
        height: auto;
        animation: pulse 1.5s ease-in-out infinite;
        filter: drop-shadow(0 0 15px rgba(139, 92, 246, 0.7));
    }
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.08); opacity: 0.8; }
        100% { transform: scale(1); opacity: 1; }
    }

/* === BASE Y FONDO === */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
    font-size: clamp(10.5px, 1.125vw, 12px);
}

body {
  font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
  background-color: #1E1B4B;
  color: white;
  min-height: 100vh;
  position: relative;
  overflow-x: hidden;
  transition: color 0.5s ease;
}

@keyframes gradientShift {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.page-background-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    z-index: 0;
    pointer-events: none;
    overflow: hidden;
}

.background-gradient {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: linear-gradient(135deg, #8B5CF6 0%, #3B0764 25%, #1E1B4B 50%, #312E81 75%, #6366F1 100%);
    background-size: 400% 400%;
    animation: gradientShift 20s ease infinite;
    z-index: 1;
}

.background-overlay {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: radial-gradient(ellipse at center, rgba(139, 92, 246, 0.25) 0%, transparent 70%);
    transition: background 0.5s ease;
    z-index: 2;
}

.floating-shapes { 
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    overflow: hidden; 
    z-index: 3;
}

.shape { 
    position: absolute; 
    background: rgba(139, 92, 246, 0.1); 
    border-radius: 50%; 
    animation: float 25s linear infinite; 
    backdrop-filter: blur(1px); 
    transition: transform 0.4s ease-out;
}
.shape:nth-child(1) { width: 100px; height: 100px; left: 10%; animation-duration: 30s; }
.shape:nth-child(2) { width: 150px; height: 150px; left: 30%; animation-duration: 25s; }
.shape:nth-child(3) { width: 80px; height: 80px; left: 60%; animation-duration: 35s; }
.shape:nth-child(4) { width: 120px; height: 120px; left: 80%; animation-duration: 28s; }

@keyframes float {
  0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateY(-200px) rotate(360deg); opacity: 0; }
}

.page-content {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    opacity: 0;
    transition: opacity 0.6s ease 0.2s;
    position: relative;
    z-index: 1;
}
.page-content.loaded {
    opacity: 1;
}

/* === HEADER Y NAV (ESTILO NEÓN FUTURISTA) === */
header, nav {
  backdrop-filter: blur(16px) saturate(150%);
  -webkit-backdrop-filter: blur(16px) saturate(150%);
  position: fixed;
  left: 0;
  right: 0;
  border-bottom: 1px solid rgba(139, 92, 246, 0.25);
  z-index: 101;
  transition: all 0.3s ease;
  background: rgba(30, 27, 75, 0.7);
}

header { 
    padding: 12px 5%; 
    display: flex; 
    align-items: center; 
    justify-content: space-between; 
    top: 0; 
    height: 70px; 
    box-shadow: 0 5px 20px rgba(0,0,0,0.3);
}
nav { 
    display: flex; 
    align-items: center; 
    justify-content: center; 
    gap: 35px; 
    padding: 12px 5%; 
    top: 70px; 
    height: 50px; 
    z-index: 100; 
}


.header-left { display: flex; align-items: center; gap: 35px; }
.logo img { height: 38px; transition: transform 0.3s ease; filter: drop-shadow(0 4px 8px rgba(139, 92, 246, 0.4)); cursor: pointer; }
.logo:hover img { transform: scale(1.05) rotate(5deg); }
.logo:active { transform: scale(0.90); }

.header-nav { display: flex; align-items: center; gap: 35px; }
.header-nav a { text-decoration: none; color: #E5E7EB; font-weight: 600; font-size: 0.95rem; padding: 8px 5px; position: relative; transition: color 0.3s ease; background: none; border: none; cursor: pointer; }
.header-nav a:hover { color: #FFFFFF; }
.header-nav a::after { content: ''; position: absolute; width: 0%; height: 3px; border-radius: 2px; background: linear-gradient(90deg, #8B5CF6, #6366F1); bottom: -5px; left: 50%; transform: translateX(-50%); transition: width 0.4s cubic-bezier(0.25, 1, 0.5, 1); }
.header-nav a:hover::after { width: 100%; }
.header-nav a:active { transform: scale(0.95); }

nav a { text-decoration: none; color: #E5E7EB; font-weight: 600; font-size: 0.95rem; padding: 8px 5px; position: relative; transition: color 0.3s ease; background: none; border: none; cursor: pointer; }
nav a:hover { color: #FFFFFF; }
nav a::after { content: ''; position: absolute; width: 0%; height: 3px; border-radius: 2px; background: linear-gradient(90deg, #8B5CF6, #6366F1); bottom: -5px; left: 50%; transform: translateX(-50%); transition: width 0.4s cubic-bezier(0.25, 1, 0.5, 1); }
nav a:hover::after { width: 100%; }
nav a:active { transform: scale(0.95); }

/* --- BARRA DE BÚSQUEDA --- */
.search-container { position: relative; max-width: 500px; width: 100%; }
#searchInput {
    width: 100%;
    padding: 10px 15px 10px 40px;
    border-radius: 20px;
    border: 1px solid rgba(139, 92, 246, 0.3);
    background-color: rgba(0, 0, 0, 0.3);
    color: white;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='rgba(255,255,255,0.5)' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: 15px center;
}
#searchInput:focus {
    outline: none;
    border-color: #8B5CF6;
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2);
    background-color: rgba(0, 0, 0, 0.5);
}
.search-results {
    display: none;
    position: absolute;
    top: 110%;
    left: 0;
    right: 0;
    background: rgba(30, 30, 47, 0.95);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(139, 92, 246, 0.3);
    border-radius: 10px;
    max-height: 400px;
    overflow-y: auto;
    z-index: 1000;
}
.search-category {
    padding: 8px 15px;
    font-size: 0.8rem;
    font-weight: bold;
    color: #a78bfa;
    text-transform: uppercase;
    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
}
.search-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 15px;
    text-decoration: none;
    color: #E5E7EB;
    transition: background-color: 0.2s ease;
}
.search-item:hover { background-color: rgba(139, 92, 246, 0.15); }
.search-item img {
    width: 64px;
    height: 36px;
    object-fit: cover;
    border-radius: 4px;
}
.search-item img.avatar { width: 36px; height: 36px; border-radius: 50%; }


/* === BANNER === */
.banner { 
    width: 100%; height: 75vh; 
    display: flex; align-items: center; justify-content: center; text-align: center; 
    position: relative;
    overflow: hidden;
}
.banner::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url("njoyimages/fondo.jpeg") no-repeat center center/cover;
    z-index: 1;
}
.banner-content { 
    z-index: 2; 
    position: relative;
}

@keyframes fadeInUp { from { opacity: 0; transform: translate3d(0, 40px, 0); filter: blur(5px); } to { opacity: 1; transform: translate3d(0, 0, 0); filter: blur(0); } }
@keyframes premiumFloat { from { transform: translateY(0px) scale(1); } to { transform: translateY(-12px) scale(1.01); } }

.banner h1 {
    position: relative; font-family: "Allerta Stencil", sans-serif; font-weight: 400; font-style: normal;
    font-size: clamp(2rem, 7vw, 4.5rem); margin-bottom: 0.9rem;
    animation: fadeInUp 1s cubic-bezier(0.2, 0.8, 0.2, 1) 0.5s both, premiumFloat 8s ease-in-out 1.5s infinite alternate;
    will-change: transform; background: linear-gradient(45deg, #FFFFFF, #FFFFFF); background-clip: text;
    -webkit-background-clip: text; -webkit-text-fill-color: #ffffff50;
    text-shadow: 0 0 1px #fff, 0 0 15px #000, 0 0 70px #ed00fff0, 0 0 100px #9000fd, 0 0 150px #b700ff, 0 0 150px #210b63;
    backface-visibility: hidden; transform-style: preserve-3d;
}
.banner p {
    font-size: clamp(0.8rem, 2.2vw, 1.05rem); max-width: 600px; margin: 0 auto;
    animation: fadeInUp 1s ease-out 1s both; color: #FFFFFF;
    text-shadow: 0 0 2.5px #ffffff, 0 0 10px #00000087, 0 0 45px #ed00fff0, 0 0 70px #9000fd36, 0 0 75px #210b63;
}

/* === ESTRUCTURA PRINCIPAL Y CONTENEDORES === */
main {
    padding-top: 120px;
    position: relative;
    z-index: 2;
    background: transparent;
    flex-grow: 1;
}

.content-wrapper { max-width: 1400px; margin-left: auto; margin-right: auto; padding-left: 5%; padding-right: 5%; }

.section, .lists-section-container, .faq-section-container { 
    position: relative; 
    text-align: left; 
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
    z-index: 2;
}
.section.is-hovered {
    z-index: 20;
}

.section {
    padding: 25px 0;
}
.section.is-visible, .lists-section-container.is-visible, .faq-section-container.is-visible {
    opacity: 1;
    transform: translateY(0);
}

.section-title {
    font-size: clamp(1.3rem, 3.5vw, 1.9rem);
    font-weight: 700; margin-bottom: 2rem; position: relative; padding-bottom: 10px;
    text-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
}
.section-title::after { 
    content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: 4px; 
    background: linear-gradient(90deg, #8B5CF6, #6366F1); border-radius: 2px;
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
}
.section.is-visible .section-title::after {
    transform: scaleX(1);
}

/* === SLIDER DESTACADOS === */
.main-slider-wrapper {
    position: relative;
    max-width: 1050px;
    margin: 0 auto 4rem auto;
}
.destacados-principal-slider {
    position: relative;
    width: 960px;
    height: 353px;
    margin: 0 auto;
    overflow: hidden;
    
    border-radius: 16px;
    background: linear-gradient(165deg, rgba(70, 60, 150, 0.5), rgba(40, 35, 90, 0.4));
    backdrop-filter: blur(20px) saturate(180%);
    -webkit-backdrop-filter: blur(20px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.2);
    /* Sombra para integrar mejor, en lugar de borde */
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
}

.destacados-principal-slider::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: inherit;
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.15) 0%, rgba(255, 255, 255, 0) 50%);
    pointer-events: none;
}

.slides-container {
    display: flex;
    height: 100%;
    transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
}

/* === EFECTO HOVER PARA SLIDER DESTACADOS (SIN SEGUIMIENTO) === */
.slide {
    flex: 0 0 100%;
    width: 100%;
    height: 100%;
    display: flex;
    position: relative;
    transition: transform 0.4s ease;
}
.slide:hover {
    transform: scale(1.02); /* Sutil crecimiento al pasar el cursor */
}

.slide-image-container {
    width: 616px;
    height: 353px;
    flex-shrink: 0;
    background-color: #000;
    display: flex;
    align-items: center;
    justify-content: center;
}
.slide-image-container a {
    display: block;
    width: 100%;
    height: 100%;
}
.slide-image-container img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Cambiado a cover para mejor apariencia */
    transition: opacity 0.3s ease-in-out;
}
.slide-content-wrapper {
    flex-grow: 1;
    display: flex;
}
.slide-content-wrapper > a {
    text-decoration: none;
    color: inherit;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}
.slide-content {
    padding: 1rem;
    width: 100%;
    color: #fff;
    display: flex;
    flex-direction: column;
    height: 100%;
}
.slide-content h3 {
    font-size: 1.5rem;
    font-weight: 600;
    color: #f0f0f0;
    text-shadow: 0 1px 3px rgba(0,0,0,0.5);
}
.thumbnails {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 1rem;
}
.thumbnails img {
    width: 100%;
    border-radius: 4px;
    aspect-ratio: 16 / 9;
    object-fit: cover;
    opacity: 0.7; /* Más opaco por defecto */
    transition: opacity 0.3s ease, transform 0.3s ease;
    border: 1px solid rgba(255,255,255,0.1);
    cursor: pointer;
}
.thumbnails img:hover {
    opacity: 1;
    transform: scale(1.05);
}

.tags-container {
    margin-top: 20px;
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    margin-bottom: 1rem;
}
.genre-tag {
    background-color: rgba(0, 0, 0, 0.25);
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.8rem;
    font-weight: 500;
    color: #d1d5db;
    border: 1px solid rgba(255,255,255,0.1);
}
.price-platform {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
}
.price-block {
    display: flex;
    align-items: center;
    gap: 10px;
}
.price-block .discount {
    background-color: #4c952e;
    color: #d2ffc0;
    padding: 4px 10px;
    border-radius: 3px;
    font-weight: 700;
    font-size: 1.4rem;
}
.price-block .price-values {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}
.price-block .original-price {
    font-size: 0.8rem;
    color: #9ca3af;
    text-decoration: line-through;
    line-height: 1;
}
.price-block .final-price {
    font-size: 1.1rem;
    font-weight: 600;
    color: #d2ffc0;
    line-height: 1;
}
.price-platform .price.free {
    font-size: 1.2rem;
    color: #e5e7eb;
    font-weight: 600;
}
.platform-icon {
    width: 20px;
    height: 20px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512' fill='%239ca3af'%3E%3Cpath d='M0 93.7l183.6-25.3v177.4H0V93.7zm0 324.6l183.6 25.3V268.4H0v149.9zm203.8 28L448 480V268.4H203.8v177.9zm0-380.6v180.1H448V32L203.8 65.7z'/%3E%3C/svg%3E");
    background-size: contain;
    background-repeat: no-repeat;
    opacity: 0.8;
}
.slider-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(30, 30, 47, 0.5);
    color: white;
    border: none;
    border-radius: 4px;
    width: 40px;
    height: 70px;
    font-size: 28px;
    font-weight: 300;
    cursor: pointer;
    z-index: 10;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}
.slider-btn:hover {
    background: rgba(45, 45, 68, 0.8);
}
.slider-btn.prev-main { left: 0; }
.slider-btn.next-main { right: 0; }
.pagination-dots {
    position: absolute;
    bottom: -30px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 8px;
    z-index: 5;
}
.dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.2);
    cursor: pointer;
    transition: all 0.4s ease;
}
.dot:hover {
    background-color: rgba(255, 255, 255, 0.5);
}
.dot.active {
    background-color: #fff;
}


/* === CARRUSELES Y JUEGOS === */
.carrusel-wrapper {
    position: relative;
    padding: 0 60px;
}

.carrusel-automatico { overflow: hidden; }
.carrusel-automatico .destacados-grid { display: flex; gap: 24px; padding-bottom: 1.3rem; overflow-x: visible; animation: scrollC 80s linear infinite; width: max-content; touch-action: none; margin-top: 12px; }
.carrusel-automatico .destacados-grid:hover { animation-play-state: paused; }
@keyframes scrollC { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }

.carrusel-container {
    overflow-x: auto;
    overflow-y: visible;
    scroll-snap-type: x mandatory;
    -webkit-overflow-scrolling: touch;
    scroll-behavior: smooth;
    scrollbar-width: none;
    cursor: grab;
    padding-top: 40px;
    padding-bottom: 40px;
    margin-top: -40px;
    margin-bottom: -40px;
}
.carrusel-container:active { cursor: grabbing; }
.carrusel-container::-webkit-scrollbar { display: none; }
.carrusel-container .destacados-grid { display: flex; gap: 24px; width: max-content; touch-action: pan-x; }

/* === TARJETA DE JUEGO "NEÓN GLOW & GLINT" === */
.juego { 
    width: clamp(150px, 11vw, 170px);
    flex-shrink: 0; 
    border-radius: 12px; 
    overflow: hidden;
    transition: all 0.3s ease; 
    scroll-snap-align: start;
    position: relative;
    z-index: 1;
    background: #1E1E2F;
    border: 1px solid rgba(139, 92, 246, 0.2);
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}

.juego:hover {
    transform: translateY(-10px) scale(1.05);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 30px rgba(139, 92, 246, 0.5);
    z-index: 10;
}

.juego > a {
    text-decoration: none;
    color: inherit;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.juego-imagen-wrapper {
    position: relative;
    overflow: hidden;
}

.juego img { 
    width: 100%; height: auto;
    aspect-ratio: 460 / 215; 
    object-fit: cover; 
    display: block;
}

/* Efecto de destello "Glint" */
.juego-brillo {
    position: absolute;
    top: 0;
    left: -150%;
    width: 80%;
    height: 100%;
    background: linear-gradient(
        100deg,
        rgba(255, 255, 255, 0) 10%,
        rgba(255, 255, 255, 0.1) 50%,
        rgba(255, 255, 255, 0) 90%
    );
    transform: skewX(-25deg);
    transition: left 0.6s ease-in-out;
    pointer-events: none;
}
.juego:hover .juego-brillo {
    left: 150%;
}

.info-content { 
    padding: 0.9rem; 
    flex-grow: 1; 
}
.info-content .titulo { 
    font-size: 0.9rem; 
    font-weight: 600; 
    margin-bottom: 7px; 
    line-height: 1.4; 
}

.precio-container { 
    padding: 0.65rem 0.9rem; 
    margin-top: auto; 
    background: rgba(18, 18, 31, 0.8);
    border-top: 1px solid rgba(139, 92, 246, 0.2);
    display: flex; 
    align-items: center; 
    justify-content: flex-end; 
    gap: 0.65rem; 
    flex-wrap: wrap; 
}
.precio-bloque {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    line-height: 1.2;
}
.precio-usd {
    font-size: 0.75rem;
    color: #9CA3AF;
    opacity: 0.8;
}
.precio-bloque-descuento { display: flex; flex-direction: column; align-items: flex-end; }
.precio-original { font-size: 0.75rem; color: #9CA3AF; text-decoration: line-through; opacity: 0.8; }
.precio { font-weight: 700; font-size: 0.95rem; }
.descuento { background: rgba(239, 68, 68, 0.8); padding: 3px 7px; border-radius: 5px; font-size: 0.75rem; font-weight: 600; color: white; align-self: center; }
.proximamente-label { color: #f59e0b; font-weight: 700; font-size: 1rem; width: 100%; text-align: right; }
.carrusel-btn { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(30, 30, 47, 0.8); backdrop-filter: blur(5px); border: 1px solid rgba(139, 92, 246, 0.3); color: white; font-size: 18px; border-radius: 50%; cursor: pointer; transition: all 0.4s ease; z-index: 30; width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; }
.carrusel-btn:hover { background: #8B5CF6; transform: translateY(-50%) scale(1.1); box-shadow: 0 10px 25px rgba(139, 92, 246, 0.4); }
.carrusel-btn.prev { left: 10px; }
.carrusel-btn.next { right: 10px; }
.carrusel-btn:active { transform: translateY(-50%) scale(0.95); }


/*******************************************************************/
/* INICIO DE LA SOLUCIÓN DE SEPARACIÓN DE TRANSFORMACIONES         */
/*******************************************************************/
.categorias-grid {
    display: flex;
    gap: 22px;
    width: max-content;
    touch-action: pan-x;
}

.categoria-card {
    position: relative;
    width: 260px;
    flex-shrink: 0;
    aspect-ratio: 16 / 10;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: white;
    background-color: #2a2141;
    perspective: 1000px;
    overflow: hidden;
    transition: transform 0.4s ease;
    will-change: transform;
}

.categoria-card::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: inherit;
    z-index: 11;
    pointer-events: none;
    box-shadow: inset 0 0 0 2px rgba(167, 139, 250, 0.3);
    transition: transform 0.4s ease, box-shadow 0.4s ease;
    will-change: transform, box-shadow;
}

.categoria-background,
.categoria-overlay,
.categoria-label {
    transition: transform 0.4s ease;
    will-change: transform;
}

.categoria-card:hover {
    transform: translateY(-8px);
}

.categoria-card:hover::before,
.categoria-card:hover .categoria-background,
.categoria-card:hover .categoria-overlay,
.categoria-card:hover .categoria-label {
    transform: scale(1.05);
}

.categoria-card:hover::before {
    box-shadow: inset 0 0 0 2px #a78bfa,
                inset 0 0 20px 5px rgba(167, 139, 250, 0.7);
}

.categoria-background {
    position: absolute;
    top: -100%; left: -50%;
    width: 250%; height: 250%;
    transform-style: preserve-3d;
    transform: perspective(1200px) rotateX(65deg) rotateZ(-25deg) scale(1.1);
    z-index: 1;
}

.categoria-card:hover .categoria-background {
    transform: perspective(1200px) rotateX(60deg) rotateZ(-20deg) scale(1.15);
}


.categoria-background img {
    position: absolute;
    width: 25%; height: 25%;
    object-fit: cover;
    filter: grayscale(40%) brightness(70%);
    opacity: 1;
    backface-visibility: hidden;
    transition: filter 0.4s ease, opacity 0.4s ease;
    border: 1px solid rgba(0,0,0,0.5);
}

.categoria-card:hover .categoria-background img {
    filter: grayscale(10%) brightness(85%);
}

.categoria-background img:nth-child(1)  { top: 0; left: -12.5%; }
.categoria-background img:nth-child(2)  { top: 0; left: 12.5%; }
.categoria-background img:nth-child(3)  { top: 0; left: 37.5%; }
.categoria-background img:nth-child(4)  { top: 0; left: 62.5%; }
.categoria-background img:nth-child(5)  { top: 25%; left: 0; }
.categoria-background img:nth-child(6)  { top: 25%; left: 25%; }
.categoria-background img:nth-child(7)  { top: 25%; left: 50%; }
.categoria-background img:nth-child(8)  { top: 25%; left: 75%; }
.categoria-background img:nth-child(9)  { top: 50%; left: -12.5%; }
.categoria-background img:nth-child(10) { top: 50%; left: 12.5%; }
.categoria-background img:nth-child(11) { top: 50%; left: 37.5%; }
.categoria-background img:nth-child(12) { top: 50%; left: 62.5%; }
.categoria-background img:nth-child(13) { top: 75%; left: 0; }
.categoria-background img:nth-child(14) { top: 75%; left: 25%; }
.categoria-background img:nth-child(15) { top: 75%; left: 50%; }
.categoria-background img:nth-child(16) { top: 75%; left: 75%; }


.categoria-overlay {
    background: linear-gradient(180deg, rgba(42, 33, 65, 0.2) 0%, rgba(42, 33, 65, 0.7) 100%);
    z-index: 10;
    border-radius: inherit;
    box-shadow: inset 0 0 35px 8px rgb(132 5 255 / 15%);
}

.categoria-label {
    position: relative;
    z-index: 12;
    background-color: rgba(240, 240, 240, 0.95);
    color: #1c1c1c;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
}
/*******************************************************************/
/* FIN DE LA SOLUCIÓN                                              */
/*******************************************************************/


/* === CONTENEDOR DE LISTAS A ANCHO COMPLETO === */
.lists-section-container {
    padding: 3.5rem 0;
    margin: 1rem 0 3rem 0;
    background: rgba(15, 23, 42, 0.5);
    backdrop-filter: blur(10px);
    border-top: 1px solid rgba(139, 92, 246, 0.2);
    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
    transition: all 0.5s ease;
}
#explorar-listas { padding-top: 0; padding-bottom: 0; }
.tabs-container { display: flex; gap: 15px; border-bottom: 2px solid rgba(139, 92, 246, 0.2); margin-bottom: 25px; flex-wrap: wrap; }
.tab-link { background: none; border: none; color: #E5E7EB; padding: 10px 20px; cursor: pointer; font-size: 1rem; font-weight: 600; position: relative; transition: all 0.3s ease; }
.tab-link::after { content: ''; position: absolute; bottom: -2px; left: 50%; transform: translateX(-50%); width: 0; height: 3px; background: linear-gradient(90deg, #8B5CF6, #6366F1); border-radius: 2px; transition: width 0.4s ease; }
.tab-link.active, .tab-link:hover { color: #FFFFFF; }
.tab-link.active::after { width: 100%; }
.tab-link:active { transform: scale(0.95); }
.tab-content { display: none; animation: fadeIn 0.5s ease; }
.tab-content.active { display: block; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.juegos-lista { display: flex; flex-direction: column; gap: 8px; }
.juego-fila { display: flex; align-items: center; background: rgba(30, 30, 47, 0.7); border-radius: 8px; text-decoration: none; color: white; transition: all 0.3s ease; overflow: hidden; border: 1px solid transparent; }
.juego-fila:hover { background: rgba(139, 92, 246, 0.2); transform: translateX(5px); border-color: rgba(139, 92, 246, 0.5); }
.juego-fila-img { width: 150px; height: 70px; object-fit: cover; flex-shrink: 0; }
.juego-fila-info { flex-grow: 1; padding: 0 20px; }
.juego-fila-titulo { font-size: 1rem; font-weight: 600; }
.precio-fila { padding: 0 20px; font-weight: 700; font-size: 0.95rem; min-width: 120px; text-align: right; }
.precio-fila.free { color: #4ade80; }
.precio-fila-dual {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    padding: 0 20px; 
    min-width: 120px;
    text-align: right;
}
.precio-fila.con-descuento { display: flex; align-items: center; gap: 10px; justify-content: flex-end; padding: 0 20px; min-width: 120px; }
.descuento-fila { background: rgba(239, 68, 68, 0.8); padding: 4px 8px; border-radius: 5px; font-size: 0.8rem; font-weight: 700; }
.precio-bloque-fila { display: flex; flex-direction: column; align-items: flex-end; }
.precio-original-fila { font-size: 0.8rem; color: #9CA3AF; text-decoration: line-through; }
.precio-final-fila { font-size: 1rem; font-weight: 700; }
.precio-fila.proximamente-label { min-width: 120px; padding: 0 20px; }

/* === USUARIO, MODALES, FOOTER, ETC === */
.header-right { display: flex; align-items: center; gap: 15px; justify-content: flex-end; flex-grow: 1; }
.usuario { cursor: pointer; display: flex; align-items: center; gap: 10px; position: relative; }
.nombre-usuario { font-weight: 600; font-size: 0.95rem; transition: color 0.3s ease; }
.usuario:hover .nombre-usuario { color: #e0e0e0; }
.usuario img { width: 42px; height: 42px; border-radius: 50%; border: 2.5px solid rgba(139, 92, 246, 0.8); object-fit: cover; transition: all 0.3s ease; box-shadow: 0 0 15px rgba(139, 92, 246, 0.75); }
.usuario:hover img { transform: scale(1.1); border-color: #8B5CF6; box-shadow: 0 0 25px rgba(139, 92, 246, 1); }
.usuario-menu { display: none; position: absolute; top: 60px; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; overflow: hidden; min-width: 200px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; animation: menuSlideDown 0.3s ease-out; }
@keyframes menuSlideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.usuario-menu a { display: flex; align-items: center; gap: 10px; padding: 13px; text-decoration: none; color: white; font-weight: 500; font-size: 0.9rem; transition: all 0.3s ease; }
.usuario-menu a:hover { background: rgba(139, 92, 246, 0.2); }
/* --- NOTIFICACIONES --- */
#notificacionesBtn { position: relative; cursor: pointer; display: flex; align-items: center; }
#notificacion-alerta { position: absolute; top: -2px; right: -4px; width: 10px; height: 10px; background-color: #ef4444; border-radius: 50%; border: 2px solid #1E1B4B; display: none; }
#notificaciones-panel { display: none; position: absolute; top: 60px; right: 0; width: 340px; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; max-height: 400px; overflow-y: auto; animation: menuSlideDown 0.3s ease-out; }
.notificacion-item { padding: 15px; display: flex; align-items: flex-start; gap: 12px; border-bottom: 1px solid rgba(139, 92, 246, 0.1); }
.notificacion-item a { text-decoration: none; }
.notificacion-item:last-child { border: none; }
.notificacion-avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; }
.notificacion-contenido { flex-grow: 1; }
.notificacion-item p { font-size: 0.9rem; line-height: 1.4; color: #E5E7EB; margin: 0; }
.notificacion-item p a { color: #c4b5fd; font-weight: bold; text-decoration: none; }
.notificacion-item p a:hover { text-decoration: underline; }
.notificacion-acciones { margin-top: 10px; display: flex; gap: 10px; }
.notif-action-btn { font-size: 0.8rem; padding: 4px 10px; border-radius: 5px; border: none; cursor: pointer; font-weight: 600; color: white; transition: transform 0.1s ease; }
.notif-action-btn:active { transform: scale(0.95); }
.notif-action-btn.accept { background-color: #10B981; }
.notif-action-btn.reject { background-color: #EF4444; }
.notif-feedback { font-size: 0.9rem; color: #a78bfa; font-style: italic; }
.notificacion-item.no-leida { background: rgba(139, 92, 246, 0.1); }
#notificacion-icono-svg { width: 26px; height: 26px; stroke: #E5E7EB; transition: all 0.3s ease; }
#notificacionesBtn:hover #notificacion-icono-svg { stroke: #FFFFFF; filter: drop-shadow(0 0 5px rgba(192, 132, 252, 0.7)); }

.explorar-botones { display: flex; justify-content: flex-start; gap: 18px; flex-wrap: wrap; }
.explorar-botones a { text-decoration: none; background: rgba(139, 92, 246, 0.15); padding: 13px 26px; border-radius: 22px; color: white; font-weight: 600; font-size: 0.9rem; border: 1px solid rgba(139, 92, 246, 0.3); transition: all 0.4s ease; }
.explorar-botones a:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(139, 92, 246, 0.4); border-color: #8B5CF6; background-color: rgba(139, 92, 246, 0.3); }
.explorar-botones a:active { transform: translateY(-1px) scale(0.98); }
footer { background: rgba(30, 30, 47, 0.9); backdrop-filter: blur(20px); padding: 35px 18px; text-align: center; color: #E5E7EB; margin-top: auto; transition: background 0.5s ease, color 0.5s ease; width: 100%; z-index: 2; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(10px); justify-content: center; align-items: center; z-index: 2000; }
.modal-content { background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); padding: 28px; border-radius: 18px; max-width: 420px; width: 90%; color: white; text-align: center; position: relative; border: 1px solid rgba(139, 92, 246, 0.3); animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
@keyframes modalSlideIn { from { transform: translateY(-50px) scale(0.9); opacity: 0; } to { transform: translateY(0) scale(1); opacity: 1; } }
.modal-content h2 { margin-bottom: 18px; font-size: 1.4rem; }
.modal-content label { display: block; margin: 13px 0 7px; text-align: left; font-weight: 500; font-size: 0.9rem; }
.modal-content input, .modal-content textarea, .modal-content select { width: 100%; padding: 11px; border: 1px solid rgba(139, 92, 246, 0.3); background: rgba(255, 255, 255, 0.1); border-radius: 9px; margin-bottom: 13px; color: white; transition: all 0.3s ease; font-family: inherit; }
.modal-content input:focus, .modal-content textarea:focus, .modal-content select:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
.modal-content button { padding: 11px 22px; border: none; border-radius: 8px; cursor: pointer; margin: 9px 4px; font-weight: 600; font-size: 0.9rem; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);}
.modal-content button:active { transform: scale(0.95); }
.modal-button-secondary { background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); }
.modal-button-secondary:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
.cerrar { position: absolute; top: 13px; right: 18px; font-size: 22px; cursor: pointer; color: #9CA3AF; transition: all 0.3s ease;}
.cerrar:hover { color: #fff; }
.foto-perfil-config-container { display: flex; align-items: center; gap: 13px; margin-bottom: 13px; }
#configFotoPreview { width: 65px; height: 65px; border-radius: 50%; border: 4px solid rgba(139, 92, 246, 0.5); object-fit: cover; }
.boton-subir-foto { background: rgba(255, 255, 255, 0.1); padding: 9px 13px; border-radius: 7px; border: 1px solid rgba(139, 92, 246, 0.3); cursor: pointer; transition: all 0.3s ease; font-weight: 500; font-size: 0.85rem; }
.boton-subir-foto:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
.btn-acceso:active { transform: scale(0.95); }

/* === THEME SWITCH === */
.theme-switch-wrapper { display: flex; align-items: center; gap: 13px; margin-top: 13px; margin-bottom: 20px; }
.theme-switch { position: relative; display: inline-block; width: 55px; height: 30px; }
.theme-switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 30px; }
.slider:before { position: absolute; content: ""; height: 23px; width: 23px; left: 4px; bottom: 3.5px; background-color: white; transition: .4s; border-radius: 50%; }
input:checked + .slider { background-color: #8B5CF6; }
input:focus + .slider { box-shadow: 0 0 1px #8B5CF6; }
input:checked + .slider:before { transform: translateX(24px); }

/* === MODO CLARO === */
body.light-mode { color: #111827; }
body.light-mode .background-gradient { background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 25%, #f5f3ff 50%, #c4b5fd 75%, #a5b4fc 100%); }
body.light-mode #searchInput { background-color: #e5e7eb; color: #111827; border-color: #d1d5db; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='rgba(0,0,0,0.5)' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 S'/%3E%3C/svg%3E"); }
body.light-mode .search-results { background-color: rgba(255,255,255,0.98); border-color: #e5e7eb; }
body.light-mode .search-item { color: #374151; }
body.light-mode .search-item:hover { background-color: #f3f4f6; }
body.light-mode .search-category { color: #6d28d9; border-color: #e5e7eb; }
body.light-mode .lists-section-container { background: rgba(245, 243, 255, 0.8); border-color: rgba(0, 0, 0, 0.05); }
body.light-mode .banner p { color: #FFFFFF; text-shadow: 0 1px 3px rgba(0, 0, 0, 0.4); }
body.light-mode header, body.light-mode nav { background: rgba(255, 255, 255, 0.85); border-bottom-color: rgba(0, 0, 0, 0.1); }
body.light-mode nav a, body.light-mode .header-nav a, body.light-mode .nombre-usuario { color: #374151; }
body.light-mode nav a:hover, body.light-mode .header-nav a:hover { color: #111827; }
body.light-mode .section-title { color: #111827; }
body.light-mode .juego { background: #ffffff; border-color: rgba(0, 0, 0, 0.1); box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
body.light-mode .juego:hover { border-color: #a78bfa; }
body.light-mode .precio-container { background: #f3f4f6; }
body.light-mode .usuario-menu { background: rgba(255, 255, 255, 0.95); border-color: rgba(0, 0, 0, 0.1); }
body.light-mode .usuario-menu a { color: #1f2937; }
body.light-mode .usuario-menu a:hover { background: rgba(139, 92, 246, 0.1); }
body.light-mode footer { background: rgba(255, 255, 255, 0.9); color: #4b5563; border-top-color: rgba(0, 0, 0, 0.1); }
body.light-mode .modal-content { background: rgba(255, 255, 255, 0.98); color: #111827; border-color: rgba(0, 0, 0, 0.1); }
body.light-mode .modal-content h2 { color: #1f2937; }
body.light-mode .modal-content input, body.light-mode .modal-content select { background: #f3f4f6; border-color: #d1d5db; color: #111827; }
body.light-mode .modal-content input:focus, body.light-mode .modal-content select:focus { border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
body.light-mode .cerrar { color: #6b7280; }
body.light-mode .cerrar:hover { color: #111827; }
body.light-mode .boton-subir-foto { background: #f3f4f6; border-color: #d1d5db; }
body.light-mode .carrusel-btn { background: rgba(255, 255, 255, 0.8); border-color: #d1d5db; color: #111827; }
body.light-mode .tabs-container { border-bottom-color: rgba(0, 0, 0, 0.1); }
body.light-mode .tab-link { color: #374151; }
body.light-mode .tab-link:hover, body.light-mode .tab-link.active { color: #111827; }
body.light-mode .juego-fila { background: rgba(255, 255, 255, 0.7); color: #1f2937; }
body.light-mode .juego-fila:hover { background: rgba(233, 213, 255, 0.8); border-color: #a78bfa; }
body.light-mode .precio-fila.free { color: #16a34a; }
body.light-mode #notificacion-icono-svg { stroke: #4b5563; }
body.light-mode #notificacionesBtn:hover #notificacion-icono-svg { stroke: #111827; filter: none; }
body.light-mode #notificaciones-panel { background: rgba(255,255,255,0.98); border-color: #e5e7eb; }
body.light-mode .notificacion-item { border-color: #e5e7eb; }
body.light-mode .notificacion-item.no-leida { background: rgba(139, 92, 246, 0.08); }
body.light-mode .feed-section { background: rgba(245, 243, 255, 0.8); border-color: rgba(0, 0, 0, 0.05); }
body.light-mode .feed-item { background: rgba(255, 255, 255, 0.9); border-color: rgba(0,0,0,0.1); }
body.light-mode .feed-header { color: #374151; }
body.light-mode .feed-header a { color: #5b21b6; }
body.light-mode .categoria-card { background-color: #f5f3ff; }
body.light-mode .categoria-card::before { box-shadow: inset 0 0 0 2px rgba(0,0,0,0.08); }
body.light-mode .categoria-card:hover::before { box-shadow: inset 0 0 0 2px #a78bfa, inset 0 0 20px 5px rgba(167, 139, 250, 0.7); }
body.light-mode .categoria-label { background: #e9d5ff; color: #3730a3; }
body.light-mode .categoria-card:hover .categoria-label { background: #d8b4fe; }


/* === RESPONSIVE === */
@media (max-width: 1024px) {
    .slider-btn.prev-main { left: 5px; }
    .slider-btn.next-main { right: 5px; }
    .header-nav { display: none; }
}

@media (max-width: 768px) {
    .carrusel-wrapper { padding: 0; }
    nav { justify-content: flex-start; overflow-x: auto; scrollbar-width: none; }
    nav::-webkit-scrollbar { display: none; }
    .nombre-usuario { display: block; }
    .carrusel-btn { display: none; }
    .juego-fila-img { width: 120px; height: 56px; }
    .juego-fila-info { padding: 0 15px; }
    .juego-fila-titulo { font-size: 0.9rem; }
    .precio-fila { min-width: 100px; padding: 0 15px; }
    .search-container { display: none; }
    .main-slider-wrapper { padding: 0; }
    .slider-btn { display: none; }
    .destacados-principal-slider { aspect-ratio: initial; height: auto; }
    .slide { flex-direction: column; }
    .slide-image-container { width: 100%; height: auto; aspect-ratio: 460 / 215; }
    .slide-content-wrapper { width: 100%; }
    .slide-content { padding: 1rem; }
    .slide-content h3 { font-size: 1.3rem; margin-bottom: 0.8rem; }
    .thumbnails { display: grid; }
    .pagination-dots { bottom: 8px; }
}
@media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; } }
.acciones-invitado { display: flex; gap: 15px; }
.btn-acceso { text-decoration: none; color: white; font-weight: 600; padding: 8px 16px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.5); transition: all 0.3s ease; }
.btn-acceso:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
.btn-acceso.btn-registro { background-color: #8B5CF6; border-color: #8B5CF6; }
.btn-acceso.btn-registro:hover { background-color: #7c3aed; }

/* === FEED DE ACTIVIDAD Y SKELETON LOADER === */
.feed-container { max-width: 800px; margin: 0 auto; }
.feed-item { background: rgba(30, 27, 75, 0.6); padding: 20px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2); margin-bottom: 25px; display: flex; gap: 15px; animation: fadeIn 0.5s ease; }
.feed-avatar img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
.feed-content { flex-grow: 1; }
.feed-header { margin-bottom: 10px; color: #d1d5db; line-height: 1.5; }
.feed-header a { color: #e0d4ff; text-decoration: none; font-weight: bold; }
.feed-header a:hover { text-decoration: underline; }
.feed-timestamp { font-size: 0.8rem; color: #9ca3af; }
body.light-mode .feed-item { background: rgba(255, 255, 255, 0.9); border-color: rgba(0,0,0,0.1); }
body.light-mode .feed-header { color: #374151; }
body.light-mode .feed-header a { color: #5b21b6; }

/* Skeleton Loader para el feed */
.skeleton {
    background-color: rgba(139, 92, 246, 0.1);
    background-image: linear-gradient(
        90deg,
        rgba(139, 92, 246, 0.1) 0px,
        rgba(139, 92, 246, 0.2) 40px,
        rgba(139, 92, 246, 0.1) 80px
    );
    background-size: 600px;
    animation: shimmer 1.8s infinite linear;
}
.skeleton-avatar { width: 50px; height: 50px; border-radius: 50%; }
.skeleton-line { height: 1em; border-radius: 4px; }
.skeleton-line-short { width: 40%; }
.skeleton-line-long { width: 100%; }
@keyframes shimmer {
    0% { background-position: -300px 0; }
    100% { background-position: 300px 0; }
}

/* === INICIO: ESTILOS PARA LA NUEVA SECCIÓN DE FAQ === */
.faq-section-container {
    padding: 2rem 0;
    background: rgba(10, 10, 20, 0.7);
    backdrop-filter: blur(10px);
    border-top: 1px solid rgba(139, 92, 246, 0.2);
    transition: all 0.5s ease;
}
.faq-main-header {
    width: 100%;
    background: none;
    border: none;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    padding: 0;
    font-size: clamp(1.3rem, 3.5vw, 1.9rem);
    font-weight: 700;
}
.faq-main-icon {
    font-size: 1.5rem;
    transition: transform 0.4s ease;
}
.faq-content-wrapper {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.7s ease-in-out, padding-top 0.5s ease;
    padding-top: 0;
}
.faq-section-container.active .faq-content-wrapper {
    max-height: 1000px; /* Suficiente para el contenido */
    padding-top: 2.5rem;
}
.faq-section-container.active .faq-main-icon {
    transform: rotate(180deg);
}
.faq-container {
    max-width: 850px;
    margin: 0 auto;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(139, 92, 246, 0.2);
    background: rgba(30, 27, 75, 0.6);
}
.faq-item {
    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
}
.faq-item:last-child {
    border-bottom: none;
}
.faq-question {
    background: none;
    border: none;
    width: 100%;
    text-align: left;
    padding: 20px;
    font-size: 1.1rem;
    font-weight: 600;
    color: white;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background-color 0.3s ease;
}
.faq-question:hover {
    background-color: rgba(139, 92, 246, 0.1);
}
.faq-answer {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.5s cubic-bezier(0, 1, 0, 1), padding 0.5s ease;
    padding: 0 20px;
}
.faq-answer p {
    margin: 15px;
    padding-bottom: 20px;
    line-height: 1.6;
    color: #d1d5db;
    font-size: 0.95rem;
}
.faq-item.active .faq-answer {
    margin; 15px;
    max-height: 300px;
    transition: max-height 1s cubic-bezier(1, 0, 1, 0);
}
.faq-icon {
    font-size: 1.5rem;
    transition: transform 0.4s ease;
}
.faq-item.active .faq-icon {
    transform: rotate(45deg);
}
body.light-mode .faq-section-container {
    background: rgba(249, 250, 251, 0.8);
    border-color: rgba(0, 0, 0, 0.05);
}
body.light-mode .faq-main-header {
    color: #111827;
}
body.light-mode .faq-container {
    background: rgba(255, 255, 255, 0.9);
    border-color: rgba(0,0,0,0.1);
}
body.light-mode .faq-item {
    border-color: rgba(0,0,0,0.1);
}
body.light-mode .faq-question {
    color: #1f2937;
}
body.light-mode .faq-question:hover {
    background-color: rgba(139, 92, 246, 0.08);
}
body.light-mode .faq-answer p {
    color: #374151;
}
/* === FIN: ESTILOS PARA LA NUEVA SECCIÓN DE FAQ === */

/* === INICIO: ESTILOS BOTÓN CONTACTO FAQ === */
.faq-contact-container {
    text-align: center;
    margin-top: 2.5rem;
}
.faq-contact-btn {
    display: inline-block;
    text-decoration: none;
    background-color: #8B5CF6;
    color: white;
    padding: 12px 28px;
    border-radius: 25px;
    font-weight: 600;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    border: 1px solid transparent;
}
.faq-contact-btn:hover {
    background-color: #7c3aed;
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(139, 92, 246, 0.4);
}
body.light-mode .faq-contact-btn {
    background-color: #7c3aed;
}
body.light-mode .faq-contact-btn:hover {
    background-color: #6d28d9;
}
/* === FIN: ESTILOS BOTÓN CONTACTO FAQ === */

</style>
</head>
<body style="background-color: #1E1B4B;">
    <?php include 'loader.php'; ?>

    <div class="page-content">
        <div class="page-background-container">
            <div class="background-gradient"></div>
            <div class="background-overlay"></div>
            <div class="floating-shapes">
                <div class="shape"></div><div class="shape"></div><div class="shape"></div><div class="shape"></div>
            </div>
        </div>
        
        <header>
            <div class="header-left">
                <div class="logo"><a href="index.php"><img src="NJOYSINFONDO.jpeg" alt="njoy" id="logoImg" /></a></div>
                <div class="header-nav">
                    <a href="index.php">Inicio</a>
                    <a href="foro.php">Comunidad</a>
                    <?php if ($usuario_logueado): ?>
                        <a href="perfil.php"><?php echo htmlspecialchars($nombre_usuario); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="header-right">
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Buscar juegos y personas...">
                    <div id="searchResults" class="search-results"></div>
                </div>
                <?php if ($usuario_logueado): ?>
                    <div id="notificacionesBtn">
                        <svg id="notificacion-icono-svg" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
                        </svg>
                        <span id="notificacion-alerta"></span>
                        <div id="notificaciones-panel"></div>
                    </div>
                    <div class="usuario" id="usuarioBtn">
                        <img src="" alt="Perfil" id="foto">
                        <div class="usuario-menu" id="usuarioMenu">
                            <a href="perfil.php">👤 Mi Perfil</a>
                            <a href="#configuracion">⚙️ Configuración</a>
                            <a href="#logout">🚪 Cerrar sesión</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="acciones-invitado">
                        <a href="login.html" class="btn-acceso">Iniciar Sesión</a>
                        <a href="registro2.html" class="btn-acceso btn-registro">Registrarse</a>
                    </div>
                <?php endif; ?>
            </div>
      </header>

      <nav>
        <a href="#recomendados-para-ti">Recomendados</a>
        <a href="#ofertas">Ofertas</a>
        <a href="#populares">Populares</a>
        <a href="#free-to-play">Gratis</a>
        <a href="#novedades">Novedades</a>
    </nav>

    <main>
      <div class="banner">
        <div class="banner-content">
          <h1>NJOY GAMING</h1>
          <p>Descubre, juega y conecta en la mejor plataforma de videojuegos</p>
        </div>
      </div>

        <div class="content-wrapper">

            <!-- === INICIO DE LA SECCIÓN: DESTACADOS (CORREGIDA) === -->
            <?php if (!empty($juegos_destacados_principal)): ?>
            <section class="section" id="destacados-principal-container" data-section>
                <h2 class="section-title">Destacados</h2>
                <div class="main-slider-wrapper">
                    <div class="destacados-principal-slider">
                        <div class="slides-container">
                            <?php foreach ($juegos_destacados_principal as $index => $juego):
                                $pagina_url = !empty($juego['pagina_url']) ? htmlspecialchars($juego['pagina_url']) : '#';
                            ?>
                                <div class="slide" data-slide-index="<?php echo $index; ?>">
                                    <div class="slide-image-container">
                                        <a href="<?php echo $pagina_url; ?>" data-juego-id="<?php echo $juego['id']; ?>">
                                            <img src="<?php echo htmlspecialchars($juego['imagen_url']); ?>" alt="<?php echo htmlspecialchars($juego['titulo']); ?>" class="main-slide-image">
                                        </a>
                                    </div>
                                    <div class="slide-content-wrapper">
                                        <a href="<?php echo $pagina_url; ?>" data-juego-id="<?php echo $juego['id']; ?>">
                                            <div class="slide-content">
                                                <h3><?php echo htmlspecialchars($juego['titulo']); ?></h3>
                                                <div class="thumbnails">
                                                    <?php
                                                    $capturas_completas = array_merge([$juego['imagen_url']], $juego['capturas']);
                                                    $capturas = array_slice($capturas_completas, 0, 4);
                                                    while (count($capturas) < 4) {
                                                        $capturas[] = $juego['imagen_url'];
                                                    }
                                                    foreach($capturas as $i => $captura_url): ?>
                                                        <img src="<?php echo htmlspecialchars($captura_url); ?>" alt="thumbnail <?php echo $i + 1; ?>" data-src="<?php echo htmlspecialchars($captura_url); ?>">
                                                    <?php endforeach; ?>
                                                </div>

                                                <div class="tags-container">
                                                    <?php 
                                                        if (!empty($juego['tags'])) {
                                                            $tags = explode(',', $juego['tags']);
                                                            foreach(array_slice($tags, 0, 4) as $tag) {
                                                                echo '<span class="genre-tag">' . htmlspecialchars(trim($tag)) . '</span>';
                                                            }
                                                        }
                                                    ?>
                                                </div>

                                                <div class="price-platform">
                                                    <div class="price-block">
                                                    <?php
                                                        $precio_original = (float)$juego['precio_final'];
                                                        $descuento = (int)$juego['descuento_porcentaje'];

                                                        if ($precio_original == 0 && $descuento == 0) {
                                                            echo '<p class="price free">Free to Play</p>';
                                                        } else if ($descuento > 0) {
                                                            $precio_final_calculado = $precio_original * (1 - ($descuento / 100));
                                                            echo '
                                                                <span class="discount">-' . $descuento . '%</span>
                                                                <div class="price-values">
                                                                    <span class="original-price">$' . number_format($precio_original, 2) . '</span>
                                                                    <span class="final-price">$' . number_format($precio_final_calculado, 2) . '</span>
                                                                </div>';
                                                        } else {
                                                            echo '<div class="price-values"><span class="final-price">$' . number_format($precio_original, 2) . ' USD</span></div>';
                                                        }
                                                    ?>
                                                    </div>
                                                    <span class="platform-icon"></span>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="pagination-dots">
                        <?php foreach ($juegos_destacados_principal as $index => $juego): ?>
                            <span class="dot" data-dot-index="<?php echo $index; ?>"></span>
                        <?php endforeach; ?>
                    </div>
                    <button class="slider-btn prev-main">&lt;</button>
                    <button class="slider-btn next-main">&gt;</button>
                </div>
            </section>
            <?php endif; ?>
            <!-- === FIN DE LA NUEVA SECCIÓN === -->


            <section class="section" id="recomendados-para-ti" data-section>
              <h2 class="section-title">Recomendado para Ti</h2>
              <div class="carrusel-wrapper">
                <div class="carrusel-container" id="carrusel-recomendados">
                  <div class="destacados-grid">
                    <?php
                    if ($result_recomendados && $result_recomendados->num_rows > 0) {
                        $result_recomendados->data_seek(0);
                        while($juego = $result_recomendados->fetch_assoc()) { generarJuegoHTML($juego); }
                    } else { echo "<p>No hay recomendaciones disponibles en este momento.</p>"; }
                    ?>
                  </div>
                </div>
                <button class="carrusel-btn prev" data-target="carrusel-recomendados" data-direction="-1">←</button>
                <button class="carrusel-btn next" data-target="carrusel-recomendados" data-direction="1">→</button>
              </div>
            </section>

            <section class="section" id="ofertas" data-section>
                <h2 class="section-title">Ofertas Especiales</h2>
                <div class="carrusel-wrapper">
                    <div class="carrusel-container" id="carrusel-ofertas">
                        <div class="destacados-grid">
                            <?php
                            if ($result_ofertas_carousel && $result_ofertas_carousel->num_rows > 0) {
                                $result_ofertas_carousel->data_seek(0);
                                while($juego = $result_ofertas_carousel->fetch_assoc()) { generarJuegoHTML($juego); }
                            } else { echo "<p>No hay ofertas disponibles en este momento.</p>"; }
                            ?>
                        </div>
                    </div>
                    <button class="carrusel-btn prev" data-target="carrusel-ofertas" data-direction="-1">←</button>
                    <button class="carrusel-btn next" data-target="carrusel-ofertas" data-direction="1">→</button>
                </div>
            </section>

            <!-- === INICIO: NUEVO CARRUSEL DE CATEGORÍAS === -->
            <?php if (!empty($categorias_para_mostrar)): ?>
            <section class="section" id="explorar-por-categoria" data-section>
                <h2 class="section-title">Explorar por Categoría</h2>
                <div class="carrusel-wrapper">
                    <div class="carrusel-container" id="carrusel-categorias">
                        <div class="categorias-grid">
                             <?php foreach ($categorias_para_mostrar as $categoria): ?>
                                <a href="categoria.php?nombre=<?php echo urlencode($categoria['nombre']); ?>" class="categoria-card">
                                    <div class="categoria-background">
                                        <?php 
                                        $imagenes_a_mostrar = $categoria['imagenes'];
                                        while (count($imagenes_a_mostrar) < 16 && count($imagenes_a_mostrar) > 0) {
                                            $imagenes_a_mostrar = array_merge($imagenes_a_mostrar, $imagenes_a_mostrar);
                                        }
                                        $imagenes_a_mostrar = array_slice($imagenes_a_mostrar, 0, 16);

                                        foreach ($imagenes_a_mostrar as $img_url): ?>
                                            <img src="<?php echo htmlspecialchars($img_url); ?>" alt="Fondo <?php echo htmlspecialchars($categoria['nombre']); ?>">
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="categoria-overlay"></div>
                                    <span class="categoria-label"><?php echo htmlspecialchars(strtoupper($categoria['nombre'])); ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button class="carrusel-btn prev" data-target="carrusel-categorias" data-direction="-1">←</button>
                    <button class="carrusel-btn next" data-target="carrusel-categorias" data-direction="1">→</button>
                </div>
            </section>
            <?php endif; ?>
            <!-- === FIN: NUEVO CARRUSEL DE CATEGORÍAS === -->
            
            <section class="section" id="populares" data-section>
                <h2 class="section-title">Títulos Populares</h2>
                <div class="carrusel-wrapper">
                    <div class="carrusel-container" id="carrusel-populares">
                        <div class="destacados-grid">
                            <?php
                            if ($result_populares && $result_populares->num_rows > 0) {
                                 $result_populares->data_seek(0);
                                while($juego = $result_populares->fetch_assoc()) { generarJuegoHTML($juego); }
                            } else { echo "<p>Aún no hay títulos populares. ¡Sé el primero en descubrir uno!</p>"; }
                            ?>
                        </div>
                    </div>
                    <button class="carrusel-btn prev" data-target="carrusel-populares" data-direction="-1">←</button>
                    <button class="carrusel-btn next" data-target="carrusel-populares" data-direction="1">→</button>
                </div>
            </section>

            <section class="section" id="novedades" data-section>
              <h2 class="section-title">Novedades</h2>
              <div class="carrusel-automatico">
                <div class="destacados-grid">
                  <?php
                    if ($result_novedades_carousel && $result_novedades_carousel->num_rows > 0) {
                        $result_novedades_carousel->data_seek(0);
                        $novedades_juegos = $result_novedades_carousel->fetch_all(MYSQLI_ASSOC);
                        $juegos_duplicados = array_merge($novedades_juegos, $novedades_juegos);
                        foreach ($juegos_duplicados as $juego) { generarJuegoHTML($juego); }
                    } else { echo "<p>No hay novedades disponibles.</p>"; }
                  ?>
                </div>
              </div>
            </section>
            
            <section class="section" id="free-to-play" data-section>
                <h2 class="section-title">Juega Gratis</h2>
                <div class="carrusel-wrapper">
                    <div class="carrusel-container" id="carrusel-f2p">
                        <div class="destacados-grid">
                            <?php
                            if ($result_f2p && $result_f2p->num_rows > 0) {
                                $result_f2p->data_seek(0);
                                while($juego = $result_f2p->fetch_assoc()) { generarJuegoHTML($juego); }
                            } else { echo "<p>No hay juegos gratuitos disponibles en este momento.</p>"; }
                            ?>
                        </div>
                    </div>
                    <button class="carrusel-btn prev" data-target="carrusel-f2p" data-direction="-1">←</button>
                    <button class="carrusel-btn next" data-target="carrusel-f2p" data-direction="1">→</button>
                </div>
            </section>
            <section class="section" id="proximamente" data-section>
              <h2 class="section-title">Próximamente</h2>
              <div class="carrusel-wrapper">
                <div class="carrusel-container" id="carrusel-proximamente">
                  <div class="destacados-grid">
                    <?php
                    if ($result_proximamente_carousel && $result_proximamente_carousel->num_rows > 0) {
                        $result_proximamente_carousel->data_seek(0);
                        while($juego = $result_proximamente_carousel->fetch_assoc()) { generarJuegoHTML($juego); }
                    } else { echo "<p>No hay anuncios de próximos juegos.</p>"; }
                    ?>
                  </div>
                </div>
                <button class="carrusel-btn prev" data-target="carrusel-proximamente" data-direction="-1">←</button>
                <button class="carrusel-btn next" data-target="carrusel-proximamente" data-direction="1">→</button>
              </div>
            </section>
        </div> <!-- Cierre del primer content-wrapper -->

        <div class="lists-section-container" data-section>
            <div class="content-wrapper">
                <div id="explorar-listas">
                    <div class="tabs-container">
                        <button class="tab-link active" data-tab="novedades-populares">Novedades populares</button>
                        <button class="tab-link" data-tab="ofertas-populares">Ofertas</button>
                        <button class="tab-link" data-tab="proximamente-lista">Próximamente</button>
                        <button class="tab-link" data-tab="gratuitos-populares">Gratuitos populares</button>
                    </div>

                    <div id="novedades-populares" class="tab-content active">
                        <div class="juegos-lista">
                            <?php
                            if ($result_novedades_lista && $result_novedades_lista->num_rows > 0) {
                                $result_novedades_lista->data_seek(0);
                                while($juego = $result_novedades_lista->fetch_assoc()) { generarJuegoFilaHTML($juego); }
                            } else { echo "<p>No hay novedades disponibles.</p>"; }
                            ?>
                        </div>
                    </div>

                    <div id="ofertas-populares" class="tab-content">
                        <div class="juegos-lista">
                            <?php
                            if ($result_ofertas_lista && $result_ofertas_lista->num_rows > 0) {
                                $result_ofertas_lista->data_seek(0);
                                while($juego = $result_ofertas_lista->fetch_assoc()) { generarJuegoFilaHTML($juego); }
                            } else { echo "<p>No hay ofertas disponibles en este momento.</p>"; }
                            ?>
                        </div>
                    </div>

                    <div id="proximamente-lista" class="tab-content">
                        <div class="juegos-lista">
                            <?php
                            if ($result_proximamente_lista && $result_proximamente_lista->num_rows > 0) {
                                $result_proximamente_lista->data_seek(0);
                                while($juego = $result_proximamente_lista->fetch_assoc()) { generarJuegoFilaHTML($juego); }
                            } else { echo "<p>No hay próximos lanzamientos anunciados.</p>"; }
                            ?>
                        </div>
                    </div>

                    <div id="gratuitos-populares" class="tab-content">
                        <div class="juegos-lista">
                             <?php
                            if ($result_gratuitos_populares && $result_gratuitos_populares->num_rows > 0) {
                                $result_gratuitos_populares->data_seek(0);
                                while($juego = $result_gratuitos_populares->fetch_assoc()) { generarJuegoFilaHTML($juego); }
                            } else { echo "<p>No hay juegos gratuitos populares en este momento.</p>"; }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($usuario_logueado): ?>
        <div class="content-wrapper">
            <section class="section" id="feed-de-amigos" data-section>
                <h2 class="section-title">Actividad de Amigos</h2>
                <div class="feed-container" id="feed-container">
                    <!-- El Skeleton Loader se insertará aquí -->
                </div>
            </section>
        </div>
        <?php endif; ?>

        <div class="content-wrapper">
            <section class="section" data-section>
              <h2 class="section-title">Explorar NJOY</h2>
              <div class="explorar-botones">
                <a href="#">Novedades</a>
                <a href="#">Ofertas</a>
                <a href="#">Juegos gratuitos</a>
                <a href="#">Por etiquetas de usuario</a>
              </div>
            </section>
        </div>
        
        <!-- === INICIO: SECCIÓN DE PREGUNTAS FRECUENTES (NUEVA ESTRUCTURA) === -->
        <div class="faq-section-container" id="faq" data-section>
            <div class="content-wrapper">
                <button class="faq-main-header">
                    <span>Preguntas Frecuentes</span>
                    <span class="faq-main-icon">▼</span>
                </button>
                <div class="faq-content-wrapper">
                    <div class="faq-container">
                        <div class="faq-item">
                            <button class="faq-question">
                                <span>¿Cómo puedo comprar un juego?</span>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <p>Todavia no implementamos la funcion de compra ya que esta pagina es solo la version de prueba del sistema.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">
                                <span>¿Qué pasa si un juego que compré está en oferta poco después?</span>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <p>Nuestra política de precios es dinámica. Si un juego que compraste a precio completo entra en oferta en un plazo de 48 horas tras tu compra, contáctanos y te ofreceremos un cupón por la diferencia para tu próxima compra.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">
                                <span>¿Los juegos tienen requerimientos de sistema?</span>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <p>Sí, cada juego tiene una sección de "Requerimientos del Sistema" en su página de producto. Asegúrate de que tu PC cumple con los requisitos mínimos antes de realizar la compra para garantizar una experiencia de juego óptima.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">
                                <span>¿Cómo funcionan las devoluciones?</span>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <p>Puedes solicitar una devolución de cualquier juego si lo has jugado menos de 2 horas y la compra se realizó en los últimos 14 días. Las solicitudes se procesan a través de tu perfil en la sección "Historial de compras".</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-contact-container">
                        <a href="mailto:ticketsupport@njoy3077.shop" class="faq-contact-btn">¿No se resolvió tu duda? Contáctanos</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- === FIN: SECCIÓN DE PREGUNTAS FRECUENTES === -->

    </main>

      <footer>
        <p id="footer-text">© 2025 NJOY - Tu tienda de videojuegos. Todos los derechos reservados.</p>
      </footer>
    </div> <!-- Cierre de .page-content -->

  <!-- MODALES -->
  <div class="modal" id="modalLogout">
    <div class="modal-content">
      <span class="cerrar" data-close="modalLogout">&times;</span>
      <h2>🚪 Cerrar sesión</h2>
      <p>¿Estás seguro de que deseas cerrar sesión?</p>
      <button id="confirmarLogout" style="background: #ef4444;">Sí, cerrar sesión</button>
      <button id="cancelarLogout" class="modal-button-secondary">Cancelar</button>
    </div>
  </div>
  <div class="modal" id="modalConfig">
    <div class="modal-content">
      <span class="cerrar" data-close="modalConfig">&times;</span>
      <h2>⚙️ Configuración</h2>
      
      <label>Modo de visualización:</label>
      <div class="theme-switch-wrapper">
        <label class="theme-switch" for="theme-toggle"><input type="checkbox" id="theme-toggle" /><span class="slider"></span></label>
        <span id="theme-label-text">Modo Oscuro</span>
      </div>
      
      <button id="guardarConfig" style="background: #8B5CF6; width: 100%;">Guardar cambios</button>
    </div>
  </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isUserLoggedIn = <?php echo json_encode($usuario_logueado); ?>;
    
    // ===================================================================
    // INICIO DE ANIMACIONES Y EFECTOS
    // ===================================================================

    const sections = document.querySelectorAll('[data-section]');
    const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
    const sectionObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                entry.target.style.transitionDelay = `${index * 150}ms`;
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    sections.forEach(section => sectionObserver.observe(section));
    
    const gameCards = document.querySelectorAll('.juego');
    gameCards.forEach(card => {
        // Lógica para elevar la sección contenedora y evitar recortes
        const section = card.closest('.section');
        if (section) {
            card.addEventListener('mouseenter', () => {
                section.classList.add('is-hovered');
            });
            card.addEventListener('mouseleave', () => {
                section.classList.remove('is-hovered');
            });
        }
    });

    // ===================================================================
    // FIN DE ANIMACIONES Y EFECTOS
    // ===================================================================

    // ===================================================================
    // LÓGICA DEL SLIDER DESTACADOS PRINCIPAL
    // ===================================================================
    const sliderContainer = document.querySelector('.main-slider-wrapper');
    if (sliderContainer) {
        const slidesContainer = sliderContainer.querySelector('.slides-container');
        const slides = sliderContainer.querySelectorAll('.slide');
        const prevBtn = sliderContainer.querySelector('.prev-main');
        const nextBtn = sliderContainer.querySelector('.next-main');
        const dots = sliderContainer.querySelectorAll('.dot');
        let currentIndex = 0;
        let slideInterval;

        function goToSlide(index) {
            if (!slidesContainer || !dots[index]) return;
            slidesContainer.style.transform = `translateX(-${index * 100}%)`;
            dots.forEach(dot => dot.classList.remove('active'));
            dots[index].classList.add('active');
            currentIndex = index;
        }

        function nextSlide() {
            const newIndex = (currentIndex + 1) % slides.length;
            goToSlide(newIndex);
        }
        
        function prevSlide() {
            const newIndex = (currentIndex - 1 + slides.length) % slides.length;
            goToSlide(newIndex);
        }

        function startAutoplay() {
            stopAutoplay();
            slideInterval = setInterval(nextSlide, 6000); // Cambia cada 6 segundos
        }

        function stopAutoplay() {
            clearInterval(slideInterval);
        }

        if (slides.length > 1) {
            nextBtn.addEventListener('click', () => {
                nextSlide();
                stopAutoplay();
                startAutoplay();
            });

            prevBtn.addEventListener('click', () => {
                prevSlide();
                stopAutoplay();
                startAutoplay();
            });
            
            dots.forEach(dot => {
                dot.addEventListener('click', (e) => {
                    const index = parseInt(e.target.dataset.dotIndex, 10);
                    goToSlide(index);
                    stopAutoplay();
                    startAutoplay();
                });
            });

            sliderContainer.addEventListener('mouseenter', stopAutoplay);
            sliderContainer.addEventListener('mouseleave', startAutoplay);
            
            goToSlide(0);
            startAutoplay();

            // === INICIO: LÓGICA DE GALERÍA INTERACTIVA EN DESTACADOS ===
            slides.forEach(slide => {
                const mainImage = slide.querySelector('.main-slide-image');
                const thumbnails = slide.querySelectorAll('.thumbnails img');
                
                thumbnails.forEach(thumb => {
                    thumb.addEventListener('mouseenter', () => {
                        mainImage.style.opacity = '0';
                        setTimeout(() => {
                            mainImage.src = thumb.dataset.src;
                            mainImage.style.opacity = '1';
                        }, 150);
                    });
                });
            });
            // === FIN: LÓGICA DE GALERÍA INTERACTIVA ===

        } else if (slides.length > 0) {
            goToSlide(0);
            prevBtn.style.display = 'none';
            nextBtn.style.display = 'none';
            sliderContainer.querySelector('.pagination-dots').style.display = 'none';
        } else {
             const mainSliderSection = document.getElementById('destacados-principal-container');
             if (mainSliderSection) mainSliderSection.style.display = 'none';
        }
    }


    if (isUserLoggedIn) {
        let currentUserData = { nombre: '', foto: '' };
        const fotoPerfilHeader = document.querySelector("#usuarioBtn img");
        const usuarioBtn = document.getElementById("usuarioBtn");
        const usuarioMenu = document.getElementById("usuarioMenu");
        
        if(usuarioBtn) {
            usuarioBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                usuarioMenu.style.display = usuarioMenu.style.display === "block" ? "none" : "block";
            });
        }
        document.addEventListener("click", (e) => {
            const target = e.target;
            if (usuarioMenu && usuarioMenu.style.display === "block" && !usuarioMenu.contains(target) && !usuarioBtn.contains(target)) {
                usuarioMenu.style.display = "none";
            }
        });

        document.querySelectorAll(".usuario-menu a").forEach(link => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                const href = link.getAttribute("href");
                if (href === "#configuracion") {
                    document.getElementById('modalConfig').style.display = "flex";
                } else if (href === "#logout") {
                    document.getElementById('modalLogout').style.display = 'flex';
                } else {
                    window.location.href = href;
                }
                if (usuarioMenu) usuarioMenu.style.display = 'none';
            });
        });

        fetch('obtener_datos_usuario.php?v=' + new Date().getTime())
            .then(response => response.json())
            .then(data => {
                if (data.status === "ok") {
                    currentUserData = data;
                    if(fotoPerfilHeader) fotoPerfilHeader.src = data.foto + "?t=" + new Date().getTime();
                }
            });
        
        const guardarConfigBtn = document.getElementById('guardarConfig');
        if(guardarConfigBtn) {
            guardarConfigBtn.addEventListener('click', () => {
                document.getElementById('modalConfig').style.display = 'none';
            });
        }

        const confirmarLogoutBtn = document.getElementById("confirmarLogout");
        if(confirmarLogoutBtn) {
            confirmarLogoutBtn.addEventListener("click", () => {
                fetch('logout.php', { method: 'POST' }).finally(() => window.location.href = 'index.php');
            });
        }

        const notificacionesBtn = document.getElementById('notificacionesBtn');
        const notificacionesPanel = document.getElementById('notificaciones-panel');
        const notificacionAlerta = document.getElementById('notificacion-alerta');
        
        function checkUnreadNotifications() {
             fetch('/api.php?action=get_notifications')
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'ok' && data.unread_count > 0) {
                        notificacionAlerta.style.display = 'block';
                    } else {
                        notificacionAlerta.style.display = 'none';
                    }
                });
        }

        function cargarNotificaciones() {
            if(!notificacionesPanel) return;

            fetch('/api.php?action=get_notifications')
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'ok') {
                        notificacionesPanel.innerHTML = '';
                        if (data.notificaciones.length > 0) {
                             data.notificaciones.forEach(notif => {
                                const profileLink = `perfil.php?id=${notif.usuario_origen_id}`;
                                const userLink = `<a href="${profileLink}"><b>${notif.origen_nombre}</b></a>`;
                                let texto = '';
                                let acciones = '';

                                switch(notif.tipo_notificacion) {
                                    case 'SOLICITUD_AMISTAD':
                                        texto = `${userLink} quiere ser tu amigo.`;
                                        acciones = `<div class="notificacion-acciones">
                                            <button class="notif-action-btn accept" data-action="aceptar" data-solicitante-id="${notif.usuario_origen_id}">Aceptar</button>
                                            <button class="notif-action-btn reject" data-action="rechazar" data-solicitante-id="${notif.usuario_origen_id}">Rechazar</button>
                                        </div>`;
                                        break;
                                    case 'SOLICITUD_ACEPTADA':
                                        texto = `Ahora eres amigo de ${userLink}.`;
                                        break;
                                    case 'AMISTAD_CONFIRMADA':
                                        texto = `Has aceptado la solicitud de amistad de ${userLink}.`;
                                        break;
                                    case 'AMISTAD_RECHAZADA':
                                        texto = `Has rechazado la solicitud de amistad de ${userLink}.`;
                                        break;
                                    case 'LIKE_RESENA':
                                        texto = `A ${userLink} le ha gustado tu reseña.`;
                                        break;
                                    case 'NUEVO_COMENTARIO_PERFIL':
                                        texto = `${userLink} ha comentado en tu perfil.`;
                                        break;
                                    case 'RESPUESTA_COMENTARIO':
                                        texto = `${userLink} ha respondido a tu comentario.`;
                                        break;
                                    default:
                                        texto = `${userLink} ha interactuado contigo.`;
                                }
                                const notifHtml = `
                                <div class="notificacion-item ${notif.leido == 0 ? 'no-leida' : ''}" data-notif-id="${notif.id}">
                                    <a href="${profileLink}"><img src="${notif.origen_foto}" alt="Avatar" class="notificacion-avatar"></a>
                                    <div class="notificacion-contenido">
                                        <p>${texto}</p>
                                        ${acciones}
                                    </div>
                                </div>`;
                                notificacionesPanel.innerHTML += notifHtml;
                            });
                        } else {
                            notificacionesPanel.innerHTML = '<p style="padding: 15px; text-align:center;">No tienes notificaciones.</p>';
                        }
                    }
                });
        }

        if(notificacionesBtn) {
            notificacionesBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isVisible = notificacionesPanel.style.display === 'block';
                notificacionesPanel.style.display = isVisible ? 'none' : 'block';
                if (!isVisible) {
                    cargarNotificaciones();
                    setTimeout(() => {
                        fetch('/api.php?action=mark_notifications_read', { method: 'POST' })
                            .then(res => res.json())
                            .then(data => {
                                if(data.status === 'ok' && data.affected_rows > 0) {
                                    notificacionAlerta.style.display = 'none';
                                    notificacionesPanel.querySelectorAll('.no-leida').forEach(item => item.classList.remove('no-leida'));
                                }
                            });
                    }, 2500);
                }
            });
        }

        if(notificacionesPanel) {
            notificacionesPanel.addEventListener('click', e => {
                e.stopPropagation();
                const target = e.target;
                if(target.classList.contains('notif-action-btn')) {
                    const accion = target.dataset.action;
                    const solicitanteId = target.dataset.solicitanteId;
                    const notifItemContent = target.closest('.notificacion-contenido');

                    const formData = new FormData();
                    formData.append('solicitante_id', solicitanteId);
                    formData.append('accion', accion);

                    fetch('gestionar_solicitud.php', { method: 'POST', body: formData })
                        .then(res => res.json())
                        .then(data => {
                            if (data.status === 'ok') {
                                cargarNotificaciones();
                            } else {
                                notifItemContent.innerHTML = `<p class="notif-feedback" style="color: #fca5a5;">${data.msg || 'Error al procesar.'}</p>`;
                            }
                        });
                }
            });
            document.addEventListener('click', (e) => {
                if (notificacionesPanel.style.display === 'block' && !notificacionesBtn.contains(e.target)) {
                    notificacionesPanel.style.display = 'none';
                }
            });
        }
        
        checkUnreadNotifications();
    }
    
    document.querySelectorAll(".cerrar, [data-close], #cancelarLogout").forEach(el => {
        el.addEventListener("click", () => {
            el.closest('.modal').style.display = "none";
        });
    });
    document.querySelectorAll(".modal").forEach(modal => {
        modal.addEventListener("click", e => {
            if (e.target === modal) {
                modal.style.display = "none";
            }
        });
    });

    document.querySelectorAll('.carrusel-btn').forEach(button => {
        button.addEventListener('click', () => {
            const idCarrusel = button.dataset.target;
            const direccion = parseInt(button.dataset.direction, 10);
            const container = document.getElementById(idCarrusel);
            if (!container) return;
            
            let card = container.querySelector('.categoria-card, .juego');
            if (!card) return;
            
            const cardWidth = card.offsetWidth;
            const grid = container.querySelector('.destacados-grid, .categorias-grid');
            const gap = parseInt(window.getComputedStyle(grid).gap) || 22;
            const scrollAmount = (cardWidth + gap) * 2;
            
            container.scrollBy({ left: direccion * scrollAmount, behavior: 'smooth' });
        });
    });

    const themeToggle = document.getElementById('theme-toggle');
    const themeLabel = document.getElementById('theme-label-text');
    const logoImg = document.getElementById('logoImg');
    function setTheme(theme) {
        document.body.classList.toggle('light-mode', theme === 'light');
        if (themeToggle) themeToggle.checked = (theme === 'light');
        if (themeLabel) themeLabel.textContent = (theme === 'light') ? 'Modo Claro' : 'Modo Oscuro';
        if(logoImg) logoImg.src = (theme === 'light') ? 'NJOY_LOGO_CLARO.jpeg' : 'NJOYSINFONDO.jpeg';
    }
    if(themeToggle) {
        themeToggle.addEventListener('change', () => {
            const newTheme = themeToggle.checked ? 'light' : 'dark';
            localStorage.setItem('theme', newTheme);
            setTheme(newTheme);
        });
    }
    const savedTheme = localStorage.getItem('theme') || 'dark';
    setTheme(savedTheme);
    const tabLinks = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');
    tabLinks.forEach(link => {
        link.addEventListener('click', () => {
            const tabId = link.getAttribute('data-tab');
            tabLinks.forEach(item => item.classList.remove('active'));
            tabContents.forEach(item => item.classList.remove('active'));
            link.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    let lastScrollTop = 0;
    const nav = document.querySelector('nav');
    window.addEventListener('scroll', function() {
        if (!nav) return;
        const currentScroll = window.scrollY || document.documentElement.scrollTop;
        if (currentScroll > lastScrollTop && currentScroll > 100) {
            nav.style.transform = 'translateY(-100%)';
            nav.style.opacity = '0';
        } else if (currentScroll < lastScrollTop) {
            nav.style.transform = 'translateY(0)';
            nav.style.opacity = '1';
        }
        lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
    });

    document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offsetTop = target.offsetTop - 120;
                window.scrollTo({ top: offsetTop, behavior: 'smooth' });
            }
        });
    });

    const carruseles = document.querySelectorAll('.carrusel-container');
    carruseles.forEach(carrusel => {
        let isDown = false, startX, scrollLeft;
        carrusel.addEventListener('mousedown', (e) => { isDown = true; carrusel.style.cursor = 'grabbing'; startX = e.pageX - carrusel.offsetLeft; scrollLeft = carrusel.scrollLeft; });
        carrusel.addEventListener('mouseleave', () => { isDown = false; carrusel.style.cursor = 'grab'; });
        carrusel.addEventListener('mouseup', () => { isDown = false; carrusel.style.cursor = 'grab'; });
        carrusel.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - carrusel.offsetLeft;
            const walk = (x - startX) * 2;
            carrusel.scrollLeft = scrollLeft - walk;
        });
    });
    
    document.addEventListener('click', function(e) {
        const juegoCard = e.target.closest('.juego, .juego-fila, .slide-content-wrapper > a, .slide-image-container > a');
        
        if (isUserLoggedIn && juegoCard && juegoCard.dataset.juegoId) {
            const juegoId = juegoCard.dataset.juegoId;
            const formData = new FormData();
            formData.append('juego_id', juegoId);
            navigator.sendBeacon('registrar_clic.php', formData);
        }
    });

    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    let searchTimeout;

    if(searchInput){
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimeout);
            const term = searchInput.value.trim();

            if (term.length < 2) {
                searchResults.style.display = 'none';
                return;
            }

            searchTimeout = setTimeout(() => {
                fetch(`buscar.php?termino=${encodeURIComponent(term)}`)
                    .then(response => response.json())
                    .then(data => {
                        searchResults.innerHTML = '';
                        if (data.juegos.length === 0 && data.usuarios.length === 0) {
                            searchResults.innerHTML = '<div class="search-item">No se encontraron resultados.</div>';
                        } else {
                            if (data.juegos.length > 0) {
                                let gamesHtml = '<div class="search-category">Juegos</div>';
                                data.juegos.forEach(juego => { gamesHtml += `<a href="${juego.pagina_url || '#'}" class="search-item"><img src="${juego.imagen_url}" alt=""><span>${juego.titulo}</span></a>`; });
                                searchResults.innerHTML += usersHtml;
                            }
                        }
                        searchResults.style.display = 'block';
                    });
            }, 250);
        });

        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target)) {
                searchResults.style.display = 'none';
            }
        });
    }
    
    if (isUserLoggedIn) {
        const feedContainer = document.getElementById('feed-container');

        function renderSkeletonLoader() {
            let skeletonHTML = '';
            for (let i = 0; i < 3; i++) {
                skeletonHTML += `
                <div class="feed-item">
                    <div class="feed-avatar"><div class="skeleton skeleton-avatar"></div></div>
                    <div class="feed-content">
                        <div class="feed-header">
                            <div class="skeleton skeleton-line skeleton-line-long" style="margin-bottom: 10px;"></div>
                        </div>
                        <div class="feed-timestamp"><div class="skeleton skeleton-line skeleton-line-short"></div></div>
                    </div>
                </div>`;
            }
            if(feedContainer) feedContainer.innerHTML = skeletonHTML;
        }

        function cargarFeed() {
            if (!feedContainer) return;

            renderSkeletonLoader();

            fetch('/api.php?action=get_feed')
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'ok') {
                        if (data.feed.length > 0) {
                        feedContainer.innerHTML = '';
                        data.feed.slice(0, 5).forEach(item => { // <-- Línea modificada para mostrar solo 5
                            feedContainer.innerHTML += renderFeedItem(item);
                        });
                        } else {
                            feedContainer.innerHTML = '<p style="text-align: center; color: #9ca3af; width: 100%;">No hay actividad reciente de tus amigos. ¡Sé el primero en reseñar un juego o añadir nuevos amigos!</p>';
                        }
                    } else if (data.msg === 'No autenticado') {
                        const feedSection = document.getElementById('feed-de-amigos');
                        if (feedSection) feedSection.style.display = 'none';
                    } else {
                        feedContainer.innerHTML = `<p style="text-align: center; color: #fca5a5; width: 100%;">Error al cargar la actividad: ${data.msg}</p>`;
                    }
                }).catch(err => {
                    feedContainer.innerHTML = '<p style="text-align: center; color: #fca5a5; width: 100%;">Error de conexión al cargar la actividad.</p>';
                });
        }

        function renderFeedItem(item) {
            let contentHtml = '';
            const userLink = `<a href="perfil.php?id=${item.usuario_id}">${item.nombre}</a>`;

            switch(item.tipo_actividad) {
                case 'NUEVA_RESENA':
                    const gameLink = item.juego ? `<a href="${item.juego.pagina_url}">${item.juego.titulo}</a>` : 'un juego';
                    contentHtml = `${userLink} ha escrito una reseña para ${gameLink}.`;
                    break;
                case 'ELIMINO_RESENA':
                    const deletedGameLink = item.juego ? `<b>${item.juego.titulo}</b>` : 'un juego';
                    contentHtml = `${userLink} eliminó su reseña para ${deletedGameLink}.`;
                    break;
                case 'NUEVO_AMIGO':
                    const friendLink = item.amigo ? `<a href="perfil.php?id=${item.referencia_id}">${item.amigo.nombre}</a>` : 'otro usuario';
                    contentHtml = `${userLink} ahora es amigo de ${friendLink}.`;
                    break;
                case 'NUEVO_COMENTARIO_PERFIL':
                    if (item.perfil_comentado && item.perfil_comentado.nombre) {
                        const profileLink = `<a href="perfil.php?id=${item.referencia_id}">el perfil de ${item.perfil_comentado.nombre}</a>`;
                        contentHtml = `${userLink} ha comentado en ${profileLink}.`;
                    } else {
                        const profileLink = `<a href="perfil.php?id=${item.referencia_id}">el perfil de un usuario</a>`;
                        contentHtml = `${userLink} ha comentado en ${profileLink}.`;
                    }
                    break;
                default:
                    contentHtml = `${userLink} ha realizado una nueva actividad.`;
            }

            const timestamp = new Date(item.timestamp + ' UTC').toLocaleString(undefined, { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });

            return `
                <div class="feed-item">
                    <div class="feed-avatar">
                        <a href="perfil.php?id=${item.usuario_id}"><img src="${item.foto}" alt="${item.nombre}"></a>
                    </div>
                    <div class="feed-content">
                        <div class="feed-header">${contentHtml}</div>
                        <div class="feed-timestamp">${timestamp}</div>
                    </div>
                </div>`;
        }
        
        cargarFeed();
    }
    
    // === INICIO: LÓGICA PARA EL ACORDEÓN DE FAQ (ACTUALIZADA) ===
    const faqMainHeader = document.querySelector('.faq-main-header');
    const faqSectionContainer = document.querySelector('.faq-section-container');
    const faqItems = document.querySelectorAll('.faq-item');

    if (faqMainHeader) {
        faqMainHeader.addEventListener('click', () => {
            faqSectionContainer.classList.toggle('active');
        });
    }
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            faqItems.forEach(i => {
               if (i !== item) i.classList.remove('active');
            });
            
            item.classList.toggle('active');
        });
    });
    // === FIN: LÓGICA PARA EL ACORDEÓN DE FAQ ===

    // --- LÓGICA DEL LOADER ---
    window.addEventListener('load', function() {
        const loader = document.getElementById('loader');
        const pageContent = document.querySelector('.page-content');
        
        if (loader) { 
            loader.classList.add('hidden'); 
        }
        if (pageContent) {
            pageContent.classList.add('loaded');
        }
    });

});
</script>
</body>
</html>
<?php
// Cerramos la conexión a la base de datos al final del script
if (isset($conn)) {
    $conn->close();
}
?>