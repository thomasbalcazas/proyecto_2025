<?php
// like_comentario.php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id'])) {
    die(json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión para dar me gusta.']));
}

require_once 'db.php';
require_once 'social_system.php';

$usuario_id = (int)$_SESSION['usuario_id'];
$comentario_id = isset($_POST['comentario_id']) ? (int)$_POST['comentario_id'] : 0;

if ($comentario_id === 0) {
    die(json_encode(['status' => 'error', 'msg' => 'Comentario no válido.']));
}

$conn->begin_transaction();

try {
    // Verificar si el comentario existe y obtener el ID de su autor
    $stmt_author = $conn->prepare("SELECT autor_id FROM comentarios_perfil WHERE id = ?");
    $stmt_author->bind_param("i", $comentario_id);
    $stmt_author->execute();
    $result_author = $stmt_author->get_result();
    if ($result_author->num_rows === 0) {
        throw new Exception("El comentario no existe.");
    }
    $autor_comentario_id = $result_author->fetch_assoc()['autor_id'];
    $stmt_author->close();

    // Verificar si ya existe un "Me gusta" del usuario actual
    $stmt_check = $conn->prepare("SELECT id FROM likes_comentarios WHERE usuario_id = ? AND comentario_id = ?"); // <-- CAMBIO
    $stmt_check->bind_param("ii", $usuario_id, $comentario_id);
    $stmt_check->execute();
    $like_exists = $stmt_check->get_result()->fetch_assoc();
    $stmt_check->close();

    $xp_change = 1;
    $liked = false;

    if ($like_exists) {
        // --- QUITAR LIKE ---
        $stmt_delete = $conn->prepare("DELETE FROM likes_comentarios WHERE id = ?"); // <-- CAMBIO
        $stmt_delete->bind_param("i", $like_exists['id']);
        $stmt_delete->execute();
        $stmt_delete->close();
        
        $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = GREATEST(0, xp - ?) WHERE id = ?");
        $stmt_xp->bind_param("ii", $xp_change, $autor_comentario_id);
        $stmt_xp->execute();
        $stmt_xp->close();

        $liked = false;
    } else {
        // --- PONER LIKE ---
        $stmt_insert = $conn->prepare("INSERT INTO likes_comentarios (usuario_id, comentario_id) VALUES (?, ?)"); // <-- CAMBIO
        $stmt_insert->bind_param("ii", $usuario_id, $comentario_id);
        $stmt_insert->execute();
        $stmt_insert->close();
        
        $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = xp + ? WHERE id = ?");
        $stmt_xp->bind_param("ii", $xp_change, $autor_comentario_id);
        $stmt_xp->execute();
        $stmt_xp->close();
        
        if ($autor_comentario_id != $usuario_id) {
            generarNotificacion($conn, $autor_comentario_id, $usuario_id, 'LIKE_COMENTARIO', $comentario_id);
        }
        
        $liked = true;
    }

    $conn->commit();
    
    // Obtener el nuevo total de likes de forma segura
    $stmt_count = $conn->prepare("SELECT COUNT(id) AS total FROM likes_comentarios WHERE comentario_id = ?"); // <-- CAMBIO
    $stmt_count->bind_param("i", $comentario_id);
    $stmt_count->execute();
    $total_likes = $stmt_count->get_result()->fetch_assoc()['total'];
    $stmt_count->close();
    
    echo json_encode(['status' => 'ok', 'liked' => $liked, 'total_likes' => (int)$total_likes]);

} catch (Exception $exception) {
    $conn->rollback();
    die(json_encode(['status' => 'error', 'msg' => 'Error de base de datos: ' . $exception->getMessage()]));
}

$conn->close();
?>