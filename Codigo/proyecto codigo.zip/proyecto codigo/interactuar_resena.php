<?php
// interactuar_resena.php (VERSIÓN FINAL CON ACTUALIZACIÓN DE DESTACADA EN TIEMPO REAL)
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'db.php';

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'msg' => 'Error de conexión a la base de datos.']));
}

if (!isset($_SESSION['usuario_id'])) {
    die(json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión.']));
}
$usuario_id = (int)$_SESSION['usuario_id'];

if (!isset($_POST['resena_id']) || !isset($_POST['action'])) {
    die(json_encode(['status' => 'error', 'msg' => 'Datos incompletos.']));
}

$resena_id = (int)$_POST['resena_id'];
$action = $_POST['action'];
$allowed_actions = ['like', 'dislike', 'premio'];

if (!in_array($action, $allowed_actions)) {
    die(json_encode(['status' => 'error', 'msg' => 'Acción no válida.']));
}

// OBTENER EL AUTOR Y EL JUEGO_ID DE LA RESEÑA
$stmt_info = $conn->prepare("SELECT usuario_id, juego_id FROM resenas WHERE id = ?");
$stmt_info->bind_param("i", $resena_id);
$stmt_info->execute();
$result_info = $stmt_info->get_result();
if ($result_info->num_rows === 0) {
    die(json_encode(['status' => 'error', 'msg' => 'La reseña no existe.']));
}
$resena_info = $result_info->fetch_assoc();
$autor_resena_id = (int)$resena_info['usuario_id'];
$juego_id = (int)$resena_info['juego_id']; // Necesitamos esto para encontrar la nueva reseña destacada
$stmt_info->close();

$conn->begin_transaction();

try {
    $stmt_check = $conn->prepare("SELECT id FROM resena_interacciones WHERE resena_id = ? AND usuario_id = ? AND tipo_interaccion = ?");
    $stmt_check->bind_param("iis", $resena_id, $usuario_id, $action);
    $stmt_check->execute();
    $interaction_exists = $stmt_check->get_result()->fetch_assoc();
    $stmt_check->close();

    if ($interaction_exists) {
        $stmt_delete = $conn->prepare("DELETE FROM resena_interacciones WHERE id = ?");
        $stmt_delete->bind_param("i", $interaction_exists['id']);
        $stmt_delete->execute();
        $stmt_delete->close();

        if ($autor_resena_id !== $usuario_id) {
            $xp_perdido = 0;
            if ($action === 'like') $xp_perdido = 2;
            elseif ($action === 'premio') $xp_perdido = 15;

            if ($xp_perdido > 0) {
                $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = GREATEST(0, xp - ?) WHERE id = ?"); 
                $stmt_xp->bind_param("ii", $xp_perdido, $autor_resena_id);
                $stmt_xp->execute();
                $stmt_xp->close();
            }
        }
    } else {
        if ($action === 'like' || $action === 'dislike') {
            $opposite_action = ($action === 'like') ? 'dislike' : 'like';
            $stmt_remove_opposite = $conn->prepare("DELETE FROM resena_interacciones WHERE resena_id = ? AND usuario_id = ? AND tipo_interaccion = ?");
            $stmt_remove_opposite->bind_param("iis", $resena_id, $usuario_id, $opposite_action);
            $stmt_remove_opposite->execute();
            $stmt_remove_opposite->close();
        }
        
        $stmt_insert = $conn->prepare("INSERT INTO resena_interacciones (resena_id, usuario_id, tipo_interaccion) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("iis", $resena_id, $usuario_id, $action);
        $stmt_insert->execute();
        $stmt_insert->close();

        if ($autor_resena_id !== $usuario_id) { 
            $xp_ganado = 0;
            if ($action === 'like') $xp_ganado = 2;
            elseif ($action === 'premio') $xp_ganado = 15;

            if ($xp_ganado > 0) {
                $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = xp + ? WHERE id = ?");
                $stmt_xp->bind_param("ii", $xp_ganado, $autor_resena_id);
                $stmt_xp->execute();
                $stmt_xp->close();
            }
        }
    }

    $conn->commit();

} catch (mysqli_sql_exception $exception) {
    $conn->rollback();
    die(json_encode(['status' => 'error', 'msg' => 'Error de base de datos: ' . $exception->getMessage()]));
}

// --- ¡NUEVO! DETERMINAR LA NUEVA RESEÑA DESTACADA ---
$new_top_review_id = null;
$stmt_top = $conn->prepare("SELECT id FROM resenas WHERE juego_id = ? ORDER BY premios DESC, likes DESC, timestamp DESC LIMIT 1");
$stmt_top->bind_param("i", $juego_id);
$stmt_top->execute();
$result_top = $stmt_top->get_result();
if ($row_top = $result_top->fetch_assoc()) {
    $new_top_review_id = (int)$row_top['id'];
}
$stmt_top->close();
// --- FIN ---

// Devolver los nuevos contadores
$query_counts = "
    SELECT
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND tipo_interaccion = 'like') AS likes,
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND tipo_interaccion = 'dislike') AS dislikes,
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND tipo_interaccion = 'premio') AS premios
";
$stmt_counts = $conn->prepare($query_counts);
$stmt_counts->bind_param("iii", $resena_id, $resena_id, $resena_id);
$stmt_counts->execute();
$new_counts = $stmt_counts->get_result()->fetch_assoc();
$stmt_counts->close();

$query_user_interactions = "
    SELECT
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND usuario_id = ? AND tipo_interaccion = 'like') > 0 AS `like`,
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND usuario_id = ? AND tipo_interaccion = 'dislike') > 0 AS `dislike`,
        (SELECT COUNT(*) FROM resena_interacciones WHERE resena_id = ? AND usuario_id = ? AND tipo_interaccion = 'premio') > 0 AS `premio`
";
$stmt_user = $conn->prepare($query_user_interactions);
$stmt_user->bind_param("iiiiii", $resena_id, $usuario_id, $resena_id, $usuario_id, $resena_id, $usuario_id);
$stmt_user->execute();
$user_interactions = $stmt_user->get_result()->fetch_assoc();
$stmt_user->close();

$conn->close();

echo json_encode([
    'status' => 'ok',
    'newCounts' => $new_counts,
    'userInteractions' => $user_interactions,
    'newTopReviewId' => $new_top_review_id // <-- ¡NUEVO DATO EN LA RESPUESTA!
]);
?>