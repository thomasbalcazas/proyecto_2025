<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

$usuario_logueado = isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
$usuario_id_actual = $_SESSION['usuario_id'] ?? null;

require_once 'db.php';

// --- Lógica para manejar la creación de un nuevo post ---
$error_post = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_post'])) {
    if (!$usuario_logueado) {
        header('Location: login.html');
        exit;
    }

    $titulo = trim($_POST['post_title']);
    $descripcion = trim($_POST['post_description']);
    $juego_id = $_POST['juego_id'] ?: NULL;
    $imagen_url = NULL;

    if (empty($titulo)) {
        $error_post = "El título de la publicación es obligatorio.";
    } elseif (!isset($_FILES['post_image']) || $_FILES['post_image']['error'] != 0) {
        $error_post = "Debes seleccionar una imagen para tu publicación.";
    } else {
        $target_dir = "uploads/foro_images/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        $imageFileType = strtolower(pathinfo($_FILES["post_image"]["name"], PATHINFO_EXTENSION));
        $target_file = $target_dir . uniqid('post_', true) . '.' . $imageFileType;
        $allowed_types = ['jpg', 'png', 'jpeg', 'gif', 'webp'];

        if (in_array($imageFileType, $allowed_types) && $_FILES["post_image"]["size"] < 5000000) { // 5MB
            if (move_uploaded_file($_FILES["post_image"]["tmp_name"], $target_file)) {
                $imagen_url = $target_file;
            } else {
                $error_post = "Hubo un error al subir tu imagen.";
            }
        } else {
            $error_post = "Archivo no válido. Solo se permiten imágenes (JPG, PNG, GIF, WEBP) de menos de 5MB.";
        }

        if (empty($error_post)) {
            $stmt = $conn->prepare("INSERT INTO foro_posts (usuario_id, juego_id, titulo, descripcion, imagen_url) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisss", $usuario_id_actual, $juego_id, $titulo, $descripcion, $imagen_url);
            
            if ($stmt->execute()) {
                header("Location: foro.php");
                exit;
            } else {
                $error_post = "No se pudo crear la publicación. Inténtalo de nuevo.";
            }
            $stmt->close();
        }
    }
}


// Obtener todos los juegos para el selector
$juegos_para_selector = [];
$sql_juegos = "SELECT id, titulo FROM juegos ORDER BY titulo ASC";
$result_juegos = $conn->query($sql_juegos);
if ($result_juegos) {
    $juegos_para_selector = $result_juegos->fetch_all(MYSQLI_ASSOC);
}

// Obtener todos los posts del foro
$posts_del_foro = [];
$sql_posts = "
    SELECT
        fp.id, fp.titulo, fp.imagen_url, fp.fecha_creacion,
        u.nombre as autor_nombre, u.foto as autor_foto, u.id as autor_id,
        j.titulo as juego_titulo, j.pagina_url as juego_url
    FROM foro_posts fp
    JOIN usuarios u ON fp.usuario_id = u.id
    LEFT JOIN juegos j ON fp.juego_id = j.id
    ORDER BY fp.fecha_creacion DESC;
";
$result_posts = $conn->query($sql_posts);
if ($result_posts) {
    $posts_del_foro = $result_posts->fetch_all(MYSQLI_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Allerta+Stencil&display=swap" rel="stylesheet">
  <title>Comunidad NJOY - Foro</title>
  <link rel="icon" type="image/x-icon" href="/NJOYSINFONDO.ico">

  <style>
    /* Estilos generales */
    #loader { position: fixed; inset: 0; z-index: 99999; background-color: #1E1B4B; display: flex; align-items: center; justify-content: center; transition: opacity 0.5s ease-out, visibility 0s linear 0.5s; opacity: 1; visibility: visible; }
    #loader.hidden { opacity: 0; visibility: hidden; pointer-events: none; }
    #loader img { width: 120px; height: auto; animation: pulse 1.5s ease-in-out infinite; filter: drop-shadow(0 0 15px rgba(139, 92, 246, 0.7)); }
    @keyframes pulse { 0% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.08); opacity: 0.8; } 100% { transform: scale(1); opacity: 1; } }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { font-size: clamp(10.5px, 1.125vw, 12px); }
    body { font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; background-color: #1E1B4B; color: white; min-height: 100vh; position: relative; overflow-x: hidden; transition: color 0.5s ease; }
    .page-background-container { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; z-index: 0; pointer-events: none; overflow: hidden; }
    .background-gradient { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, #8B5CF6 0%, #3B0764 25%, #1E1B4B 50%, #312E81 75%, #6366F1 100%); background-size: 400% 400%; animation: gradientShift 20s ease infinite; z-index: 1; }
    @keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
    .background-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: radial-gradient(ellipse at center, rgba(139, 92, 246, 0.25) 0%, transparent 70%); transition: background 0.5s ease; z-index: 2; }
    .floating-shapes { position: absolute; top: 0; left: 0; width: 100%; height: 100%; overflow: hidden; z-index: 3; }
    .shape { position: absolute; background: rgba(139, 92, 246, 0.1); border-radius: 50%; animation: float 25s linear infinite; backdrop-filter: blur(1px); }
    .page-content { display: flex; flex-direction: column; min-height: 100vh; opacity: 0; transition: opacity 0.6s ease 0.2s; position: relative; z-index: 1; }
    .page-content.loaded { opacity: 1; }
    header, nav { background: rgba(30, 30, 47, 0.85); backdrop-filter: blur(15px); position: fixed; left: 0; right: 0; border-bottom: 2px solid rgba(139, 92, 246, 0.2); z-index: 101; }
    header { padding: 12px 5%; display: flex; align-items: center; justify-content: space-between; top: 0; height: 70px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); }
    nav { display: flex; align-items: center; justify-content: center; gap: 35px; padding: 12px 5%; top: 70px; height: 50px; z-index: 100; }
    .header-left { display: flex; align-items: center; gap: 20px; }
    .logo img { height: 38px; }
    nav a { text-decoration: none; color: #E5E7EB; font-weight: 600; font-size: 0.95rem; padding: 8px 5px; position: relative; }
    nav a::after { content: ''; position: absolute; width: 0%; height: 3px; border-radius: 2px; background: linear-gradient(90deg, #8B5CF6, #6366F1); bottom: -5px; left: 50%; transform: translateX(-50%); transition: width 0.4s cubic-bezier(0.25, 1, 0.5, 1); }
    nav a:hover::after, nav a.active::after { width: 100%; }
    main { padding-top: 140px; position: relative; z-index: 2; flex-grow: 1; }
    .content-wrapper { max-width: 1400px; margin-left: auto; margin-right: auto; padding: 0 5%; }
    .foro-header { text-align: center; margin-bottom: 3rem; }
    .foro-header h1 { font-size: clamp(2rem, 6vw, 3.5rem); font-weight: 700; margin-bottom: 0.5rem; background: linear-gradient(90deg, #c4b5fd, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: 0 2px 15px rgba(167, 139, 250, 0.3); }
    .foro-header p { font-size: clamp(0.9rem, 2vw, 1.1rem); color: #d1d5db; max-width: 600px; margin: 0 auto; }
    .foro-main-content { max-width: 950px; margin-left: auto; margin-right: auto; }
    .create-post-container { background: rgba(30, 27, 75, 0.7); backdrop-filter: blur(10px); padding: 2rem; border-radius: 15px; border: 1px solid rgba(139, 92, 246, 0.2); margin-bottom: 3rem; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
    .create-post-container h2 { font-size: 1.5rem; margin-bottom: 1.5rem; text-align: center; }
    
    /* Estilos del Formulario */
    .create-post-form label { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #d1d5db; }
    .create-post-form input[type="text"], .create-post-form textarea, .create-post-form select { width: 100%; padding: 12px; border: 1px solid rgba(139, 92, 246, 0.3); background: rgba(10, 10, 20, 0.5); border-radius: 9px; margin-bottom: 1.2rem; color: white; transition: all 0.3s ease; font-family: inherit; font-size: 1rem; }
    .create-post-form textarea { resize: vertical; }
    .create-post-form input:focus, .create-post-form textarea:focus, .create-post-form select:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
    .form-actions { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; margin-top: 1rem; }
    .btn-upload { background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); color: white; padding: 10px 18px; border-radius: 8px; cursor: pointer; transition: all 0.3s ease; }
    .btn-upload:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
    #file-name { margin-left: 10px; font-style: italic; color: #9ca3af; }
    .btn-submit-post { background: #8B5CF6; color: white; border: none; padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s ease; }
    .btn-submit-post:hover { background: #7c3aed; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4); }
    .error-message { color: #fca5a5; background: rgba(239, 68, 68, 0.2); padding: 10px; border-radius: 8px; margin-top: 1rem; text-align: center; }

    /* Estilos de la Cascada */
    .foro-grid-container { column-count: 3; column-gap: 1.5rem; }
    .foro-post-item { position: relative; display: inline-block; width: 100%; background: rgba(30, 27, 75, 0.6); border-radius: 12px; margin-bottom: 1.5rem; overflow: hidden; border: 1px solid rgba(139, 92, 246, 0.2); box-shadow: 0 5px 20px rgba(0,0,0,0.2); transition: transform 0.3s ease, box-shadow 0.3s ease; -webkit-column-break-inside: avoid; page-break-inside: avoid; break-inside: avoid; }
    .foro-post-item:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3); }
    .stretched-link { position: absolute; top: 0; left: 0; right: 0; bottom: 0; z-index: 1; }
    .post-author a, .post-game-tag a { position: relative; z-index: 2; }
    .post-image-container img { width: 100%; height: auto; display: block; }
    .post-content { padding: 1rem; }
    .post-title { font-size: 1.1rem; font-weight: 600; color: #e5e7eb; margin-bottom: 1rem; line-height: 1.4; }
    .post-meta { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(139, 92, 246, 0.15); padding-top: 0.8rem; }
    .post-author { display: flex; align-items: center; gap: 10px; }
    .post-author img { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }
    .post-author a { color: #c4b5fd; font-weight: 600; text-decoration: none; transition: color 0.3s; }
    .post-author a:hover { color: #fff; }
    .post-game-tag a { background: rgba(139, 92, 246, 0.2); padding: 5px 10px; border-radius: 15px; font-size: 0.8rem; color: #e0d4ff; text-decoration: none; transition: background 0.3s; }
    .post-game-tag a:hover { background: rgba(139, 92, 246, 0.4); }
    footer { background: rgba(30, 30, 47, 0.9); backdrop-filter: blur(20px); padding: 35px 18px; text-align: center; color: #E5E7EB; margin-top: auto; width: 100%; z-index: 2; position: relative; }
    @media (max-width: 768px) { .foro-grid-container { column-count: 2; } nav { justify-content: flex-start; overflow-x: auto; } }
    @media (max-width: 500px) { .foro-grid-container { column-count: 1; } .form-actions { flex-direction: column; align-items: stretch; } .btn-submit-post { width: 100%; text-align: center; } }
    .header-right { display: flex; align-items: center; gap: 15px; justify-content: flex-end; flex-grow: 1; }
    .usuario { cursor: pointer; display: flex; align-items: center; gap: 10px; position: relative; }
    .nombre-usuario { font-weight: 600; font-size: 0.95rem; }
    .usuario img { width: 42px; height: 42px; border-radius: 50%; border: 2.5px solid rgba(139, 92, 246, 0.8); object-fit: cover; }
    .acciones-invitado { display: flex; gap: 15px; }
    .btn-acceso { text-decoration: none; color: white; font-weight: 600; padding: 8px 16px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.5); }
    .btn-acceso:hover { background: rgba(139, 92, 246, 0.2); border-color: #8B5CF6; }
    .btn-acceso.btn-registro { background-color: #8B5CF6; border-color: #8B5CF6; }
    .btn-acceso.btn-registro:hover { background-color: #7c3aed; }
    
    /* Estilos para Menú de Usuario y Modales */
    .usuario-menu { display: none; position: absolute; top: 60px; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; overflow: hidden; min-width: 200px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; animation: menuSlideDown 0.3s ease-out; }
    @keyframes menuSlideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    .usuario-menu a { display: flex; align-items: center; gap: 10px; padding: 13px; text-decoration: none; color: white; font-weight: 500; font-size: 0.9rem; transition: all 0.3s ease; }
    .usuario-menu a:hover { background: rgba(139, 92, 246, 0.2); }
    .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(10px); justify-content: center; align-items: center; z-index: 2000; }
    .modal-content { background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); padding: 28px; border-radius: 18px; max-width: 420px; width: 90%; color: white; text-align: center; position: relative; border: 1px solid rgba(139, 92, 246, 0.3); animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
    @keyframes modalSlideIn { from { transform: translateY(-50px) scale(0.9); opacity: 0; } to { transform: translateY(0) scale(1); opacity: 1; } }
    .modal-content h2 { margin-bottom: 18px; font-size: 1.4rem; }
    .modal-content button { padding: 11px 22px; border: none; border-radius: 8px; cursor: pointer; margin: 9px 4px; font-weight: 600; font-size: 0.9rem; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);}
    .modal-button-secondary { background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); }
    .cerrar { position: absolute; top: 13px; right: 18px; font-size: 22px; cursor: pointer; color: #9CA3AF; transition: all 0.3s ease;}
    .cerrar:hover { color: #fff; }
    .theme-switch-wrapper { display: flex; align-items: center; gap: 13px; margin-top: 13px; margin-bottom: 20px; }
    .theme-switch { position: relative; display: inline-block; width: 55px; height: 30px; }
    .theme-switch input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 30px; }
    .slider:before { position: absolute; content: ""; height: 23px; width: 23px; left: 4px; bottom: 3.5px; background-color: white; transition: .4s; border-radius: 50%; }
    input:checked + .slider { background-color: #8B5CF6; }
    input:checked + .slider:before { transform: translateX(24px); }
  </style>
</head>
<body>
    <?php include 'loader.php'; ?>

    <div class="page-content">
        <div class="page-background-container">
            <div class="background-gradient"></div>
            <div class="background-overlay"></div>
            <div class="floating-shapes">
                <div class="shape"></div><div class="shape"></div><div class="shape"></div><div class="shape"></div>
            </div>
        </div>
        
        <header>
            <div class="header-left">
                <div class="logo"><a href="index.php"><img src="NJOYSINFONDO.jpeg" alt="njoy" id="logoImg" /></a></div>
            </div>
            <div class="header-right">
                <?php if ($usuario_logueado): ?>
                    <div class="usuario" id="usuarioBtn">
                        <img src="" alt="Perfil" id="foto">
                        <span id="nombreUsuario" class="nombre-usuario"></span>
                        <div class="usuario-menu" id="usuarioMenu">
                          <a href="perfil.php">👤 Mi Perfil</a>
                          <a href="#configuracion">⚙️ Configuración</a>
                          <a href="#logout">🚪 Cerrar sesión</a>
                      </div>
                    </div>
                <?php else: ?>
                    <div class="acciones-invitado">
                        <a href="login.html" class="btn-acceso">Iniciar Sesión</a>
                        <a href="registro2.html" class="btn-acceso btn-registro">Registrarse</a>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <nav>
            <a href="index.php">Inicio</a>
            <a href="foro.php" class="active">Comunidad</a>
        </nav>

        <main>
            <div class="content-wrapper">
                <section class="foro-header">
                    <h1>Comunidad NJOY</h1>
                    <p>Comparte tus momentos, capturas y opiniones con otros jugadores. ¡Inspírate y conecta!</p>
                </section>
                
                <div class="foro-main-content">
                    <?php if ($usuario_logueado): ?>
                    <section class="create-post-container">
                        <h2>Crear una nueva publicación</h2>
                        <form action="foro.php" method="POST" enctype="multipart/form-data" class="create-post-form">
                            <label for="post_title">Título (Obligatorio)</label>
                            <input type="text" name="post_title" id="post_title" placeholder="Un título atractivo para tu publicación" required>
                            <label for="post_image">Imagen Principal (Obligatoria)</label>
                            <div>
                               <label for="file_input_trigger" class="btn-upload">📷 Seleccionar Imagen...</label>
                               <input type="file" name="post_image" id="file_input_trigger" accept="image/*" style="display:none;" required>
                               <span id="file-name"></span>
                            </div>
                            <label for="juego_id" style="margin-top: 1.2rem;">Juego relacionado (Opcional)</label>
                            <select name="juego_id" id="juego_id">
                                <option value="">-- General (Sin juego específico) --</option>
                                <?php foreach ($juegos_para_selector as $juego): ?>
                                <option value="<?php echo $juego['id']; ?>"><?php echo htmlspecialchars($juego['titulo']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label for="post_description">Descripción Larga (Opcional)</label>
                            <textarea name="post_description" id="post_description" rows="5" placeholder="Escribe aquí los detalles. Esto no aparecerá en la vista principal, sino al hacer clic en tu publicación."></textarea>
                            <div class="form-actions">
                                <span></span>
                                <button type="submit" name="submit_post" class="btn-submit-post">Publicar</button>
                            </div>
                            <?php if(!empty($error_post)): ?>
                                <p class="error-message"><?php echo $error_post; ?></p>
                            <?php endif; ?>
                        </form>
                    </section>
                    <?php endif; ?>

                    <section class="foro-grid-container">
                        <?php if (empty($posts_del_foro)): ?>
                            <p style="grid-column: 1 / -1; text-align:center;">Aún no hay publicaciones. ¡Sé el primero en compartir algo!</p>
                        <?php else: ?>
                            <?php foreach($posts_del_foro as $post): ?>
                            <div class="foro-post-item">
                                <a href="post.php?id=<?php echo $post['id']; ?>" class="stretched-link"></a>
                                
                                <div class="post-image-container">
                                    <img src="<?php echo htmlspecialchars($post['imagen_url']); ?>" alt="Imagen de la publicación">
                                </div>
                                <div class="post-content">
                                    <h3 class="post-title"><?php echo htmlspecialchars($post['titulo']); ?></h3>
                                    <div class="post-meta">
                                        <div class="post-author">
                                            <a href="perfil.php?id=<?php echo $post['autor_id']; ?>">
                                                <img src="<?php echo htmlspecialchars($post['autor_foto']); ?>" alt="Avatar de <?php echo htmlspecialchars($post['autor_nombre']); ?>">
                                            </a>
                                            <a href="perfil.php?id=<?php echo $post['autor_id']; ?>">
                                                <?php echo htmlspecialchars($post['autor_nombre']); ?>
                                            </a>
                                        </div>
                                        <?php if ($post['juego_titulo']): ?>
                                        <div class="post-game-tag">
                                            <a href="<?php echo htmlspecialchars($post['juego_url'] ?? '#'); ?>"><?php echo htmlspecialchars($post['juego_titulo']); ?></a>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </section>
                </div>
            </div>
        </main>

        <footer>
            <p>© <?php echo date("Y"); ?> NJOY - Tu tienda de videojuegos. Todos los derechos reservados.</p>
        </footer>
    </div>

    <!-- Modales -->
    <div class="modal" id="modalLogout">
      <div class="modal-content">
        <span class="cerrar" data-close="modalLogout">&times;</span>
        <h2>🚪 Cerrar sesión</h2>
        <p>¿Estás seguro de que deseas cerrar sesión?</p>
        <button id="confirmarLogout" style="background: #ef4444;">Sí, cerrar sesión</button>
        <button id="cancelarLogout" class="modal-button-secondary">Cancelar</button>
      </div>
    </div>
    <div class="modal" id="modalConfig">
      <div class="modal-content">
        <span class="cerrar" data-close="modalConfig">&times;</span>
        <h2>⚙️ Configuración</h2>
        <label>Modo de visualización:</label>
        <div class="theme-switch-wrapper">
          <label class="theme-switch" for="theme-toggle"><input type="checkbox" id="theme-toggle" /><span class="slider"></span></label>
          <span id="theme-label-text">Modo Oscuro</span>
        </div>
        <button id="guardarConfig" style="background: #8B5CF6; width: 100%;">Guardar cambios</button>
      </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        window.addEventListener('load', function() {
            document.getElementById('loader')?.classList.add('hidden');
            document.querySelector('.page-content')?.classList.add('loaded');
        });

        const isUserLoggedIn = <?php echo json_encode($usuario_logueado); ?>;
        if (isUserLoggedIn) {
            fetch('obtener_datos_usuario.php?v=' + new Date().getTime())
                .then(response => response.json())
                .then(data => {
                    if (data.status === "ok") {
                        document.querySelector("#usuarioBtn img").src = data.foto + "?t=" + new Date().getTime();
                        document.getElementById("nombreUsuario").textContent = data.nombre;
                    }
                });
            
            const usuarioBtn = document.getElementById("usuarioBtn");
            const usuarioMenu = document.getElementById("usuarioMenu");
        
            usuarioBtn?.addEventListener("click", (e) => {
                e.stopPropagation();
                usuarioMenu.style.display = usuarioMenu.style.display === "block" ? "none" : "block";
            });

            document.addEventListener("click", (e) => {
                if (usuarioMenu?.style.display === "block" && !usuarioMenu.contains(e.target) && !usuarioBtn.contains(e.target)) {
                    usuarioMenu.style.display = "none";
                }
            });

            document.querySelectorAll(".usuario-menu a").forEach(link => {
                link.addEventListener("click", (e) => {
                    e.preventDefault();
                    const href = link.getAttribute("href");
                    if (href === "#configuracion") {
                        document.getElementById('modalConfig').style.display = "flex";
                    } else if (href === "#logout") {
                        document.getElementById('modalLogout').style.display = 'flex';
                    } else {
                        window.location.href = href;
                    }
                    if (usuarioMenu) usuarioMenu.style.display = 'none';
                });
            });
            
            document.getElementById('guardarConfig')?.addEventListener('click', () => {
                document.getElementById('modalConfig').style.display = 'none';
            });
            
            document.getElementById("confirmarLogout")?.addEventListener("click", () => {
                fetch('logout.php', { method: 'POST' }).finally(() => window.location.href = 'index.php');
            });
        }
        
        document.querySelectorAll(".cerrar, [data-close], #cancelarLogout").forEach(el => {
            el.addEventListener("click", () => el.closest('.modal').style.display = "none");
        });
        
        document.querySelectorAll(".modal").forEach(modal => {
            modal.addEventListener("click", e => { if (e.target === modal) modal.style.display = "none"; });
        });

        const themeToggle = document.getElementById('theme-toggle');
        const themeLabel = document.getElementById('theme-label-text');
        const logoImg = document.getElementById('logoImg');
        const setTheme = (theme) => {
            document.body.classList.toggle('light-mode', theme === 'light');
            if (themeToggle) themeToggle.checked = (theme === 'light');
            if (themeLabel) themeLabel.textContent = (theme === 'light') ? 'Modo Claro' : 'Modo Oscuro';
            if(logoImg) logoImg.src = (theme === 'light') ? 'NJOY_LOGO_CLARO.jpeg' : 'NJOYSINFONDO.jpeg';
        }
        themeToggle?.addEventListener('change', () => {
            const newTheme = themeToggle.checked ? 'light' : 'dark';
            localStorage.setItem('theme', newTheme);
            setTheme(newTheme);
        });
        setTheme(localStorage.getItem('theme') || 'dark');
        
        const fileInput = document.getElementById('file_input_trigger');
        const fileNameSpan = document.getElementById('file-name');
        if (fileInput && fileNameSpan) {
            fileInput.addEventListener('change', function() {
                fileNameSpan.textContent = this.files.length > 0 ? this.files[0].name : '';
            });
        }
    });
    </script>
</body>
</html>
<?php
if (isset($conn)) {
    $conn->close();
}
?>