<?php
// guardar_juego.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header('Location: admin.php');
    exit();
}

try {
    // --- 1. RECOGER DATOS DEL FORMULARIO ---
    $titulo = $_POST['titulo'] ?? 'Sin Título';
    $tags = $_POST['tags'] ?? '';
    $secciones_seleccionadas = $_POST['secciones'] ?? [];
    
    // --- LÓGICA DE PRECIO ACTUALIZADA ---
    $es_proximamente = isset($_POST['es_proximamente']) ? 1 : 0;
    $precio_final = 0.00;
    $descuento = 0;

    if ($es_proximamente == 1) {
        // Si es "Próximamente", el precio y descuento son 0.
        $precio_final = 0.00;
        $descuento = 0;
    } else if (!isset($_POST['es_free'])) {
        // Si no es "Próximamente" y no es "Free to play", tomamos el precio del formulario.
        $precio_final = (float)($_POST['precio'] ?? 0.00);
        $descuento = (int)($_POST['descuento'] ?? 0);
    }
    // Si es "Free to play", se queda con los valores por defecto (0).

    $descripcion_larga = $_POST['descripcion_larga'] ?? '';
    $video_youtube_id = $_POST['video_youtube_id'] ?? '';
    $caracteristicas = str_replace(["\r\n", "\r", "\n"], '|', $_POST['caracteristicas'] ?? '');
    $req_minimos = str_replace(["\r\n", "\r", "\n"], '|', $_POST['req_minimos'] ?? '');
    $req_recomendados = str_replace(["\r\n", "\r", "\n"], '|', $_POST['req_recomendados'] ?? '');
    $desarrollador = $_POST['desarrollador'] ?? '';
    $editor = $_POST['editor'] ?? '';
    $fecha_lanzamiento = $_POST['fecha_lanzamiento'] ?? '';

    // --- 2. SUBIR IMAGEN DE PORTADA ---
    $imagen_url = ''; 
    if (isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] == 0) {
        $target_dir_cover = "njoyimages/";
        if (!is_writable($target_dir_cover)) throw new Exception("Error de permisos en la carpeta '{$target_dir_cover}'.");
        $nombre_archivo = time() . '_' . basename($_FILES["imagen"]["name"]);
        $target_file = $target_dir_cover . $nombre_archivo;
        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
            $imagen_url = $target_file; 
        } else { throw new Exception("Error al mover la imagen de portada."); }
    } else {
        throw new Exception("Error: La imagen de portada es obligatoria.");
    }
    
    // --- 3. SUBIR IMÁGENES DE GALERÍA ---
    $rutas_galeria = [];
    if (isset($_FILES['imagenes_galeria']) && !empty($_FILES['imagenes_galeria']['name'][0])) {
        $target_dir_gallery = "njoyimages/gallery/";
        if (!file_exists($target_dir_gallery)) { mkdir($target_dir_gallery, 0775, true); }
        if (!is_writable($target_dir_gallery)) { throw new Exception("Error de permisos en la carpeta '{$target_dir_gallery}'."); }

        $nombres_personalizados = $_POST['gallery_image_names'] ?? [];
        $total_files = count($_FILES['imagenes_galeria']['name']);

        for ($i = 0; $i < $total_files; $i++) {
            if ($_FILES['imagenes_galeria']['error'][$i] === 0) {
                $custom_name = $nombres_personalizados[$i] ?? pathinfo($_FILES['imagenes_galeria']['name'][$i], PATHINFO_FILENAME);
                $original_extension = pathinfo($_FILES['imagenes_galeria']['name'][$i], PATHINFO_EXTENSION);
                $sanitized_name = preg_replace('/[^A-Za-z0-9_\-]/', '_', $custom_name);
                $final_filename = time() . '_' . $i . '_' . $sanitized_name . '.' . $original_extension;
                $target_file_galeria = $target_dir_gallery . $final_filename;

                if (move_uploaded_file($_FILES['imagenes_galeria']['tmp_name'][$i], $target_file_galeria)) {
                    $rutas_galeria[] = $target_file_galeria;
                }
            }
        }
    }
    $imagenes_galeria_string = implode('|', $rutas_galeria);

    // --- 4. INSERTAR EN LA BASE DE DATOS (CON TRANSACCIÓN) ---
    $conn->begin_transaction();

    // PASO 4.1: Insertar el juego en la tabla `juegos`
    $stmt_juego = $conn->prepare(
        "INSERT INTO juegos (titulo, pagina_url, imagen_url, precio_final, descuento_porcentaje, es_proximamente, tags, descripcion_larga, caracteristicas, video_youtube_id, imagenes_galeria, req_minimos, req_recomendados, desarrollador, editor, fecha_lanzamiento) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $pagina_url_placeholder = 'temp'; 
    $stmt_juego->bind_param("sssdisssssssssss", 
        $titulo, $pagina_url_placeholder, $imagen_url, $precio_final, $descuento, $es_proximamente, $tags,
        $descripcion_larga, $caracteristicas, $video_youtube_id, $imagenes_galeria_string,
        $req_minimos, $req_recomendados, $desarrollador, $editor, $fecha_lanzamiento
    );
    if (!$stmt_juego->execute()) {
        throw new Exception("Error al guardar el juego: " . $stmt_juego->error);
    }
    
    $juego_id = $conn->insert_id;
    $stmt_juego->close();

    // PASO 4.2: Actualizar la `pagina_url`
    $pagina_url_final = "game.php?id=" . $juego_id;
    $stmt_url = $conn->prepare("UPDATE juegos SET pagina_url = ? WHERE id = ?");
    $stmt_url->bind_param("si", $pagina_url_final, $juego_id);
    $stmt_url->execute();
    $stmt_url->close();

    // PASO 4.3: Insertar las relaciones en `juego_secciones`
    if (!empty($secciones_seleccionadas)) {
        $stmt_secciones = $conn->prepare("INSERT INTO juego_secciones (juego_id, seccion_id) VALUES (?, ?)");
        foreach ($secciones_seleccionadas as $seccion_id) {
            $seccion_id_int = (int)$seccion_id;
            $stmt_secciones->bind_param("ii", $juego_id, $seccion_id_int);
            $stmt_secciones->execute();
        }
        $stmt_secciones->close();
    }
    
    $conn->commit();
    header("Location: admin.php?status=success&message=" . urlencode("Juego '{$titulo}' guardado con éxito."));
    exit;

} catch (Exception $e) {
    if (isset($conn) && $conn->ping()) {
        $conn->rollback();
    }
    header("Location: admin.php?status=error&message=" . urlencode($e->getMessage()));
    exit;
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>