<!-- loader.php -->
<div id="loader">
    <img src="/NJOYSINFONDO.jpeg" alt="Cargando NJOY...">
</div>