<?php
// gestionar_amigos.php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión.']);
    exit();
}

require_once 'db.php';
require_once 'social_system.php';

$usuario_actual_id = (int)$_SESSION['usuario_id'];
$amigo_id = isset($_POST['amigo_id']) ? (int)$_POST['amigo_id'] : 0;
$accion = isset($_POST['accion']) ? $_POST['accion'] : '';

if ($amigo_id === 0 || $usuario_actual_id === $amigo_id) {
    echo json_encode(['status' => 'error', 'msg' => 'ID de usuario no válido.']);
    exit();
}

$u1 = min($usuario_actual_id, $amigo_id);
$u2 = max($usuario_actual_id, $amigo_id);

if ($accion === 'agregar') {
    $stmt_insert = $conn->prepare("INSERT INTO amigos (usuario1_id, usuario2_id, solicitado_por, estado) VALUES (?, ?, ?, 'pendiente') ON DUPLICATE KEY UPDATE estado=estado");
    $stmt_insert->bind_param("iii", $u1, $u2, $usuario_actual_id);
    if ($stmt_insert->execute()) {
        // --- INTEGRACIÓN SOCIAL ---
        // Genera la notificación permanente para el usuario que recibe la solicitud.
        generarNotificacion($conn, $amigo_id, $usuario_actual_id, 'SOLICITUD_AMISTAD');
        
        echo json_encode(['status' => 'ok', 'nuevo_estado' => 'pendiente']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'No se pudo enviar la solicitud.']);
    }
    $stmt_insert->close();
} elseif ($accion === 'eliminar') {
    $stmt_delete = $conn->prepare("DELETE FROM amigos WHERE usuario1_id = ? AND usuario2_id = ?");
    $stmt_delete->bind_param("ii", $u1, $u2);
    if ($stmt_delete->execute()) {
        echo json_encode(['status' => 'ok', 'nuevo_estado' => 'eliminado']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'No se pudo eliminar al amigo.']);
    }
    $stmt_delete->close();
}

$conn->close();
?>