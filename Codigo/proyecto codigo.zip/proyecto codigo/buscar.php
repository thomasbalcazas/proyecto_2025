<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php';

$resultados = ['juegos' => [], 'usuarios' => []];
$termino_busqueda = isset($_GET['termino']) ? trim($_GET['termino']) : '';

if (strlen($termino_busqueda) < 2) {
    echo json_encode($resultados);
    exit();
}

$termino_like = '%' . $termino_busqueda . '%';

// --- Buscar Juegos ---
$sql_juegos = "SELECT id, titulo, imagen_url, pagina_url FROM juegos WHERE titulo LIKE ? LIMIT 5";
$stmt_juegos = $conn->prepare($sql_juegos);
$stmt_juegos->bind_param("s", $termino_like);
$stmt_juegos->execute();
$result_juegos = $stmt_juegos->get_result();

while ($row = $result_juegos->fetch_assoc()) {
    $resultados['juegos'][] = $row;
}
$stmt_juegos->close();


// --- Buscar Usuarios ---
$sql_usuarios = "SELECT id, nombre, foto FROM usuarios WHERE nombre LIKE ? LIMIT 5";
$stmt_usuarios = $conn->prepare($sql_usuarios);
$stmt_usuarios->bind_param("s", $termino_like);
$stmt_usuarios->execute();
$result_usuarios = $stmt_usuarios->get_result();

while ($row = $result_usuarios->fetch_assoc()) {
    $resultados['usuarios'][] = $row;
}
$stmt_usuarios->close();

$conn->close();

echo json_encode($resultados);
?>