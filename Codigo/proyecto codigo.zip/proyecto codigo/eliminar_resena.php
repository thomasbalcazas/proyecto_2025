<?php
// eliminar_resena.php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión para realizar esta acción.']);
    exit();
}

require_once 'db.php';
require_once 'social_system.php'; // Incluimos el sistema social

$usuario_id = (int)$_SESSION['usuario_id'];
$resena_id = isset($_POST['resena_id']) ? (int)$_POST['resena_id'] : 0;

if ($resena_id === 0) {
    echo json_encode(['status' => 'error', 'msg' => 'ID de reseña no válido.']);
    exit();
}

$conn->begin_transaction();

try {
    // PASO 1: Obtener la información de la reseña ANTES de borrarla
    $stmt_info = $conn->prepare("SELECT usuario_id, juego_id FROM resenas WHERE id = ?");
    $stmt_info->bind_param("i", $resena_id);
    $stmt_info->execute();
    $result_info = $stmt_info->get_result();
    
    if ($result_info->num_rows === 0) {
        throw new Exception('La reseña no existe.');
    }
    
    $resena_data = $result_info->fetch_assoc();
    $juego_id_afectado = (int)$resena_data['juego_id'];
    $autor_resena_id = (int)$resena_data['usuario_id'];
    $stmt_info->close();

    // PASO 2: Verificar que el usuario que intenta borrar es el dueño de la reseña
    if ($autor_resena_id !== $usuario_id) {
        throw new Exception('No tienes permiso para eliminar esta reseña.');
    }

    // PASO 3: Proceder con la eliminación
    $stmt_delete = $conn->prepare("DELETE FROM resenas WHERE id = ?");
    $stmt_delete->bind_param("i", $resena_id);
    $delete_success = $stmt_delete->execute();
    $stmt_delete->close();
    
    if (!$delete_success) {
        throw new Exception('No se pudo eliminar la reseña de la base de datos.');
    }

    // --- INTEGRACIÓN SOCIAL ---
    // PASO 4: Si la eliminación fue exitosa, generar la actividad en el feed.
    generarActividad($conn, $usuario_id, 'ELIMINO_RESENA', $juego_id_afectado);
    
    $conn->commit();
    echo json_encode(['status' => 'ok', 'msg' => 'Reseña eliminada con éxito.']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}

$conn->close();
?>