<?php
// eliminar_comentario.php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'db.php';

// 1. Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id']) || empty($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión para realizar esta acción.']);
    exit();
}
$usuario_id = (int)$_SESSION['usuario_id'];

// 2. Verificar si se recibió el ID del comentario
if (!isset($_POST['comentario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'No se especificó el comentario a eliminar.']);
    exit();
}
$comentario_id = (int)$_POST['comentario_id'];

// 3. Verificar que el comentario existe y que el usuario es el autor (Seguridad)
$stmt_check = $conn->prepare("SELECT autor_id FROM comentarios_perfil WHERE id = ?");
$stmt_check->bind_param("i", $comentario_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows === 0) {
    echo json_encode(['status' => 'error', 'msg' => 'El comentario no existe.']);
    $stmt_check->close();
    $conn->close();
    exit();
}

$comentario = $result_check->fetch_assoc();
if ($comentario['autor_id'] !== $usuario_id) {
    echo json_encode(['status' => 'error', 'msg' => 'No tienes permiso para eliminar este comentario.']);
    $stmt_check->close();
    $conn->close();
    exit();
}
$stmt_check->close();

// 4. Proceder con la eliminación
// Opcional: Primero eliminar los likes asociados para mantener la integridad de la base de datos
$stmt_likes = $conn->prepare("DELETE FROM likes_comentarios WHERE comentario_id = ?");
$stmt_likes->bind_param("i", $comentario_id);
$stmt_likes->execute();
$stmt_likes->close();

// Ahora eliminar el comentario
$stmt_delete = $conn->prepare("DELETE FROM comentarios_perfil WHERE id = ?");
$stmt_delete->bind_param("i", $comentario_id);

if ($stmt_delete->execute()) {
    if ($stmt_delete->affected_rows > 0) {
        echo json_encode(['status' => 'ok', 'msg' => 'Comentario eliminado correctamente.']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'No se encontró el comentario para eliminar.']);
    }
} else {
    echo json_encode(['status' => 'error', 'msg' => 'Ocurrió un error al eliminar el comentario.']);
}

$stmt_delete->close();
$conn->close();
?>