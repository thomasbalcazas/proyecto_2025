<?php
// gestionar_solicitud.php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión.']);
    exit();
}

require_once 'db.php';
require_once 'social_system.php';

$usuario_actual_id = (int)$_SESSION['usuario_id'];
$solicitante_id = isset($_POST['solicitante_id']) ? (int)$_POST['solicitante_id'] : 0;
$accion = isset($_POST['accion']) ? $_POST['accion'] : '';

if ($solicitante_id === 0) {
    echo json_encode(['status' => 'error', 'msg' => 'Solicitante no válido.']);
    exit();
}

$u1 = min($usuario_actual_id, $solicitante_id);
$u2 = max($usuario_actual_id, $solicitante_id);

$conn->begin_transaction();
try {
    if ($accion === 'aceptar') {
        $stmt_update = $conn->prepare("UPDATE amigos SET estado = 'aceptada' WHERE usuario1_id = ? AND usuario2_id = ? AND estado = 'pendiente'");
        $stmt_update->bind_param("ii", $u1, $u2);
        $stmt_update->execute();

        if ($stmt_update->affected_rows > 0) {
            // Eliminar la notificación de solicitud original
            $stmt_delete_notif = $conn->prepare("DELETE FROM notificaciones WHERE usuario_destino_id = ? AND usuario_origen_id = ? AND tipo_notificacion = 'SOLICITUD_AMISTAD'");
            $stmt_delete_notif->bind_param("ii", $usuario_actual_id, $solicitante_id);
            $stmt_delete_notif->execute();
            $stmt_delete_notif->close();

            // Lógica de XP por nuevo amigo
            $xp_ganado = 10;
            $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = xp + ? WHERE id = ? OR id = ?");
            $stmt_xp->bind_param("iii", $xp_ganado, $usuario_actual_id, $solicitante_id);
            $stmt_xp->execute();
            $stmt_xp->close();

            // Generar actividad y notificaciones informativas permanentes
            generarActividad($conn, $usuario_actual_id, 'NUEVO_AMIGO', $solicitante_id);
            generarActividad($conn, $solicitante_id, 'NUEVO_AMIGO', $usuario_actual_id);
            
            // Notificación para el que envió la solicitud
            generarNotificacion($conn, $solicitante_id, $usuario_actual_id, 'SOLICITUD_ACEPTADA');
            
            // Notificación de confirmación para el que aceptó (para su propio historial)
            generarNotificacion($conn, $usuario_actual_id, $solicitante_id, 'AMISTAD_CONFIRMADA');

        } else {
             throw new Exception('La solicitud ya fue procesada o no existe.');
        }
        $stmt_update->close();

    } elseif ($accion === 'rechazar') {
        $stmt_delete_friend = $conn->prepare("DELETE FROM amigos WHERE usuario1_id = ? AND usuario2_id = ? AND estado = 'pendiente'");
        $stmt_delete_friend->bind_param("ii", $u1, $u2);
        $stmt_delete_friend->execute();
        
        if($stmt_delete_friend->affected_rows > 0) {
            // Eliminar la notificación de solicitud original
            $stmt_delete_notif = $conn->prepare("DELETE FROM notificaciones WHERE usuario_destino_id = ? AND usuario_origen_id = ? AND tipo_notificacion = 'SOLICITUD_AMISTAD'");
            $stmt_delete_notif->bind_param("ii", $usuario_actual_id, $solicitante_id);
            $stmt_delete_notif->execute();
            $stmt_delete_notif->close();

            // Crear notificación de confirmación de rechazo (para el historial del usuario actual)
            generarNotificacion($conn, $usuario_actual_id, $solicitante_id, 'AMISTAD_RECHAZADA');
        } else {
            throw new Exception('La solicitud ya fue procesada o no existe.');
        }
        $stmt_delete_friend->close();
    }
    
    $conn->commit();
    echo json_encode(['status' => 'ok']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}

$conn->close();
?>