<?php
$host = "127.0.0.1:3306";
$user = "u651705570_njoy";
$pass = "Njoy2025";
$db   = "u651705570_njoy";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");