<?php
// guardar_resena.php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Debes iniciar sesión para dejar una reseña.']);
    exit();
}

require_once 'db.php';
require_once 'social_system.php';

$usuario_id = (int)$_SESSION['usuario_id'];
$juego_id = isset($_POST['juego_id']) ? (int)$_POST['juego_id'] : 0;
$calificacion = isset($_POST['calificacion']) ? (float)$_POST['calificacion'] : 0;
$comentario = isset($_POST['comentario']) ? trim($_POST['comentario']) : '';
$recomendacion = isset($_POST['recomendacion']) ? trim($_POST['recomendacion']) : '';

if ($juego_id === 0 || $calificacion === 0 || !in_array($recomendacion, ['recomienda', 'no_recomienda'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Faltan datos requeridos.']);
    exit();
}

// Verificar si ya existe una reseña para actualizarla o crear una nueva
$stmt_check = $conn->prepare("SELECT id FROM resenas WHERE usuario_id = ? AND juego_id = ?");
$stmt_check->bind_param("ii", $usuario_id, $juego_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();
$existing_review = $result_check->fetch_assoc();
$stmt_check->close();

$response = ['status' => 'error', 'msg' => 'Ocurrió un error inesperado.'];

if ($existing_review) {
    // Si la reseña ya existe, solo la actualizamos (sin dar XP)
    $stmt_update = $conn->prepare("UPDATE resenas SET calificacion = ?, comentario = ?, recomendacion = ?, fecha = NOW() WHERE id = ?");
    $stmt_update->bind_param("dssi", $calificacion, $comentario, $recomendacion, $existing_review['id']);
    if ($stmt_update->execute()) {
        $response = ['status' => 'ok', 'msg' => 'Reseña actualizada con éxito.'];
    }
    $stmt_update->close();
} else {
    // Si es una reseña nueva, la insertamos y damos XP
    $conn->begin_transaction();
    try {
        // Insertar nueva reseña
        $stmt_insert = $conn->prepare("INSERT INTO resenas (juego_id, usuario_id, calificacion, comentario, recomendacion) VALUES (?, ?, ?, ?, ?)");
        $stmt_insert->bind_param("iidss", $juego_id, $usuario_id, $calificacion, $comentario, $recomendacion);
        $stmt_insert->execute();
        $stmt_insert->close();

        // --- LÓGICA DE XP (INICIO) ---
        // Otorgar 15 XP por la nueva reseña
        $xp_ganado = 15;
        $stmt_xp = $conn->prepare("UPDATE usuarios SET xp = xp + ? WHERE id = ?");
        $stmt_xp->bind_param("ii", $xp_ganado, $usuario_id);
        $stmt_xp->execute();
        $stmt_xp->close();
        // --- LÓGICA DE XP (FIN) ---

        // --- INTEGRACIÓN SOCIAL ---
        generarActividad($conn, $usuario_id, 'NUEVA_RESENA', $juego_id);
        
        $conn->commit();
        $response = ['status' => 'ok', 'msg' => 'Reseña publicada con éxito.'];

    } catch (mysqli_sql_exception $exception) {
        $conn->rollback();
        $response = ['status' => 'error', 'msg' => 'Error en la base de datos: ' . $exception->getMessage()];
    }
}

echo json_encode($response);
$conn->close();
?>