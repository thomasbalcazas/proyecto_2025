<?php
header('Content-Type: application/json');
require_once 'db.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'No autenticado.']);
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$updates = [];
$params = [];
$types = '';

// 1. Manejar la subida de la foto de perfil
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $file = $_FILES['foto'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5 MB

    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['status' => 'error', 'msg' => 'Formato de imagen no válido. Solo se permiten JPG, PNG o GIF.']);
        exit();
    }
    if ($file['size'] > $maxSize) {
        echo json_encode(['status' => 'error', 'msg' => 'La imagen es demasiado grande. El máximo es 5 MB.']);
        exit();
    }

    $fileName = uniqid() . '-' . basename($file['name']);
    $filePath = $uploadDir . $fileName;

    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        $updates[] = "foto = ?";
        $params[] = $filePath;
        $types .= 's';
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'Error al mover el archivo subido.']);
        exit();
    }
}

// 2. Manejar el cambio de nombre
if (isset($_POST['nombre']) && !empty(trim($_POST['nombre']))) {
    $nombre = trim($_POST['nombre']);
    if (strlen($nombre) > 50) {
        echo json_encode(['status' => 'error', 'msg' => 'El nombre es demasiado largo.']);
        exit();
    }
    $updates[] = "nombre = ?";
    $params[] = $nombre;
    $types .= 's';
}

// 3. Manejar el cambio de descripción
if (isset($_POST['descripcion'])) { // Permitir descripción vacía
    $descripcion = trim($_POST['descripcion']);
     if (strlen($descripcion) > 500) {
        echo json_encode(['status' => 'error', 'msg' => 'La descripción es demasiado larga.']);
        exit();
    }
    $updates[] = "descripcion = ?";
    $params[] = $descripcion;
    $types .= 's';
}

// Si no hay nada que actualizar, terminar.
if (empty($updates)) {
    echo json_encode(['status' => 'ok', 'msg' => 'No se realizaron cambios.']);
    exit();
}

// 4. Construir y ejecutar la consulta SQL
$sql = "UPDATE usuarios SET " . implode(', ', $updates) . " WHERE id = ?";
$params[] = $usuario_id;
$types .= 'i';

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(['status' => 'ok', 'msg' => 'Perfil actualizado con éxito.']);
} else {
    echo json_encode(['status' => 'error', 'msg' => 'Error al actualizar la base de datos.']);
}

$stmt->close();
$conn->close();
?>