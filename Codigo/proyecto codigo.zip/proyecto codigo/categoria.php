<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

// 1. Comprobar si hay una sesión activa
$usuario_logueado = isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);

require_once 'db.php';

// 2. Prevenir caché del navegador
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// 3. Obtener y validar el nombre de la categoría desde la URL
if (!isset($_GET['nombre']) || empty(trim($_GET['nombre']))) {
    header('Location: index.php');
    exit();
}
$categoria_nombre = trim($_GET['nombre']);

// 4. Consultar los juegos que coincidan con la categoría
$sql_juegos_categoria = "SELECT * FROM juegos WHERE tags LIKE ? ORDER BY id DESC";
$stmt = $conn->prepare($sql_juegos_categoria);
$searchTerm = "%" . $categoria_nombre . "%";
$stmt->bind_param("s", $searchTerm);
$stmt->execute();
$result_juegos_categoria = $stmt->get_result();

/**
 * Función que genera el bloque HTML para una fila de juego en la lista.
 * Reutilizada de index.php para la vista de lista.
 */
function generarJuegoFilaHTML($juego) {
    $id = htmlspecialchars($juego['id']);
    $titulo = htmlspecialchars($juego['titulo']);
    $imagen_url = htmlspecialchars($juego['imagen_url']);
    $pagina_url = !empty($juego['pagina_url']) ? htmlspecialchars($juego['pagina_url']) : '#';
    $precio_final = (float)$juego['precio_final'];
    $descuento = (int)$juego['descuento_porcentaje'];
    $es_proximamente = (bool)($juego['es_proximamente'] ?? false);

    $html_precio_fila = '';
    if ($es_proximamente) {
        $html_precio_fila = '<div class="precio-fila proximamente-label">Próximamente</div>';
    } else if ($precio_final == 0 && $descuento == 0) {
        $html_precio_fila = '<div class="precio-fila free">Gratis</div>';
    } else if ($descuento > 0) {
        $precio_original = $precio_final / (1 - ($descuento / 100));
        $html_precio_fila =
            '<div class="precio-fila con-descuento">' .
                '<span class="descuento-fila">-' . $descuento . '%</span>' .
                '<div class="precio-bloque-fila">' .
                    '<span class="precio-original-fila">$' . number_format($precio_original, 2) . '</span>' .
                    '<span class="precio-final-fila">$' . number_format($precio_final, 2) . '</span>' .
                '</div>' .
            '</div>';
    } else {
        $html_precio_fila = '<div class="precio-fila">$' . number_format($precio_final, 2) . '</div>';
    }

    echo '
    <a href="' . $pagina_url . '" class="juego-fila" data-juego-id="' . $id . '">
        <img src="' . $imagen_url . '" alt="' . $titulo . '" class="juego-fila-img">
        <div class="juego-fila-info">
            <h3 class="juego-fila-titulo">' . $titulo . '</h3>
        </div>
        ' . $html_precio_fila . '
    </a>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Allerta+Stencil&display=swap" rel="stylesheet">
  <title>Categoría: <?php echo htmlspecialchars($categoria_nombre); ?> - NJOY</title>
  <link rel="icon" type="image/x-icon" href="/NJOYSINFONDO.ico">

  <style>
    /* === PANTALLA DE CARGA (LOADER) === */
    #loader { position: fixed; inset: 0; z-index: 99999; background-color: #1E1B4B; display: flex; align-items: center; justify-content: center; transition: opacity 0.5s ease-out, visibility 0s linear 0.5s; opacity: 1; visibility: visible; }
    #loader.hidden { opacity: 0; visibility: hidden; pointer-events: none; }
    #loader img { width: 120px; height: auto; animation: pulse 1.5s ease-in-out infinite; filter: drop-shadow(0 0 15px rgba(139, 92, 246, 0.7)); }
    @keyframes pulse { 0% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.08); opacity: 0.8; } 100% { transform: scale(1); opacity: 1; } }

    /* === BASE Y FONDO === */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { font-size: clamp(10.5px, 1.125vw, 12px); }
    body { font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; background-color: #1E1B4B; color: white; min-height: 100vh; position: relative; overflow-x: hidden; transition: color 0.5s ease; }
    @keyframes gradientShift { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
    .page-background-container { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; z-index: 0; pointer-events: none; overflow: hidden; }
    .background-gradient { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, #8B5CF6 0%, #3B0764 25%, #1E1B4B 50%, #312E81 75%, #6366F1 100%); background-size: 400% 400%; animation: gradientShift 20s ease infinite; z-index: 1; }
    .page-content { display: flex; flex-direction: column; min-height: 100vh; opacity: 0; transition: opacity 0.6s ease 0.2s; position: relative; z-index: 1; }
    .page-content.loaded { opacity: 1; }

    /* === HEADER Y NAV === */
    header, nav { background: rgba(30, 30, 47, 0.85); backdrop-filter: blur(15px); position: fixed; left: 0; right: 0; border-bottom: 2px solid rgba(139, 92, 246, 0.2); z-index: 101; transition: all 0.3s ease; }
    header { padding: 12px 5%; display: flex; align-items: center; justify-content: space-between; top: 0; height: 70px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); }
    nav { display: flex; align-items: center; justify-content: center; gap: 35px; padding: 12px 5%; top: 70px; height: 50px; z-index: 100; }
    .header-left { display: flex; align-items: center; gap: 20px; }
    .logo img { height: 38px; transition: transform 0.3s ease; }
    .logo:hover img { transform: scale(1.05); }
    nav a { text-decoration: none; color: #E5E7EB; font-weight: 600; font-size: 0.95rem; padding: 8px 5px; position: relative; transition: color 0.3s ease; }
    nav a:hover { color: #FFFFFF; }
    nav a::after { content: ''; position: absolute; width: 0%; height: 3px; border-radius: 2px; background: linear-gradient(90deg, #8B5CF6, #6366F1); bottom: -5px; left: 50%; transform: translateX(-50%); transition: width 0.4s cubic-bezier(0.25, 1, 0.5, 1); }
    nav a:hover::after { width: 100%; }

    /* --- BARRA DE BÚSQUEDA --- */
    .header-right { display: flex; align-items: center; gap: 15px; justify-content: flex-end; flex-grow: 1; }
    .search-container { position: relative; max-width: 500px; width: 100%; }
    #searchInput { width: 100%; padding: 10px 15px 10px 40px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.3); background-color: rgba(0, 0, 0, 0.3); color: white; font-size: 0.9rem; transition: all 0.3s ease; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='rgba(255,255,255,0.5)' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: 15px center; }
    #searchInput:focus { outline: none; border-color: #8B5CF6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2); }
    .search-results { display: none; position: absolute; top: 110%; left: 0; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(10px); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 10px; max-height: 400px; overflow-y: auto; z-index: 1000; }
    .search-item { display: flex; align-items: center; gap: 12px; padding: 10px 15px; text-decoration: none; color: #E5E7EB; }
    .search-item:hover { background-color: rgba(139, 92, 246, 0.15); }
    .search-item img { width: 64px; height: 36px; object-fit: cover; border-radius: 4px; }

    /* === ESTRUCTURA PRINCIPAL Y CONTENEDORES === */
    main { padding-top: 120px; position: relative; z-index: 2; flex-grow: 1; }
    .content-wrapper { max-width: 1400px; margin: 0 auto; padding: 0 5%; }
    .section { padding: 40px 0; opacity: 0; transform: translateY(40px); animation: fadeInUP 0.8s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
    @keyframes fadeInUP { to { opacity: 1; transform: translateY(0); } }
    .section-title { font-size: clamp(1.8rem, 4vw, 2.5rem); font-weight: 700; margin-bottom: 2.5rem; position: relative; padding-bottom: 10px; border-bottom: 3px solid #8B5CF6; }
    
    /* === ESTILOS PARA LA VISTA DE LISTA (copiados de index.php) === */
    .juegos-lista { display: flex; flex-direction: column; gap: 8px; }
    .juego-fila { display: flex; align-items: center; background: rgba(30, 30, 47, 0.7); border-radius: 8px; text-decoration: none; color: white; transition: all 0.3s ease; overflow: hidden; border: 1px solid transparent; }
    .juego-fila:hover { background: rgba(139, 92, 246, 0.2); transform: translateX(5px); border-color: rgba(139, 92, 246, 0.5); }
    .juego-fila-img { width: 150px; height: 70px; object-fit: cover; flex-shrink: 0; }
    .juego-fila-info { flex-grow: 1; padding: 0 20px; }
    .juego-fila-titulo { font-size: 1rem; font-weight: 600; }
    .precio-fila { padding: 0 20px; font-weight: 700; font-size: 0.95rem; min-width: 120px; text-align: right; }
    .precio-fila.free { color: #4ade80; }
    .precio-fila.con-descuento { display: flex; align-items: center; gap: 10px; justify-content: flex-end; }
    .descuento-fila { background: rgba(239, 68, 68, 0.8); padding: 4px 8px; border-radius: 5px; font-size: 0.8rem; font-weight: 700; }
    .precio-bloque-fila { display: flex; flex-direction: column; align-items: flex-end; }
    .precio-original-fila { font-size: 0.8rem; color: #9CA3AF; text-decoration: line-through; }
    .precio-final-fila { font-size: 1rem; font-weight: 700; }
    .precio-fila.proximamente-label { color: #f59e0b; }
    .no-juegos-mensaje { font-size: 1.2rem; color: #9ca3af; text-align: center; padding: 4rem 0; width: 100%; }
    
    /* === USUARIO, MODALES, FOOTER, ETC (reutilizado) === */
    .usuario { cursor: pointer; display: flex; align-items: center; gap: 10px; position: relative; }
    .usuario img { width: 42px; height: 42px; border-radius: 50%; border: 2.5px solid rgba(139, 92, 246, 0.8); object-fit: cover; transition: all 0.3s ease; }
    .usuario:hover img { transform: scale(1.1); border-color: #8B5CF6; }
    .usuario-menu { display: none; position: absolute; top: 60px; right: 0; background: rgba(30, 30, 47, 0.95); backdrop-filter: blur(20px); border-radius: 15px; overflow: hidden; min-width: 200px; box-shadow: 0 10px 20px rgba(0,0,0,0.25); border: 1px solid rgba(139, 92, 246, 0.3); z-index: 1000; animation: menuSlideDown 0.3s ease-out; }
    @keyframes menuSlideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    .usuario-menu a { display: flex; align-items: center; gap: 10px; padding: 13px; text-decoration: none; color: white; font-size: 0.9rem; transition: background 0.2s ease; }
    .usuario-menu a:hover { background: rgba(139, 92, 246, 0.2); }
    .acciones-invitado { display: flex; gap: 15px; }
    .btn-acceso { text-decoration: none; color: white; font-weight: 600; padding: 8px 16px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.5); transition: all 0.3s ease; }
    .btn-acceso:hover { background: rgba(139, 92, 246, 0.2); }
    .btn-acceso.btn-registro { background-color: #8B5CF6; border-color: #8B5CF6; }
    .btn-acceso.btn-registro:hover { background-color: #7c3aed; }
    .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(10px); justify-content: center; align-items: center; z-index: 2000; }
    .modal-content { background: rgba(30, 30, 47, 0.95); padding: 28px; border-radius: 18px; max-width: 420px; width: 90%; text-align: center; position: relative; border: 1px solid rgba(139, 92, 246, 0.3); animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
    @keyframes modalSlideIn { from { transform: translateY(-50px) scale(0.9); opacity: 0; } to { transform: translateY(0) scale(1); opacity: 1; } }
    .modal-content h2 { margin-bottom: 18px; }
    .modal-content button { padding: 11px 22px; border: none; border-radius: 8px; cursor: pointer; margin: 9px 4px; font-weight: 600; }
    .cerrar { position: absolute; top: 13px; right: 18px; font-size: 22px; cursor: pointer; color: #9CA3AF; }
    footer { background: rgba(30, 30, 47, 0.9); padding: 35px 18px; text-align: center; color: #E5E7EB; margin-top: auto; width: 100%; z-index: 2; }
    
    /* === RESPONSIVE === */
    @media (max-width: 768px) {
        nav { justify-content: flex-start; overflow-x: auto; scrollbar-width: none; }
        nav::-webkit-scrollbar { display: none; }
        .search-container { display: none; }
        .juego-fila-img { width: 120px; height: 56px; }
        .juego-fila-info { padding: 0 15px; }
        .juego-fila-titulo { font-size: 0.9rem; }
        .precio-fila { min-width: 100px; padding: 0 15px; }
        .section-title { font-size: 1.6rem; }
    }
  </style>
</head>
<body>
    <div id="loader"><img src="NJOYSINFONDO.jpeg" alt="Cargando..."></div>

    <div class="page-content">
        <div class="page-background-container">
            <div class="background-gradient"></div>
        </div>
        
        <header>
            <div class="header-left">
                <div class="logo"><a href="index.php"><img src="NJOYSINFONDO.jpeg" alt="njoy" id="logoImg" /></a></div>
            </div>
            <div class="header-right">
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Buscar juegos y personas...">
                    <div id="searchResults" class="search-results"></div>
                </div>
                <?php if ($usuario_logueado): ?>
                    <div class="usuario" id="usuarioBtn">
                        <img src="" alt="Perfil" id="foto">
                        <span id="nombreUsuario" class="nombre-usuario"></span>
                        <div class="usuario-menu" id="usuarioMenu">
                            <a href="perfil.php">👤 Mi Perfil</a>
                            <a href="#configuracion">⚙️ Configuración</a>
                            <a href="#logout">🚪 Cerrar sesión</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="acciones-invitado">
                        <a href="login.html" class="btn-acceso">Iniciar Sesión</a>
                        <a href="registro2.html" class="btn-acceso btn-registro">Registrarse</a>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <nav>
            <a href="index.php#recomendados-para-ti">Recomendados</a>
            <a href="index.php#ofertas">Ofertas</a>
            <a href="index.php#populares">Populares</a>
            <a href="index.php#free-to-play">Gratis</a>
            <a href="index.php#novedades">Novedades</a>
        </nav>

        <main>
            <div class="content-wrapper">
                <section class="section">
                    <h1 class="section-title"><?php echo htmlspecialchars($categoria_nombre); ?></h1>
                    
                    <div class="juegos-lista">
                        <?php
                        if ($result_juegos_categoria && $result_juegos_categoria->num_rows > 0) {
                            while($juego = $result_juegos_categoria->fetch_assoc()) {
                                // Se llama a la función que genera la VISTA DE LISTA
                                generarJuegoFilaHTML($juego);
                            }
                        } else {
                            echo '<p class="no-juegos-mensaje">No hay juegos disponibles en esta categoría por el momento.</p>';
                        }
                        ?>
                    </div>
                </section>
            </div>
        </main>

        <footer>
            <p id="footer-text">© 2025 NJOY - Tu tienda de videojuegos. Todos los derechos reservados.</p>
        </footer>
    </div>

    <!-- MODALES -->
    <div class="modal" id="modalLogout">
        <div class="modal-content">
            <span class="cerrar" data-close="modalLogout">&times;</span>
            <h2>Cerrar sesión</h2>
            <p>¿Estás seguro de que quieres salir?</p>
            <button id="confirmarLogout" style="background: #ef4444;">Sí, cerrar sesión</button>
            <button id="cancelarLogout" class="modal-button-secondary">Cancelar</button>
        </div>
    </div>
    <div class="modal" id="modalConfig">
        <div class="modal-content">
            <span class="cerrar" data-close="modalConfig">&times;</span>
            <h2>Configuración</h2>
            <!-- Aquí iría el contenido del modal de configuración -->
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isUserLoggedIn = <?php echo json_encode($usuario_logueado); ?>;
    
    // --- LÓGICA DEL LOADER ---
    window.addEventListener('load', function() {
        const loader = document.getElementById('loader');
        const pageContent = document.querySelector('.page-content');
        if (loader) { loader.classList.add('hidden'); }
        if (pageContent) { pageContent.classList.add('loaded'); }
    });

    // --- LÓGICA DEL HEADER (MENÚ USUARIO, BÚSQUEDA, MODALES) ---
    if (isUserLoggedIn) {
        const usuarioBtn = document.getElementById("usuarioBtn");
        const usuarioMenu = document.getElementById("usuarioMenu");
        
        if(usuarioBtn) {
            usuarioBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                usuarioMenu.style.display = usuarioMenu.style.display === "block" ? "none" : "block";
            });
        }
        document.addEventListener("click", (e) => {
            if (usuarioMenu && usuarioMenu.style.display === "block" && !usuarioMenu.contains(e.target) && !usuarioBtn.contains(e.target)) {
                usuarioMenu.style.display = "none";
            }
        });

        document.querySelectorAll(".usuario-menu a").forEach(link => {
            link.addEventListener("click", (e) => {
                const href = link.getAttribute("href");
                if (href.startsWith("#")) {
                    e.preventDefault();
                    const modalId = href === "#logout" ? 'modalLogout' : (href === "#configuracion" ? 'modalConfig' : null);
                    if(modalId) document.getElementById(modalId).style.display = 'flex';
                    if (usuarioMenu) usuarioMenu.style.display = 'none';
                }
            });
        });
        
        fetch('obtener_datos_usuario.php?v=' + new Date().getTime())
            .then(response => response.json())
            .then(data => {
                if (data.status === "ok") {
                    const fotoEl = document.getElementById("foto");
                    const nombreEl = document.getElementById("nombreUsuario");
                    if(fotoEl) fotoEl.src = data.foto + "?t=" + new Date().getTime();
                    if(nombreEl) nombreEl.textContent = data.nombre;
                }
            });
    }

    const confirmarLogoutBtn = document.getElementById("confirmarLogout");
    if(confirmarLogoutBtn) {
        confirmarLogoutBtn.addEventListener("click", () => {
            fetch('logout.php', { method: 'POST' }).finally(() => window.location.href = 'index.php');
        });
    }
    
    document.querySelectorAll(".cerrar, [data-close], #cancelarLogout").forEach(el => {
        el.addEventListener("click", () => el.closest('.modal').style.display = "none");
    });

    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    if(searchInput && searchResults) {
        searchInput.addEventListener('input', () => {
            const term = searchInput.value.trim();
            if (term.length < 2) {
                searchResults.style.display = 'none';
                return;
            }
            fetch(`buscar.php?termino=${encodeURIComponent(term)}`)
                .then(response => response.json())
                .then(data => {
                    searchResults.innerHTML = ''; // Limpiar resultados
                    if (data.juegos && data.juegos.length > 0) {
                        data.juegos.forEach(juego => {
                            searchResults.innerHTML += `<a href="${juego.pagina_url || '#'}" class="search-item"><img src="${juego.imagen_url}" alt=""><span>${juego.titulo}</span></a>`;
                        });
                    }
                    if (data.usuarios && data.usuarios.length > 0) {
                         data.usuarios.forEach(usuario => { 
                             searchResults.innerHTML += `<a href="perfil.php?id=${usuario.id}" class="search-item"><img src="${usuario.foto}" alt="" class="avatar"><span>${usuario.nombre}</span></a>`; 
                        });
                    }
                    searchResults.style.display = 'block';
                });
        });
        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target)) searchResults.style.display = 'none';
        });
    }
});
</script>
</body>
</html>
<?php
// Cerramos la conexión a la base de datos
if (isset($stmt)) {
    $stmt->close();
}
if (isset($conn)) {
    $conn->close();
}
?>